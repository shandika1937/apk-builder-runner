// ignore_for_file: use_build_context_synchronously, deprecated_member_use
import 'package:flutter/material.dart';
import 'dart:ui' as ui; // Import ini untuk ImageFilter

// Impor halaman tujuan Anda
import 'home_page.dart';
import 'home_page2.dart'; // Tempat AttackPage2 berada
import 'bug_group.dart'; // Tempat GroupBugPage berada

// ══════════════════════════════════════════════════════════════════════════════
// CONSTANTS (Sesuai palet warna & tipografi gambar)
// ══════════════════════════════════════════════════════════════════════════════
const Color _bgColor = Color(0xFF030A0A);
const Color _greenNeon = Color(0xFF00FF66);

class NetraxPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;
  final List<Map<String, dynamic>> listPayload;

  const NetraxPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
    required this.listPayload,
  });

  @override
  State<NetraxPage> createState() => _NetraxPageState();
}

class _NetraxPageState extends State<NetraxPage> {
  late PageController _pageController;
  int _currentPage = 0;
  final int _totalPages = 3;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.88, initialPage: 0);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgColor,
      body: Stack(
        children: [
          // Background Image setengah (Atas)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: MediaQuery.of(context).size.height * 0.5, // Setengah tinggi layar
            child: Image.asset(
              'assets/images/select.jpg',
              fit: BoxFit.cover, // Gambar menutupi area yang ditentukan
            ),
          ),
          // Overlay Hitam Transparan di atas gambar (agar teks terbaca jelas)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: MediaQuery.of(context).size.height * 0.5,
            child: Container(
              color: Colors.black.withOpacity(0.5), // Sesuaikan opacity sesuai kebutuhan
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 19),
                // Top Green Bubble Icon
                Center(
                  child: Container(
                    width: 76,
                    height: 76,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _greenNeon,
                      boxShadow: [
                        BoxShadow(
                          color: _greenNeon.withOpacity(0.4),
                          blurRadius: 25,
                          spreadRadius: 2,
                        )
                      ],
                    ),
                    child: const Icon(
                      Icons.chat_bubble,
                      color: Colors.white,
                      size: 36,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                // App Title Logo Text
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'NEBULA ',
                      style: TextStyle(
                        fontFamily: 'Rajdhani',
                        fontSize: 34,
                        fontWeight: FontWeight.w900,
                        color: _greenNeon,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const Text(
                      'MENU',
                      style: TextStyle(
                        fontFamily: 'Rajdhani',
                        fontSize: 34,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                // Subtitle
                Text(
                  'Pilih menu yang tersedia bosque!',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white.withOpacity(0.8),
                  ),
                ),
                const SizedBox(height: 6),
                // Horizontal Glowing Accent Line
                Container(
                  width: 90,
                  height: 4,
                  decoration: BoxDecoration(
                    color: _greenNeon,
                    borderRadius: BorderRadius.circular(2),
                    boxShadow: [
                      BoxShadow(
                        color: _greenNeon.withOpacity(0.8),
                        blurRadius: 10,
                      )
                    ],
                  ),
                ),
                const SizedBox(height: 30),
                // Horizontal Sliding Cards using PageView
                Expanded(
                  child: PageView(
                    controller: _pageController,
                    onPageChanged: (int page) {
                      setState(() {
                        _currentPage = page;
                      });
                    },
                    children: [
                      // CARD 1: NEBULA BUG
                      _buildMenuCard(
                        gradientColors: [
                          const Color(0xFF0C5540),
                          const Color(0xFF021B14),
                        ],
                        iconData: Icons.bug_report,
                        iconColor: _greenNeon,
                        badgeText: 'RECOMMENDED',
                        badgeColor: const Color(0xFFFF5500),
                        title: 'NEBULA BUG',
                        description: 'Bug tanpa custom',
                        longInstruction: 'Gunakan langsung tanpa custom delay dan loops',
                        tags: ['Mudah digunakan', 'Function terbaru', 'All work gacor'],
                        onStart: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => HomePage(
                                username: widget.username,
                                password: widget.password,
                                sessionKey: widget.sessionKey,
                                listBug: widget.listPayload,
                                role: widget.role,
                                expiredDate: widget.expiredDate,
                              ),
                            ),
                          );
                        },
                      ),
                      // CARD 2: NEBULA BUG2
                      _buildMenuCard(
                        gradientColors: [
                          const Color(0xFF5D00FF),
                          const Color(0xFF160040),
                        ],
                        iconData: Icons.settings,
                        iconColor: const Color(0xFFA855F7),
                        badgeText: 'BUG',
                        badgeColor: const Color(0xFFFF007F),
                        title: 'NEBULA BUG2',
                        description: 'Menu Bug 2',
                        longInstruction: 'Buat menu bug, delay pengiriman dan loops',
                        tags: ['Pengaturan Mudah', 'Support Multi Bug', 'Bebas Spam'],
                        onStart: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => AttackPage2(
                                username: widget.username,
                                password: widget.password,
                                sessionKey: widget.sessionKey,
                                listBug: widget.listPayload,
                                role: widget.role,
                                expiredDate: widget.expiredDate,
                              ),
                            ),
                          );
                        },
                      ),
                      // CARD 3: BUG GRUP
                      _buildMenuCard(
                        gradientColors: [
                          const Color(0xFFFF6B00),
                          const Color(0xFF4A1A00),
                        ],
                        iconData: Icons.groups_rounded,
                        iconColor: const Color(0xFFFFCC00),
                        badgeText: 'BUG',
                        badgeColor: const Color(0xFFFFCC00),
                        title: 'BUG GRUP',
                        description: 'Menu bug group',
                        longInstruction: '',
                        tags: ['Mudah Digunakan', 'Anti Gimmick'],
                        onStart: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => GroupBugPage(
                                username: widget.username,
                                password: widget.password,
                                sessionKey: widget.sessionKey,
                                role: widget.role,
                                expiredDate: widget.expiredDate,
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 25),
                // Custom Sync Indicator Dots
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(_totalPages, (index) {
                    final bool isSelected = _currentPage == index;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: isSelected ? 24 : 10,
                      height: 10,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        color: isSelected ? _greenNeon : Colors.white.withOpacity(0.25),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 35),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // CARD BUILDER METHOD (Komponen Kartu UI Sesuai Gambar)
  // ══════════════════════════════════════════════════════════════════════════════
  Widget _buildMenuCard({
    required List<Color> gradientColors,
    required IconData iconData,
    required Color iconColor,
    required String badgeText,
    required Color badgeColor,
    required String title,
    required String description,
    required String longInstruction,
    required List<String> tags,
    required VoidCallback onStart,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: gradientColors,
        ),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1.5,
        ),
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Row: Top Left Circular Icon & Top Right Badge
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.08),
                ),
                child: Icon(iconData, color: iconColor, size: 26),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: badgeColor, width: 1.5),
                ),
                child: Text(
                  badgeText,
                  style: TextStyle(
                    color: badgeColor,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          // Title dengan kombinasi Warna Hijau + Putih
          Row(
            children: [
              Text(
                title.split(' ')[0],
                style: const TextStyle(
                  fontFamily: 'Rajdhani',
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                  color: _greenNeon,
                  letterSpacing: 0.5,
                ),
              ),
              if (title.split(' ').length > 1)
                Text(
                  ' ${title.split(' ')[1]}',
                  style: const TextStyle(
                    fontFamily: 'Rajdhani',
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 0.5,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 4),
          // Sub-description teks putih transparan
          Text(
            description,
            style: TextStyle(
              fontSize: 16,
              color: Colors.white.withOpacity(0.8),
            ),
          ),
          const SizedBox(height: 12),
          // Pembatas Tipis (Divider)
          Container(
            width: double.infinity,
            height: 0.6,
            color: Colors.white.withOpacity(0.2),
          ),
          const SizedBox(height: 16),
          // Instruksi panjang (jika ada data)
          if (longInstruction.isNotEmpty) ...[
            Text(
              longInstruction,
              style: TextStyle(
                fontSize: 16,
                color: Colors.white.withOpacity(0.8),
                height: 1.4,
              ),
            ),
            const SizedBox(height: 20),
          ],
          // Daftar Fitur/Tags (Mudah digunakan, dll) menggunakan Wrap
          Wrap(
            spacing: 8,
            runSpacing: 10,
            children: tags.map((tag) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.12),
                    width: 0.8,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.check_circle_outline,
                      color: _greenNeon,
                      size: 15,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      tag,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
          const Spacer(),
          // Tombol Utama Glowing: START MODULE (Transparan dengan Blur)
          InkWell(
            onTap: onStart,
            borderRadius: BorderRadius.circular(20),
            child: Container(
              width: double.infinity,
              height: 58,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: Colors.white.withOpacity(0.2),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.white.withOpacity(0.1),
                    blurRadius: 20,
                    spreadRadius: 2,
                  )
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: BackdropFilter(
                  filter: ui.ImageFilter.blur(
                    sigmaX: 10.0,
                    sigmaY: 10.0,
                  ),
                  child: Container(
                    width: double.infinity,
                    height: double.infinity,
                    color: Colors.transparent,
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'START MODULE',
                          style: TextStyle(
                            fontFamily: 'Rajdhani',
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          ),
                        ),
                        SizedBox(width: 10),
                        Icon(
                          Icons.arrow_forward_ios,
                          color: Colors.white,
                          size: 16,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}