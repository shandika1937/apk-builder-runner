import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' show Random;

import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

import 'api_config.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'netrax_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'sellect_page.dart';
import 'thema.dart';

// ─── COLORS ────────────────────────────────────────────────────────────────────
const Color kBg      = Color(0xFF0D1117);
const Color kCard    = Color(0xFF161B22);
const Color kCardAlt = Color(0xFF1C2333);
const Color kBorder  = Color(0xFF30363D);
const Color kCyan    = Color(0xFF00E5FF);
const Color kGreen   = Color(0xFF00E676);
const Color kPink    = Color(0xFFE91E8C);
const Color kOrange  = Color(0xFFFF6D00);
const Color kBlue    = Color(0xFF2979FF);
const Color kPurple  = Color(0xFF7C4DFF);
const Color kYellow  = Color(0xFFFFD600);
const Color kWhite   = Colors.white;
const Color kWhite54 = Colors.white54;
const Color kWhite24 = Colors.white24;

// ─── Nav Item ─────────────────────────────────────────────────────────────────
class _NavItem {
  final IconData icon;
  final String label;
  final bool isCenter;

  const _NavItem({
    required this.icon,
    required this.label,
    this.isCenter = false,
  });
}

// ─── Status Item Model ────────────────────────────────────────────────────────
class _StatusItem {
  final String id;
  final String name;
  final String avatarUrl;
  final bool isMe;
  final bool hasNewStatus;

  _StatusItem({
    required this.id,
    required this.name,
    this.avatarUrl = '',
    this.isMe = false,
    this.hasNewStatus = true,
  });
}

// ─── Prayer Time Service ───────────────────────────────────────────────────────
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city,
      'country': 'ID',
      'method': '11',
      'day': '${now.day}',
      'month': '${now.month}',
      'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

// ─── Weather Service ───────────────────────────────────────────────────────────
class WeatherService {
  static const String apiKey = 'test';
  static const String baseUrl = 'http://api.agromonitoring.com/agro/1.0';

  static final Map<String, Map<String, double>> _cityCoords = {
    'Surabaya': {'lat': -7.2575, 'lon': 112.7521},
    'Jakarta': {'lat': -6.2088, 'lon': 106.8456},
    'Bandung': {'lat': -6.9175, 'lon': 107.6191},
    'Medan': {'lat': 3.5952, 'lon': 98.6722},
    'Makassar': {'lat': -5.1477, 'lon': 119.4327},
    'Semarang': {'lat': -6.9667, 'lon': 110.4167},
    'Yogyakarta': {'lat': -7.7971, 'lon': 110.3688},
    'Malang': {'lat': -7.9797, 'lon': 112.6304},
    'Denpasar': {'lat': -8.6704, 'lon': 115.2126},
    'Palembang': {'lat': -2.9909, 'lon': 104.7566},
    'Tangerang': {'lat': -6.1783, 'lon': 106.6319},
    'Bekasi': {'lat': -6.2383, 'lon': 106.9756},
    'Depok': {'lat': -6.4025, 'lon': 106.7942},
    'Bogor': {'lat': -6.5897, 'lon': 106.7928},
    'Padang': {'lat': -0.9471, 'lon': 100.4172},
    'Pekanbaru': {'lat': 0.5071, 'lon': 101.4478},
    'Lampung': {'lat': -5.3971, 'lon': 105.2670},
    'Pontianak': {'lat': -0.0263, 'lon': 109.3425},
    'Balikpapan': {'lat': -1.2379, 'lon': 116.8489},
    'Manado': {'lat': 1.4748, 'lon': 124.8421},
  };

  static Future<Map<String, dynamic>> fetchWeather(String city) async {
    try {
      final coords = _getCityCoordinates(city);
      if (coords == null) return {};

      final uri = Uri.parse(
          '$baseUrl/weather?lat=${coords['lat']}&lon=${coords['lon']}&appid=$apiKey');

      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (_) {}
    return {};
  }

  static Map<String, double>? _getCityCoordinates(String city) {
    if (_cityCoords.containsKey(city)) return _cityCoords[city];
    final lowerCity = city.toLowerCase();
    for (final entry in _cityCoords.entries) {
      if (entry.key.toLowerCase() == lowerCity) return entry.value;
    }
    return _cityCoords['Surabaya'];
  }

  static bool isGoodWeather(String weatherMain) {
    final goodWeathers = [
      'Clear',
      'Clouds',
      'Haze',
      'Mist',
      'Fog',
      'Sunny',
      'Fair'
    ];
    return goodWeathers.contains(weatherMain);
  }

  static bool isBadWeather(String weatherMain) {
    final badWeathers = [
      'Rain',
      'Drizzle',
      'Thunderstorm',
      'Snow',
      'Squall',
      'Storm',
      'Shower'
    ];
    return badWeathers.contains(weatherMain);
  }

  static IconData getWeatherIcon(String weatherMain, bool isGood) {
    if (isGood) {
      switch (weatherMain) {
        case 'Clear':
        case 'Sunny':
          return Icons.wb_sunny_rounded;
        case 'Clouds':
        case 'Haze':
        case 'Mist':
        case 'Fog':
          return Icons.cloud_rounded;
        default:
          return Icons.wb_sunny_rounded;
      }
    } else {
      switch (weatherMain) {
        case 'Rain':
        case 'Drizzle':
        case 'Shower':
          return Icons.grain_rounded;
        case 'Thunderstorm':
        case 'Storm':
          return Icons.flash_on_rounded;
        case 'Snow':
          return Icons.ac_unit_rounded;
        default:
          return Icons.cloud_rounded;
      }
    }
  }

  static Color getWeatherColor(String weatherMain, bool isGood) {
    if (isGood) {
      switch (weatherMain) {
        case 'Clear':
        case 'Sunny':
          return const Color(0xFFFFD600);
        case 'Clouds':
          return const Color(0xFFB0BEC5);
        case 'Haze':
        case 'Mist':
          return const Color(0xFFBDBDBD);
        default:
          return const Color(0xFFFFD600);
      }
    } else {
      switch (weatherMain) {
        case 'Rain':
        case 'Drizzle':
          return const Color(0xFF1A237E);
        case 'Thunderstorm':
        case 'Storm':
          return const Color(0xFFFF6F00);
        case 'Snow':
          return const Color(0xFFE3F2FD);
        default:
          return const Color(0xFF37474F);
      }
    }
  }

  static Map<String, dynamic> parseWeatherResponse(Map<String, dynamic> data) {
    final weather = data['weather'] ?? [];
    final main = weather.isNotEmpty ? weather[0]['main'] ?? 'Clear' : 'Clear';
    double temp = data['main']?['temp'] ?? 0.0;
    if (temp > 100) temp = temp - 273.15;

    return {
      'main': main,
      'temp': temp,
      'description':
          weather.isNotEmpty ? weather[0]['description'] ?? '' : '',
    };
  }
}

// ─── Role helpers ─────────────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':
      return const Color(0xFFF59E0B);
    case 'admin':
      return const Color(0xFFEF4444);
    case 'reseller':
      return kGreen;
    case 'vip':
      return kPurple;
    default:
      return kCyan;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'owner':
      return Icons.workspace_premium_rounded;
    case 'admin':
      return Icons.admin_panel_settings_rounded;
    case 'reseller':
      return Icons.storefront_rounded;
    case 'vip':
      return Icons.star_rounded;
    default:
      return Icons.person_rounded;
  }
}

// ─── ANIMATED DOT ──────────────────────────────────────────────────────────────
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => FadeTransition(
        opacity: _a,
        child: Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.color,
            boxShadow: [
              BoxShadow(
                  color: widget.color.withValues(alpha: 0.6),
                  blurRadius: 6,
                  spreadRadius: 1)
            ],
          ),
        ),
      );
}

// ─── HEXAGON PATTERN PAINTER ──────────────────────────────────────────────────
class _HexagonPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = kCyan.withValues(alpha: 0.12)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const double w = 72.0;
    const double h = 52.0;

    for (double row = -1; row * h < size.height + h * 2; row++) {
      for (double col = -1; col * w < size.width + w * 2; col++) {
        final double offsetX = (row.toInt() % 2 == 0) ? 0 : w * 0.5;
        final cx = col * w + offsetX;
        final cy = row * h;
        _drawDiamond(canvas, paint, Offset(cx, cy), w * 0.5, h * 0.5);
      }
    }
  }

  void _drawDiamond(
      Canvas canvas, Paint paint, Offset center, double hw, double hh) {
    final path = Path()
      ..moveTo(center.dx, center.dy - hh)
      ..lineTo(center.dx + hw, center.dy)
      ..lineTo(center.dx, center.dy + hh)
      ..lineTo(center.dx - hw, center.dy)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── GRID PATTERN PAINTER ─────────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  final Color gridColor;
  final Color lineColor;
  final double spacing;
  const _GridPatternPainter({
    required this.gridColor,
    required this.lineColor,
    required this.spacing,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paintGrid = Paint()
      ..color = gridColor
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;
    final paintLines = Paint()
      ..color = lineColor
      ..strokeWidth = 0.4
      ..style = PaintingStyle.stroke;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paintGrid);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paintGrid);
    }
    for (double x = -size.height;
        x < size.width + size.height;
        x += spacing * 2) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height),
          paintLines);
    }
    for (double x = -size.height;
        x < size.width + size.height;
        x += spacing * 2) {
      canvas.drawLine(Offset(x, size.height), Offset(x + size.height, 0),
          paintLines);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── COMIC GRID PATTERN PAINTER ───────────────────────────────────────────────
class _ComicGridPatternPainter extends CustomPainter {
  final Color dotColor;
  const _ComicGridPatternPainter({required this.dotColor});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = dotColor
      ..style = PaintingStyle.fill;
    const double spacing = 12.0;
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), 1.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── Embedded Wrapper ─────────────────────────────────────────────────────────
/// Wrapper untuk menampilkan halaman yang punya Scaffold/AppBar sendiri
/// agar tetap muncul di dalam body DashboardPage (bukan fullscreen).
class _EmbeddedPage extends StatelessWidget {
  final Widget child;
  const _EmbeddedPage({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.transparent,
      child: child,
    );
  }
}

// ─── Dashboard Page ───────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // ── State ────────────────────────────────────────────────────────────────
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  late WebSocketChannel channel;
  String androidId = 'unknown';
  File? _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex = 0;
  int onlineUsers = 0;
  int activeConns = 0;

  // ── Status NEBULAgram State ──────────────────────────────────────────────
  List<_StatusItem> _statusList = [
    _StatusItem(id: '1', name: 'partiganteng', hasNewStatus: true),
    _StatusItem(id: '2', name: 'Zhaa', hasNewStatus: true),
    _StatusItem(id: '3', name: 'angga7', hasNewStatus: true),
    _StatusItem(id: '4', name: 'wildanx', hasNewStatus: true),
    _StatusItem(id: '5', name: 'Jancikteam', hasNewStatus: true),
    _StatusItem(id: '6', name: 'Damzy', hasNewStatus: true),
  ];

  // ── Weather State ──────────────────────────────────────────────────────────
  String _weatherCity = 'Surabaya';
  String _weatherMain = 'Clear';
  double _weatherTemp = 0;
  bool _weatherLoading = true;
  bool _weatherIsGood = true;

  // ── Animation controllers ─────────────────────────────────────────────────
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  Timer? _statsTimer;

  late PageController _newsPageCtrl;
  int _newsPageViewKey = 0;
  double _currentNewsPage = 0.0;

  late PageController _qaPageCtrl;
  double _currentQaPage = 0.0;

  bool _locationLoading = false;
  bool _locationGranted = false;

  String _prayerCity = 'Surabaya';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime = '';
  bool _prayerLoading = true;

  Map<String, dynamic>? _hadith;
  bool _hadithLoading = true;
  int _lastHadithNumber = 0;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim =
        CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _newsPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _newsPageCtrl.addListener(() {
      if (mounted) {
        setState(() => _currentNewsPage = _newsPageCtrl.page ?? 0.0);
      }
    });

    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() {
      if (mounted) setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0);
    });

    _initAndroidId();
    _loadProfileImage();
    _initMenuVideo();
    _detectLocationAndFetchWeather();
    _detectLocationAndFetchPrayer();
    _fetchRandomHadith();
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    try {
      channel.sink.close(status.goingAway);
    } catch (_) {}
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _newsPageCtrl.dispose();
    _qaPageCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  void _initMenuVideo() {
    _menuVideoCtrl =
        VideoPlayerController.asset('assets/videos/banner.mp4')
          ..initialize().then((_) {
            if (mounted) setState(() {});
            _menuVideoCtrl?.setLooping(true);
            _menuVideoCtrl?.setVolume(0);
            _menuVideoCtrl?.play();
          });
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
    try {
      channel = WebSocketChannel.connect(
          Uri.parse('ws://yefan.myserverr.web.id:2111'));

      channel.sink.add(jsonEncode({
        'type': 'validate',
        'key': sessionKey,
        'androidId': androidId,
      }));

      channel.stream.listen((event) {
        final data = jsonDecode(event);

        if (data['type'] == 'myInfo' &&
            data['valid'] == true &&
            mounted) {
          channel.sink.add(jsonEncode({'type': 'stats'}));
        }

        if (data['type'] == 'stats' && mounted) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConns = data['activeConnections'] ?? 0;
          });
        }

        if (data['type'] == 'myInfo' &&
            data['valid'] == false &&
            mounted) {
          _handleInvalidSession(data['reason'] ?? 'Session invalid');
        }

        if (data['type'] == 'forceLogout' && mounted) {
          _handleInvalidSession(data['reason'] ?? 'Logged out');
        }
      }, onError: (_) {
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) _connectWS();
        });
      });

      _statsTimer?.cancel();
      _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
        try {
          channel.sink.add(jsonEncode({'type': 'stats'}));
        } catch (_) {}
      });
    } catch (e) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) _connectWS();
      });
    }
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  Future<void> _fetchWeather() async {
    if (!mounted) return;
    setState(() => _weatherLoading = true);
    final data = await WeatherService.fetchWeather(_weatherCity);
    if (!mounted) return;

    if (data.isNotEmpty) {
      final parsed = WeatherService.parseWeatherResponse(data);
      final main = parsed['main'] ?? 'Clear';
      final temp = parsed['temp'] ?? 0.0;
      final isGood = WeatherService.isGoodWeather(main);

      setState(() {
        _weatherMain = main;
        _weatherTemp = temp;
        _weatherIsGood = isGood;
        _weatherLoading = false;
      });
    } else {
      setState(() {
        _weatherMain = 'Clear';
        _weatherTemp = 28.0;
        _weatherIsGood = true;
        _weatherLoading = false;
      });
    }
  }

  Future<void> _detectLocationAndFetchWeather() async {
    if (!mounted) return;
    setState(() => _weatherLoading = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _weatherLoading = false;
            _weatherCity = 'Surabaya';
          });
          await _fetchWeather();
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _weatherLoading = false;
              _weatherCity = 'Surabaya';
            });
            await _fetchWeather();
          }
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _weatherLoading = false;
            _weatherCity = 'Surabaya';
          });
          await _fetchWeather();
        }
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );

      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        String city = 'Surabaya';

        if (place.subAdministrativeArea?.isNotEmpty == true) {
          city = place.subAdministrativeArea!;
        } else if (place.locality?.isNotEmpty == true) {
          city = place.locality!;
        } else if (place.administrativeArea?.isNotEmpty == true) {
          city = place.administrativeArea!;
        }

        setState(() {
          _weatherCity = city;
          _locationGranted = true;
          _weatherLoading = false;
        });

        await _fetchWeather();
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _weatherLoading = false;
          _weatherCity = 'Surabaya';
        });
        await _fetchWeather();
      }
    }
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh': timings['Fajr'] ?? '--:--',
        'Dzuhur': timings['Dhuhr'] ?? '--:--',
        'Ashar': timings['Asr'] ?? '--:--',
        'Maghrib': timings['Maghrib'] ?? '--:--',
        'Isya': timings['Isha'] ?? '--:--',
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime = nextTime;
        _prayerLoading = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _locationLoading = false;
              _prayerCity = 'Surabaya';
            });
            await _fetchPrayerTimes();
          }
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );

      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        String city = 'Surabaya';

        if (place.subAdministrativeArea?.isNotEmpty == true) {
          city = place.subAdministrativeArea!;
        } else if (place.locality?.isNotEmpty == true) {
          city = place.locality!;
        } else if (place.administrativeArea?.isNotEmpty == true) {
          city = place.administrativeArea!;
        }

        setState(() {
          _prayerCity = city;
          _locationGranted = true;
          _locationLoading = false;
        });

        await _fetchPrayerTimes();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                const Icon(Icons.location_on_rounded,
                    color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text('Lokasi terdeteksi: $city'),
              ]),
              backgroundColor: kGreen,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _locationLoading = false;
          _prayerCity = 'Surabaya';
        });
        await _fetchPrayerTimes();
      }
    }
  }

  Future<void> _fetchRandomHadith() async {
    if (!mounted) return;
    setState(() => _hadithLoading = true);
    try {
      int randomNumber;
      do {
        randomNumber = Random().nextInt(100) + 1;
      } while (randomNumber == _lastHadithNumber);
      _lastHadithNumber = randomNumber;
      final response = await http
          .get(Uri.parse(
              'https://api.hadith.gading.dev/books/muslim/$randomNumber'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200 && mounted) {
        setState(() {
          _hadith = json.decode(response.body);
          _hadithLoading = false;
        });
      } else {
        if (mounted) setState(() => _hadithLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _hadithLoading = false);
    }
  }

  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Ganti Lokasi',
            style: TextStyle(
                color: kWhite, fontFamily: 'Orbitron', fontSize: 14)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: kWhite),
          decoration: InputDecoration(
            hintText: 'Nama kota (misal: Jakarta)',
            hintStyle: const TextStyle(color: kWhite54),
            filled: true,
            fillColor: kBg,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.location_city_rounded, color: kGreen),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal',
                  style: TextStyle(color: kWhite54))),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) {
                setState(() {
                  _prayerCity = ctrl.text.trim();
                  _locationGranted = false;
                });
                _fetchPrayerTimes();
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: kGreen,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10))),
            child: const Text('Simpan',
                style: TextStyle(
                    color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showHadithFullDialog(String arabic, String indo, String source,
      String number, String grade) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kCyan.withValues(alpha: 0.3)),
            boxShadow: [
              BoxShadow(
                  color: kCyan.withValues(alpha: 0.08),
                  blurRadius: 30,
                  spreadRadius: 2),
              BoxShadow(
                  color: Colors.black.withValues(alpha: 0.6),
                  blurRadius: 20,
                  offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(24)),
                  color: kCyan.withValues(alpha: 0.08),
                  border: Border(
                      bottom: BorderSide(
                          color: kBorder.withValues(alpha: 0.5))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: kCyan.withValues(alpha: 0.2)),
                      child: const Icon(Icons.menu_book_rounded,
                          color: kCyan, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('HADITH LENGKAP',
                                style: TextStyle(
                                    color: kWhite,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                    fontFamily: 'Orbitron')),
                            Text(grade,
                                style: const TextStyle(
                                    color: kCyan, fontSize: 11)),
                          ]),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: kWhite.withValues(alpha: 0.08)),
                        child: const Icon(Icons.close_rounded,
                            color: kWhite54, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(
                    maxHeight:
                        MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: const Color(0xFF1A1F2E),
                          border: Border.all(
                              color: kBorder.withValues(alpha: 0.3)),
                        ),
                        child: Text(arabic,
                            textAlign: TextAlign.right,
                            textDirection: TextDirection.rtl,
                            style: const TextStyle(
                                color: kWhite,
                                fontSize: 19,
                                height: 2.2)),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        Container(
                            width: 3,
                            height: 18,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(2),
                                color: kCyan)),
                        const SizedBox(width: 8),
                        const Text('ARTINYA:',
                            style: TextStyle(
                                color: kCyan,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.2)),
                      ]),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: const Color(0xFF141824),
                          border: Border.all(
                              color: kBorder.withValues(alpha: 0.2)),
                        ),
                        child: Text(indo,
                            style: const TextStyle(
                                color: kWhite,
                                fontSize: 14,
                                fontStyle: FontStyle.italic,
                                height: 1.8)),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: kCyan.withValues(alpha: 0.5)),
                          color: kCyan.withValues(alpha: 0.08),
                        ),
                        child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.receipt_long_rounded,
                                  color: kCyan, size: 14),
                              const SizedBox(width: 6),
                              Text(
                                  '${source.isNotEmpty ? source : "Muslim"} #$number',
                                  style: const TextStyle(
                                      color: kCyan,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold)),
                            ]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Status NEBULAgram Functions ──────────────────────────────────────────
  void _addStatus() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Buat Status Baru',
            style: TextStyle(color: kWhite, fontFamily: 'Orbitron')),
        content: const Text(
            'Fitur ini akan membuka kamera atau galeri untuk mengunggah status Anda.',
            style: TextStyle(color: kWhite54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child:
                const Text('Batal', style: TextStyle(color: kWhite54)),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _statusList.insert(
                    0,
                    _StatusItem(
                      id: DateTime.now().millisecondsSinceEpoch.toString(),
                      name: username,
                      isMe: true,
                      hasNewStatus: true,
                    ));
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content: Text('Status berhasil ditambahkan!'),
                    backgroundColor: kGreen),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: kCyan),
            child: const Text('Tambah',
                style: TextStyle(
                    color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _viewStatus(_StatusItem item) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.black87,
        insetPadding: const EdgeInsets.all(16),
        child: Container(
          height: 400,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white, width: 3),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 40,
                backgroundColor: Colors.grey[800],
                child: Text(
                  item.name.isNotEmpty ? item.name[0].toUpperCase() : '?',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 16),
              Text(item.name,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Sedang melihat status...',
                  style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(backgroundColor: kCyan),
                child:
                    const Text('Tutup', style: TextStyle(color: Colors.black)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('⚠️ Session Expired',
            style: TextStyle(color: kWhite)),
        content: Text(message, style: const TextStyle(color: kWhite54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (_) => false),
            child: const Text('OK', style: TextStyle(color: kCyan)),
          ),
        ],
      ),
    );
  }

  // ── Bottom Nav Handler ─────────────────────────────────────────────────
  // PENTING: RAT (2), TOOLS (3), TEMA (4) sekarang TIDAK pakai Navigator.push
  // sehingga AppBar & BottomNavigationBar tetap terlihat.
  void _onNavTap(int index) {
    setState(() => _navIndex = index);

    if (index == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_newsPageCtrl.hasClients) {
          setState(() {
            _currentNewsPage = 0.0;
            _newsPageViewKey++;
          });
          _newsPageCtrl.jumpToPage(0);
        }
      });
    }
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1:
        page = SellerPage(keyToken: sessionKey);
        break;
      case 2:
        page = AdminPage(sessionKey: sessionKey);
        break;
      case 3:
        page = OwnerPage(sessionKey: sessionKey, username: username);
        break;
      default:
        return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page))
        .then((_) {
      if (mounted) {
        setState(() => _navIndex = 0);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_newsPageCtrl.hasClients) {
            setState(() {
              _currentNewsPage = 0.0;
              _newsPageViewKey++;
            });
            _newsPageCtrl.jumpToPage(0);
          }
        });
      }
    });
  }

  // ── Halaman yang dirender di body berdasarkan tab aktif ────────────────
  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 1:
        // MENU -> NetraxPage
        return NetraxPage(
          username: username,
          password: password,
          sessionKey: sessionKey,
          role: role,
          expiredDate: expiredDate,
          listPayload: listBug,
        );

      case 2:
        // RAT -> SellectPage2 dibungkus _EmbeddedPage
        // _EmbeddedPage memastikan widget tetap dalam body, tidak fullscreen.
        // Jika SellectPage2 punya Scaffold+AppBar sendiri, hilangkan AppBar-nya
        // atau modifikasi SellectPage2 agar menerima parameter `embedded`.
        return _EmbeddedPage(
          child: const SellectPage2(),
        );

      case 3:
        // TOOLS -> ToolsPage dibungkus _EmbeddedPage
        return _EmbeddedPage(
          child: ToolsPage(
            sessionKey: sessionKey,
            userRole: role,
            listDoos: listDoos,
          ),
        );

      case 4:
        // TEMA -> ThemaPage dibungkus _EmbeddedPage
        return _EmbeddedPage(
          child: const ThemaPage(),
        );

      case 0:
      default:
        return _buildHomePage();
    }
  }

  Widget _buildHomePage() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildBannerVideo(),
            const SizedBox(height: 14),
            _buildStatusSection(),
            const SizedBox(height: 14),
            _buildWelcomeCard(),
            const SizedBox(height: 14),
            _buildQuickActionsSection(),
            const SizedBox(height: 14),
            _buildLatestUpdates(),
            const SizedBox(height: 14),
            _buildPrayerSection(),
            const SizedBox(height: 14),
            _buildHadithSection(),
            const SizedBox(height: 24),
            Center(
              child: Text('..',
                  style: TextStyle(
                    color: kWhite.withValues(alpha: 0.12),
                    fontSize: 13,
                    letterSpacing: 4,
                    fontFamily: 'Orbitron',
                  )),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // ── Status NEBULAgram Section (Gaya Komik) ───────────────────────────────
  Widget _buildStatusSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.black, width: 3),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(4, 4),
              blurRadius: 0,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.black, width: 2),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.auto_awesome, color: Colors.yellow, size: 16),
                  SizedBox(width: 6),
                  Text(
                    'STATUS NEBULAGRAM',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 12,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 100,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                itemCount: _statusList.length + 1,
                itemBuilder: (context, index) {
                  if (index == 0) {
                    return GestureDetector(
                      onTap: _addStatus,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 16),
                        child: Column(
                          children: [
                            Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                                border: Border.all(
                                    color: Colors.black, width: 3),
                              ),
                              child: const Icon(Icons.add,
                                  color: Colors.black, size: 30),
                            ),
                            const SizedBox(height: 6),
                            const Text('Buat',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    );
                  }
                  final item = _statusList[index - 1];
                  return GestureDetector(
                    onTap: () => _viewStatus(item),
                    child: Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: Column(
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white,
                              border: Border.all(
                                color: item.hasNewStatus
                                    ? const Color(0xFFE91E8C)
                                    : Colors.black,
                                width: 3,
                              ),
                            ),
                            child: ClipOval(
                              child: item.avatarUrl.isNotEmpty
                                  ? Image.network(item.avatarUrl,
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => Center(
                                            child: Text(
                                              item.name.isNotEmpty
                                                  ? item.name[0]
                                                      .toUpperCase()
                                                  : '?',
                                              style: const TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 24,
                                                  fontWeight:
                                                      FontWeight.bold),
                                            ),
                                          ))
                                  : Center(
                                      child: Text(
                                        item.name.isNotEmpty
                                            ? item.name[0].toUpperCase()
                                            : '?',
                                        style: const TextStyle(
                                            color: Colors.black,
                                            fontSize: 24,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          SizedBox(
                            width: 64,
                            child: Text(
                              item.name,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBannerVideo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          height: 190,
          width: double.infinity,
          color: const Color(0xFF080C12),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_menuVideoCtrl != null &&
                  _menuVideoCtrl!.value.isInitialized)
                FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _menuVideoCtrl!.value.size.width,
                    height: _menuVideoCtrl!.value.size.height,
                    child: VideoPlayer(_menuVideoCtrl!),
                  ),
                )
              else
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF0A0F1E), Color(0xFF1A1A2E)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.black.withValues(alpha: 0.7),
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.4),
                    ],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                ),
              ),
              const Positioned(
                left: 16,
                bottom: 14,
                child: Text('..',
                    style: TextStyle(
                      color: kWhite,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWelcomeCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.black, width: 3),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.8),
                blurRadius: 10,
                offset: const Offset(4, 4))
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Stack(
            children: [
              Positioned.fill(
                child: Image.asset(
                  'assets/images/Syam.jpg',
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      Container(color: Colors.grey[800]),
                ),
              ),
              Positioned.fill(
                child: Container(
                    color: Colors.black.withValues(alpha: 0.4)),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ScaleTransition(
                          scale: _pulseAnim,
                          child: Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                  color: Colors.white, width: 3),
                              image: const DecorationImage(
                                image: AssetImage('assets/images/Avatar.jpg'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Ahlan Wa Sahlan,',
                                  style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Comic Sans MS')),
                              Text('$username ⭐',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: 'Comic Sans MS',
                                      letterSpacing: 1)),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  Icon(Icons.star,
                                      color: Colors.yellow[600], size: 16),
                                  const SizedBox(width: 4),
                                  Text(
                                    role.toUpperCase(),
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 1),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border:
                                Border.all(color: Colors.black, width: 2),
                          ),
                          child: Row(
                            children: const [
                              Icon(Icons.wb_sunny_rounded,
                                  color: Colors.orange, size: 16),
                              SizedBox(width: 6),
                              Text('29°C',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.black, width: 2),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.sync_alt,
                              color: Colors.black, size: 14),
                          const SizedBox(width: 6),
                          Text(
                            role.toUpperCase(),
                            style: const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 11,
                                letterSpacing: 1),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                            child: _buildVpsBox(
                                title: 'VPS NEBULA',
                                ram: '6.3GB/35.2GB',
                                cpu: '17%')),
                        const SizedBox(width: 10),
                        const Expanded(
                            child: _buildVpsBoxStatic(
                                title: 'VPS RAT',
                                ram: '--',
                                cpu: '--')),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Container(
                        height: 3,
                        color: Colors.white.withValues(alpha: 0.5)),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildComicStatItem(
                          icon: Icons.people_alt_rounded,
                          color: Colors.redAccent,
                          value: '$onlineUsers',
                          label: 'Online Users',
                          extraWidget: Positioned(
                            bottom: -4,
                            child: ScaleTransition(
                              scale: _pulseAnim,
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.green,
                                  border: Border.all(
                                      color: Colors.black, width: 2),
                                ),
                                child: const Text('LIVE',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 8,
                                        fontWeight: FontWeight.bold)),
                              ),
                            ),
                          ),
                        ),
                        _buildComicStatItem(
                          icon: Icons.link_rounded,
                          color: Colors.redAccent,
                          value: '$activeConns',
                          label: 'Sender',
                        ),
                        _buildComicStatItem(
                          icon: Icons.calendar_month_rounded,
                          color: Colors.redAccent,
                          value: expiredDate.isNotEmpty &&
                                  expiredDate.length > 10
                              ? expiredDate.substring(0, 10)
                              : expiredDate,
                          label: 'Expired',
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Quick actions (Comic Style) ─────────────────────────────
  Widget _buildQuickActionsSection() {
    final actions = [
      _QuickActionData(
        icon: FontAwesomeIcons.bookOpen,
        bgIcon: FontAwesomeIcons.bookOpen,
        title: 'SENDER BUG',
        subtitle: '',
        gradient: [const Color(0xFF2979FF), const Color(0xFF2979FF)],
        glowColor: Colors.transparent,
        onTap: () => Navigator.push(
          context,
          _slideRoute(BugSenderPage(
              sessionKey: sessionKey, username: username, role: role)),
        ).then((_) {
          if (mounted && _newsPageCtrl.hasClients) {
            setState(() {
              _currentNewsPage = 0.0;
              _newsPageViewKey++;
            });
            _newsPageCtrl.jumpToPage(0);
          }
        }),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.graduationCap,
        bgIcon: FontAwesomeIcons.graduationCap,
        title: 'TUTORIAL',
        subtitle: '',
        gradient: [const Color(0xFFFF3B30), const Color(0xFFFF3B30)],
        glowColor: Colors.transparent,
        onTap: () => _openUrl('https://t.me/aboutszamz'),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.music,
        bgIcon: FontAwesomeIcons.music,
        title: 'MUSIK',
        subtitle: '',
        gradient: [const Color(0xFF34C759), const Color(0xFF34C759)],
        glowColor: Colors.transparent,
        onTap: () => Navigator.push(context, _slideRoute(const AlQuranPage())),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.camera,
        bgIcon: FontAwesomeIcons.camera,
        title: 'NEBULAGRAM',
        subtitle: '',
        gradient: [const Color(0xFF9C27B0), const Color(0xFF9C27B0)],
        glowColor: Colors.transparent,
        onTap: () =>
            Navigator.push(context, _slideRoute(const HomeAnimePage())),
      ),
    ];

    return Column(
      children: [
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate:
                const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
              childAspectRatio: 1.6,
            ),
            itemCount: actions.length,
            itemBuilder: (context, index) {
              return _buildQuickActionCard(actions[index]);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    final baseColor = action.gradient.first;

    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.black, width: 3),
          boxShadow: const [
            BoxShadow(
              color: Colors.black,
              offset: Offset(4, 4),
              blurRadius: 0,
              spreadRadius: 0,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(9),
          child: Stack(
            children: [
              Positioned.fill(child: Container(color: baseColor)),
              Positioned.fill(
                child: CustomPaint(
                  painter: _ComicGridPatternPainter(
                    dotColor: Colors.white.withValues(alpha: 0.15),
                  ),
                ),
              ),
              Positioned(
                right: -15,
                bottom: -15,
                child: Icon(
                  action.bgIcon,
                  color: Colors.white.withValues(alpha: 0.15),
                  size: 100,
                ),
              ),
              Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(action.icon, color: Colors.white, size: 36),
                    const SizedBox(height: 8),
                    Text(
                      action.title,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 13,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                        shadows: [
                          Shadow(
                            offset: Offset(1.5, 1.5),
                            color: Colors.black,
                            blurRadius: 1,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Latest Updates ────────────────────────────────────────────────────────
  Widget _buildLatestUpdates() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              const Icon(Icons.dashboard_customize_rounded,
                  color: kOrange, size: 22),
              const SizedBox(width: 8),
              const Text('LATEST UPDATES',
                  style: TextStyle(
                      color: kWhite,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1)),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: kOrange.withValues(alpha: 0.15),
                    border: Border.all(
                        color: kOrange.withValues(alpha: 0.4)),
                  ),
                  child: Text('${newsList.length} Updates',
                      style: const TextStyle(
                          color: kOrange,
                          fontSize: 11,
                          fontWeight: FontWeight.bold)),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: newsList.length,
              itemBuilder: (ctx, i) =>
                  _buildNewsCardHorizontal(newsList[i]),
            ),
          ),
        if (newsList.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 120,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: kCard,
                  border: Border.all(
                      color: kBorder.withValues(alpha: 0.4))),
              child: const Center(
                  child: Text('No updates available',
                      style: TextStyle(color: kWhite54))),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCardHorizontal(dynamic item) {
    final imgUrl = item['image']?.toString() ?? '';
    final title = item['title']?.toString() ?? 'No Title';
    final date = item['date']?.toString() ??
        item['created_at']?.toString() ??
        '';
    final cardWidth = (MediaQuery.of(context).size.width / 2) - 22;

    return Container(
      width: cardWidth,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: kCard,
        border: Border.all(color: kBorder.withValues(alpha: 0.4)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.4),
              blurRadius: 12,
              offset: const Offset(0, 6))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius:
                const BorderRadius.vertical(top: Radius.circular(18)),
            child: Stack(
              children: [
                Container(
                  height: 110,
                  width: double.infinity,
                  color: kCardAlt,
                  child: imgUrl.isNotEmpty
                      ? Image.network(imgUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Center(
                              child: Icon(Icons.image_not_supported,
                                  color: kWhite54, size: 30)))
                      : const Center(
                          child: Icon(Icons.article_rounded,
                              color: kWhite54, size: 30)),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black.withValues(alpha: 0.65),
                      border: Border.all(
                          color: kOrange.withValues(alpha: 0.7)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle_notifications_rounded,
                            color: kOrange, size: 10),
                        SizedBox(width: 3),
                        Text('NEW',
                            style: TextStyle(
                                color: kOrange,
                                fontSize: 9,
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
            child: Text(title,
                style: const TextStyle(
                    color: kWhite,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    height: 1.3),
                maxLines: 2,
                overflow: TextOverflow.ellipsis),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: Row(
              children: [
                const Icon(Icons.access_time_rounded,
                    color: kWhite54, size: 11),
                const SizedBox(width: 4),
                if (date.isNotEmpty)
                  Expanded(
                    child: Text(
                        date.length > 10
                            ? date.substring(0, 10)
                            : date,
                        style: const TextStyle(
                            color: kWhite54, fontSize: 10)),
                  ),
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: kOrange.withValues(alpha: 0.18)),
                  child: const Icon(Icons.arrow_forward_ios_rounded,
                      color: kOrange, size: 9),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Prayer Section ────────────────────────────────────────────────────────
  Widget _buildPrayerSection() {
    final prayerColors = [
      const Color(0xFF5B4FD4),
      const Color(0xFFFF9800),
      const Color(0xFFFF5722),
      const Color(0xFF1E88E5),
      const Color(0xFF1565C0),
    ];
    final prayerIcons = [
      Icons.nights_stay_rounded,
      Icons.wb_sunny_rounded,
      Icons.cloud_rounded,
      Icons.wb_twilight_rounded,
      Icons.nightlight_round,
    ];
    final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder.withValues(alpha: 0.5)),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.4),
                blurRadius: 18,
                offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: kGreen.withValues(alpha: 0.2),
                    border: Border.all(
                        color: kGreen.withValues(alpha: 0.4)),
                  ),
                  child: const Center(
                      child:
                          Icon(Icons.mosque, color: kGreen, size: 26)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('JADWAL SHOLAT',
                          style: TextStyle(
                              color: kWhite,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1)),
                      Text(_prayerCity,
                          style: const TextStyle(
                              color: kWhite54, fontSize: 12)),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: _locationLoading
                      ? null
                      : _detectLocationAndFetchPrayer,
                  child: Container(
                    width: 38,
                    height: 38,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _locationGranted
                          ? kGreen.withValues(alpha: 0.2)
                          : kWhite24.withValues(alpha: 0.1),
                      border: Border.all(
                        color: _locationGranted
                            ? kGreen.withValues(alpha: 0.6)
                            : kWhite54.withValues(alpha: 0.3),
                      ),
                    ),
                    child: _locationLoading
                        ? const Padding(
                            padding: EdgeInsets.all(10),
                            child: CircularProgressIndicator(
                                color: kGreen, strokeWidth: 2),
                          )
                        : Icon(
                            _locationGranted
                                ? Icons.my_location_rounded
                                : Icons.location_searching_rounded,
                            color: _locationGranted ? kGreen : kWhite54,
                            size: 18,
                          ),
                  ),
                ),
                GestureDetector(
                  onTap: _showChangeCityDialog,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: kGreen,
                    ),
                    child: const Row(children: [
                      Icon(Icons.edit_location_alt_rounded,
                          color: Colors.white, size: 14),
                      SizedBox(width: 5),
                      Text('GANTI',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold)),
                    ]),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (_nextPrayerLabel.isNotEmpty)
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                      color: kGreen.withValues(alpha: 0.5)),
                ),
                child: Row(
                  children: [
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: _AnimatedDot(color: kOrange, size: 10),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                          'Menuju $_nextPrayerLabel : $_nextPrayerTime',
                          style: const TextStyle(
                              color: kWhite,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Orbitron')),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: kGreen.withValues(alpha: 0.5)),
                      ),
                      child: const Text('PXD',
                          style: TextStyle(
                              color: kGreen,
                              fontSize: 10,
                              fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 14),
            if (_prayerLoading)
              const Center(
                  child: CircularProgressIndicator(
                      color: kGreen, strokeWidth: 2))
            else
              SizedBox(
                height: 118,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  itemCount: prayerKeys.length,
                  itemBuilder: (ctx, i) {
                    final key = prayerKeys[i];
                    final time = _prayerTimes[key] ?? '--:--';
                    final color = prayerColors[i];
                    final icon = prayerIcons[i];
                    final isNext = key == _nextPrayerLabel;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      curve: Curves.easeOut,
                      margin: EdgeInsets.only(
                          right: 10,
                          bottom: isNext ? 0 : 6,
                          top: isNext ? 0 : 6),
                      width: 105,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        color: color,
                        boxShadow: [
                          BoxShadow(
                              color: color.withValues(
                                  alpha: isNext ? 0.65 : 0.3),
                              blurRadius: isNext ? 18 : 8,
                              offset: const Offset(0, 4))
                        ],
                        border: isNext
                            ? Border.all(
                                color:
                                    Colors.white.withValues(alpha: 0.5),
                                width: 1.5)
                            : null,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 14, horizontal: 8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(icon, color: Colors.white, size: 24),
                            const SizedBox(height: 5),
                            Text(key.toUpperCase(),
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.8)),
                            const SizedBox(height: 5),
                            Text(time,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 19,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Orbitron')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ── Hadith Section ────────────────────────────────────────────────────────
  Widget _buildHadithSection() {
    if (_hadithLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 200,
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kBorder.withValues(alpha: 0.5)),
          ),
          child: const Center(
              child: CircularProgressIndicator(
                  color: kCyan, strokeWidth: 2)),
        ),
      );
    }

    final arabic = _hadith?['data']?['text']?['ar'] ??
        'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى';
    final indo = _hadith?['data']?['text']?['id'] ??
        'Sesungguhnya setiap amalan tergantung pada niatnya.';
    final number = _hadith?['data']?['id']?.toString() ?? '1';
    final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
    final grade =
        _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder.withValues(alpha: 0.5)),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.4),
                blurRadius: 18,
                offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: kCyan.withValues(alpha: 0.18)),
                  child: const Center(
                      child: Icon(Icons.menu_book_rounded,
                          color: kCyan, size: 26)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('HADITH OF THE DAY',
                            style: TextStyle(
                                color: kWhite,
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                                fontFamily: 'Orbitron',
                                letterSpacing: 0.5)),
                        const SizedBox(height: 2),
                        Text('$grade · Tap card to read full',
                            style: const TextStyle(
                                color: kWhite54, fontSize: 11)),
                      ]),
                ),
              ],
            ),
            const SizedBox(height: 14),
            GestureDetector(
              onTap: () => _showHadithFullDialog(
                  arabic, indo, source, number, grade),
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      color: const Color(0xFF1A1F2E),
                      border: Border.all(
                          color: kBorder.withValues(alpha: 0.3)),
                    ),
                    child: Text(arabic,
                        textAlign: TextAlign.right,
                        textDirection: TextDirection.rtl,
                        style: const TextStyle(
                            color: kWhite,
                            fontSize: 17,
                            height: 2.0)),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        color: const Color(0xFF141824)),
                    child: Text(indo,
                        style: const TextStyle(
                            color: kWhite54,
                            fontSize: 12,
                            fontStyle: FontStyle.italic,
                            height: 1.7),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                        color: kCyan.withValues(alpha: 0.45)),
                    color: kCyan.withValues(alpha: 0.07),
                  ),
                  child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.receipt_long_rounded,
                            color: kCyan, size: 13),
                        const SizedBox(width: 5),
                        Text(
                            '${source.isNotEmpty ? source : "Muslim"} #$number',
                            style: const TextStyle(
                                color: kCyan,
                                fontSize: 11,
                                fontWeight: FontWeight.bold)),
                      ]),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _fetchRandomHadith,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: kWhite54.withValues(alpha: 0.3)),
                    ),
                    child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.touch_app_rounded,
                              color: kWhite54, size: 14),
                          SizedBox(width: 4),
                          Text('Tap card',
                              style: TextStyle(
                                  color: kWhite54, fontSize: 11)),
                        ]),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: false,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/background.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  Container(color: kBg),
            ),
          ),
          Positioned.fill(
            child: Container(
                color: Colors.black.withValues(alpha: 0.6)),
          ),
          Positioned.fill(
            child: CustomPaint(
              painter: _GridPatternPainter(
                gridColor: kCyan.withValues(alpha: 0.04),
                lineColor: kPink.withValues(alpha: 0.02),
                spacing: 35,
              ),
            ),
          ),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 350),
            transitionBuilder: (child, anim) =>
                FadeTransition(opacity: anim, child: child),
            child: KeyedSubtree(
              key: ValueKey(_navIndex),
              child: _buildCurrentPage(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ── APP BAR (judul dinamis per tab) ────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    // Judul per tab: 0=Beranda (pakai logo), 1=Menu, 2=RAT, 3=Tools, 4=Tema
    final titles = <String>['', 'MENU', 'RAT', 'TOOLS', 'TEMA'];
    final showLogo = _navIndex == 0;

    return AppBar(
      backgroundColor: const Color(0xFFD32F2F),
      elevation: 0,
      iconTheme: const IconThemeData(color: kWhite),
      centerTitle: true,
      titleSpacing: 0,
      leading: Builder(
        builder: (context) => IconButton(
          icon: const Icon(Icons.menu, color: kWhite),
          onPressed: () {
            Scaffold.of(context).openDrawer();
          },
        ),
      ),
      title: showLogo
          ? Image.asset(
              'assets/images/reze.png',
              height: 40,
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) {
                return const Text(
                  'NEBULA',
                  style: TextStyle(
                    color: kWhite,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    letterSpacing: 2,
                  ),
                );
              },
            )
          : Text(
              titles[_navIndex],
              style: const TextStyle(
                color: kWhite,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                fontSize: 18,
                letterSpacing: 3,
              ),
            ),
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 8),
          child: _buildWeatherIndicator(),
        ),
        GestureDetector(
          onTap: () =>
              Navigator.push(context, _slideRoute(const ContactPage())),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child:
                Icon(Icons.headset_mic_outlined, color: kWhite, size: 24),
          ),
        ),
        IconButton(
          icon: const Icon(Icons.rocket_launch_rounded,
              color: kWhite, size: 22),
          onPressed: () {},
        ),
        IconButton(
          icon: const Icon(Icons.shield_rounded, color: kWhite, size: 22),
          onPressed: () {},
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _buildWeatherIndicator() {
    if (_weatherLoading) {
      return Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: kWhite.withValues(alpha: 0.05),
          border: Border.all(color: kBorder.withValues(alpha: 0.3)),
        ),
        child: const Padding(
          padding: EdgeInsets.all(10),
          child: CircularProgressIndicator(color: kCyan, strokeWidth: 2),
        ),
      );
    }

    final weatherIcon =
        WeatherService.getWeatherIcon(_weatherMain, _weatherIsGood);
    final weatherColor =
        WeatherService.getWeatherColor(_weatherMain, _weatherIsGood);
    final tempText = '${_weatherTemp.round()}°C';
    final weatherLabel = _weatherIsGood ? 'Cerah' : 'Hujan';

    return GestureDetector(
      onTap: () {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: kCard,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            title: Row(
              children: [
                Icon(weatherIcon, color: weatherColor, size: 28),
                const SizedBox(width: 12),
                Text(
                  'Cuaca $_weatherCity',
                  style: const TextStyle(
                    color: kWhite,
                    fontFamily: 'Orbitron',
                    fontSize: 14,
                  ),
                ),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(weatherIcon, color: weatherColor, size: 64),
                const SizedBox(height: 12),
                Text(_weatherMain,
                    style: const TextStyle(
                        color: kWhite,
                        fontSize: 20,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(tempText,
                    style: TextStyle(
                        color: weatherColor,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron')),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: _weatherIsGood
                        ? kGreen.withValues(alpha: 0.2)
                        : Colors.red.withValues(alpha: 0.2),
                    border: Border.all(
                      color: _weatherIsGood
                          ? kGreen.withValues(alpha: 0.4)
                          : Colors.red.withValues(alpha: 0.4),
                    ),
                  ),
                  child: Text(
                    _weatherIsGood
                        ? '☀️ Cuaca Cerah'
                        : '🌧️ Cuaca Buruk',
                    style: TextStyle(
                      color: _weatherIsGood ? kGreen : Colors.red,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text('Lokasi: $_weatherCity',
                    style: const TextStyle(
                        color: kWhite54, fontSize: 12)),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Tutup',
                    style: TextStyle(color: kWhite54)),
              ),
            ],
          ),
        );
      },
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: _weatherIsGood
                ? kGreen.withValues(alpha: 0.3)
                : Colors.red.withValues(alpha: 0.3),
          ),
          color: _weatherIsGood
              ? kGreen.withValues(alpha: 0.1)
              : Colors.red.withValues(alpha: 0.1),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 500),
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _weatherIsGood ? kGreen : Colors.red,
                boxShadow: [
                  BoxShadow(
                    color: (_weatherIsGood ? kGreen : Colors.red)
                        .withValues(alpha: 0.4),
                    blurRadius: 8,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Center(
                child: Icon(weatherIcon, color: Colors.white, size: 18),
              ),
            ),
            const SizedBox(width: 4),
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  weatherLabel,
                  style: TextStyle(
                    color: _weatherIsGood ? kGreen : Colors.red,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  tempText,
                  style: const TextStyle(
                    color: kWhite,
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── BOTTOM NAVIGATION ─────────────────────────────────────────────────
  Widget _buildBottomNav() {
    final items = [
      const _NavItem(icon: Icons.home_rounded, label: 'BERANDA'),
      const _NavItem(icon: Icons.grid_view_rounded, label: 'MENU'),
      const _NavItem(icon: Icons.memory_rounded, label: 'RAT'),
      const _NavItem(icon: Icons.settings_rounded, label: 'TOOLS'),
      const _NavItem(icon: Icons.palette_rounded, label: 'TEMA'),
    ];

    const Color bgCream = Color(0xFFFDEBD0);
    const Color activeYellow = Color(0xFFFFD600);
    const Color inactiveColor = Color(0xFF333333);
    const Color borderBlack = Colors.black;

    return Container(
      margin: const EdgeInsets.only(bottom: 12, left: 10, right: 10),
      height: 100,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.bottomCenter,
        children: [
          Container(
            height: 75,
            decoration: BoxDecoration(
              color: bgCream,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: borderBlack, width: 3),
              boxShadow: const [
                BoxShadow(
                  color: borderBlack,
                  offset: Offset(3, 4),
                  blurRadius: 0,
                  spreadRadius: 0,
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: List.generate(items.length, (i) {
                final isActive = _navIndex == i;

                return Expanded(
                  child: GestureDetector(
                    onTap: () => _onNavTap(i),
                    behavior: HitTestBehavior.opaque,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      curve: Curves.easeOutBack,
                      transform: isActive
                          ? (Matrix4.identity()..translate(0.0, -25.0))
                          : Matrix4.identity(),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isActive
                                  ? activeYellow
                                  : Colors.transparent,
                              border: isActive
                                  ? Border.all(
                                      color: borderBlack, width: 3)
                                  : null,
                              boxShadow: isActive
                                  ? const [
                                      BoxShadow(
                                        color: borderBlack,
                                        offset: Offset(3, 3),
                                        blurRadius: 0,
                                      ),
                                    ]
                                  : [],
                            ),
                            child: Icon(
                              items[i].icon,
                              color:
                                  isActive ? borderBlack : inactiveColor,
                              size: isActive ? 28 : 26,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            items[i].label,
                            style: TextStyle(
                              color:
                                  isActive ? borderBlack : inactiveColor,
                              fontSize: 10,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Comic Sans MS',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kBg,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        children: [
          Container(
            height: 240,
            color: Colors.black,
            child: Stack(
              children: [
                if (_menuVideoCtrl != null &&
                    _menuVideoCtrl!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoCtrl!.value.size.width,
                        height: _menuVideoCtrl!.value.size.height,
                        child: VideoPlayer(_menuVideoCtrl!),
                      ),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withValues(alpha: 0.3),
                        Colors.black.withValues(alpha: 0.85)
                      ],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: kCyan.withValues(alpha: 0.6),
                                width: 2.5),
                            boxShadow: [
                              BoxShadow(
                                  color:
                                      kCyan.withValues(alpha: 0.3),
                                  blurRadius: 14,
                                  spreadRadius: 2)
                            ],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!,
                                    fit: BoxFit.cover)
                                : const Icon(
                                    FontAwesomeIcons.userAstronaut,
                                    size: 38,
                                    color: kWhite),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(username,
                            style: const TextStyle(
                                color: kWhite,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron')),
                        Text(role.toUpperCase(),
                            style: const TextStyle(
                                color: kCyan,
                                fontSize: 12,
                                letterSpacing: 2)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: kBg,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  if (role == 'reseller')
                    _buildDrawerItem(
                        icon: Icons.storefront_rounded,
                        label: 'Seller Page',
                        onTap: () => _onDrawerNav(1)),
                  if (role == 'admin')
                    _buildDrawerItem(
                        icon: Icons.admin_panel_settings_rounded,
                        label: 'Admin Page',
                        onTap: () => _onDrawerNav(2)),
                  if (role == 'owner')
                    _buildDrawerItem(
                        icon: Icons.workspace_premium_rounded,
                        label: 'Owner Page',
                        onTap: () => _onDrawerNav(3)),
                  _buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          _slideRoute(RiwayatPage(
                              sessionKey: sessionKey, role: role))).then(
                          (_) {
                        if (mounted && _newsPageCtrl.hasClients) {
                          setState(() {
                            _currentNewsPage = 0.0;
                            _newsPageViewKey++;
                          });
                          _newsPageCtrl.jumpToPage(0);
                        }
                      });
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(
                            username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'Keluar',
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(
                              builder: (_) => const LoginPage()),
                          (_) => false);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout
            ? Colors.red.withValues(alpha: 0.08)
            : kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isLogout
                ? Colors.red.withValues(alpha: 0.3)
                : kBorder.withValues(alpha: 0.4)),
      ),
      child: ListTile(
        leading:
            Icon(icon, color: isLogout ? Colors.redAccent : kCyan, size: 20),
        title: Text(label,
            style: TextStyle(
                color: isLogout ? Colors.redAccent : kWhite,
                fontWeight: FontWeight.w600,
                fontSize: 14)),
        trailing: const Icon(Icons.arrow_forward_ios_rounded,
            color: kWhite24, size: 13),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }
}

// ─── Top-level helper widgets ─────────────────────────────────────────────────

Widget _buildVpsBox({
  required String title,
  required String ram,
  required String cpu,
}) {
  return Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.black, width: 2),
      boxShadow: [
        BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 4,
            offset: const Offset(2, 2))
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.storage_rounded, color: Colors.blue, size: 18),
            const SizedBox(width: 6),
            Text(title,
                style: const TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 12)),
          ],
        ),
        const SizedBox(height: 6),
        Text('RAM: $ram',
            style: const TextStyle(
                color: Colors.black87,
                fontSize: 10,
                fontWeight: FontWeight.w600)),
        Text('CPU: $cpu',
            style: const TextStyle(
                color: Colors.black87,
                fontSize: 10,
                fontWeight: FontWeight.w600)),
      ],
    ),
  );
}

class _buildVpsBoxStatic extends StatelessWidget {
  final String title;
  final String ram;
  final String cpu;
  const _buildVpsBoxStatic({
    required this.title,
    required this.ram,
    required this.cpu,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.black, width: 2),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 4,
              offset: const Offset(2, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.storage_rounded,
                  color: Colors.blue, size: 18),
              const SizedBox(width: 6),
              Text(title,
                  style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 12)),
            ],
          ),
          const SizedBox(height: 6),
          Text('RAM: $ram',
              style: const TextStyle(
                  color: Colors.black87,
                  fontSize: 10,
                  fontWeight: FontWeight.w600)),
          Text('CPU: $cpu',
              style: const TextStyle(
                  color: Colors.black87,
                  fontSize: 10,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

Widget _buildComicStatItem({
  required IconData icon,
  required Color color,
  required String value,
  required String label,
  Widget? extraWidget,
}) {
  return Column(
    children: [
      Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              border: Border.all(color: Colors.black, width: 3),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.4),
                    blurRadius: 6,
                    offset: const Offset(2, 2))
              ],
            ),
            child: Center(
              child: Icon(icon, color: color, size: 28),
            ),
          ),
          if (extraWidget != null) extraWidget,
        ],
      ),
      const SizedBox(height: 8),
      Text(
        value,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 18,
          fontFamily: 'Comic Sans MS',
          shadows: [
            Shadow(
                color: Colors.black, blurRadius: 4, offset: Offset(1, 1))
          ],
        ),
      ),
      Text(
        label,
        style: const TextStyle(
          color: Colors.white70,
          fontSize: 10,
          fontWeight: FontWeight.bold,
          shadows: [
            Shadow(
                color: Colors.black, blurRadius: 4, offset: Offset(1, 1))
          ],
        ),
        textAlign: TextAlign.center,
      ),
    ],
  );
}

// ─── Quick Action Data ─────────────────────────────────────────────────────────
class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final Color glowColor;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.glowColor,
    required this.onTap,
  });
}

// ─── Slide Route ──────────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 350),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
                begin: const Offset(1, 0), end: Offset.zero)
            .animate(CurvedAnimation(
                parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );

// ─── NewsMedia ────────────────────────────────────────────────────────────────
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;

  bool _isVideo(String url) =>
      url.endsWith('.mp4') ||
      url.endsWith('.webm') ||
      url.endsWith('.mov') ||
      url.endsWith('.mkv');

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }

  @override
  void dispose() {
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl != null && _ctrl!.value.isInitialized) {
        return AspectRatio(
            aspectRatio: _ctrl!.value.aspectRatio,
            child: VideoPlayer(_ctrl!));
      }
      return const Center(
          child: CircularProgressIndicator(color: kCyan, strokeWidth: 2));
    }
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
          color: kCard,
          child: const Icon(Icons.error_rounded, color: kWhite24)),
    );
  }
}