// ignore_for_file: use_build_context_synchronously, deprecated_member_use, unused_field, unused_element

import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// ════════════════════════════════════════════════════════════════════════════
//  PALETTE — biru cerah di atas hitam tipis (selaras dengan home_page.dart)
// ════════════════════════════════════════════════════════════════════════════
const String _font = "Rajdhani";
const Color _bg              = Color(0xFF05060B);
const Color _cardBlack       = Color(0xFF0B0E16);
const Color _cardBlackDeep   = Color(0xFF07090F);
const Color _accentBlue      = Color(0xFF2196F3);
const Color _accentBlueGlow  = Color(0xFF60A5FA);
const Color _accentDeep      = Color(0xFF1E40AF);
const Color _greenLive       = Color(0xFF22C55E);
const Color _yellowSoft      = Color(0xFFEAB308);

// Endpoint untuk mengambil daftar grup yang sudah di-join oleh sender
// private milik user. Sesuaikan path ini bila server menggunakan path lain.
const String _kGroupListPath = "/api/whatsapp/groupList";

// ════════════════════════════════════════════════════════════════════════════
class GroupBugPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;

  const GroupBugPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<GroupBugPage> createState() => _GroupBugPageState();
}

class _GroupBugPageState extends State<GroupBugPage>
    with TickerProviderStateMixin {
  // ── Controllers ──────────────────────────────────────────────────────────
  final linkGroupController = TextEditingController();
  static const String baseUrl = "http://angelacantik.pteroq.biz.id:3202";

  // ── Video banner ─────────────────────────────────────────────────────────
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;

  // ── Avatar floating ──────────────────────────────────────────────────────
  late AnimationController _avatarAnimController;
  late Animation<double> _avatarFloatAnim;

  // ── Stagger entrance ─────────────────────────────────────────────────────
  late AnimationController _staggerController;
  late Animation<double> _f1, _f2, _f3, _f4, _f5, _f6;
  late Animation<Offset>  _s1, _s2, _s3, _s4, _s5, _s6;

  // ── State ────────────────────────────────────────────────────────────────
  bool _isSending = false;
  bool _linkValid = false;

  // Sender info (auto Private — tidak ada pilihan global)
  int  _privateSenderCount = 0;
  bool _senderLoading = true;

  // List Group milik sender private
  List<dynamic> _privateGroups = [];
  bool _groupsLoading = true;
  Map<String, dynamic>? _selectedGroup;

  @override
  void initState() {
    super.initState();
    _initVideo();
    _initAnimations();
    _staggerController.forward();
    _fetchSenderCounts();
    _fetchPrivateGroups();
    linkGroupController.addListener(() {
      final v = _isValidGroupLink(linkGroupController.text.trim());
      if (v != _linkValid && mounted) setState(() => _linkValid = v);
    });
  }

  void _initVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _videoInitialized = true);
          _videoController.setLooping(true);
          _videoController.setVolume(0.0); // banner di-mute (tanpa suara)
          _videoController.play();
          _videoController.addListener(_keepVideoAlive);
        }
      }).catchError((e) => debugPrint("Video error: $e"));
  }

  // Mencegah video berhenti waktu user ngetik di TextField.
  void _keepVideoAlive() {
    if (!mounted) return;
    final v = _videoController.value;
    if (!v.isInitialized || v.hasError) return;
    if (!v.isPlaying) {
      _videoController.play();
    }
    // Pastikan video tetap silent.
    if (v.volume != 0.0) {
      _videoController.setVolume(0.0);
    }
  }

  void _initAnimations() {
    _avatarAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _avatarFloatAnim = Tween<double>(begin: -3.0, end: 3.0).animate(
      CurvedAnimation(parent: _avatarAnimController, curve: Curves.easeInOut),
    );

    _staggerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    Animation<double> cf(double a, double b) => CurvedAnimation(
        parent: _staggerController,
        curve: Interval(a, b, curve: Curves.easeOut));
    Animation<Offset> cs(double a, double b) => Tween<Offset>(
          begin: const Offset(0, 0.18),
          end: Offset.zero,
        ).animate(CurvedAnimation(
            parent: _staggerController,
            curve: Interval(a, b, curve: Curves.easeOutCubic)));

    _f1 = cf(0.00, 0.30); _s1 = cs(0.00, 0.30); // TopBar
    _f2 = cf(0.08, 0.38); _s2 = cs(0.08, 0.38); // Profile Card
    _f3 = cf(0.16, 0.46); _s3 = cs(0.16, 0.46); // Video Banner
    _f4 = cf(0.24, 0.54); _s4 = cs(0.24, 0.54); // 3 Stats
    _f5 = cf(0.32, 0.62); _s5 = cs(0.32, 0.62); // Input Link + List Group
    _f6 = cf(0.50, 0.85); _s6 = cs(0.50, 0.85); // Send Button
  }

  // ── Fetch jumlah sender private ────────────────────────────────────────
  Future<void> _fetchSenderCounts() async {
    if (!mounted) return;
    setState(() => _senderLoading = true);
    try {
      final res = await http
          .get(Uri.parse(
              "http://panel-icxninh.ryuuuprv.my.id:2002/api/whatsapp/mySender?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          final conn = data['connections'] ?? {};
          final privList = (conn['private'] as List?) ?? [];
          setState(() {
            _privateSenderCount = privList.length;
            _senderLoading      = false;
          });
        } else {
          if (mounted) setState(() => _senderLoading = false);
        }
      } else {
        if (mounted) setState(() => _senderLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _senderLoading = false);
    }
  }

  // ── Fetch List Group yang di-join oleh private sender ──────────────────
  Future<void> _fetchPrivateGroups() async {
    if (!mounted) return;
    setState(() => _groupsLoading = true);
    try {
      final res = await http
          .get(Uri.parse(
              "http://panel-icxninh.ryuuuprv.my.id:2002$_kGroupListPath?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 12));

      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);

        // Toleran terhadap beberapa bentuk respons:
        //   { valid: true, groups: [...] }
        //   { groups: [...] }
        //   [...]
        List parsed = [];
        if (body is List) {
          parsed = body;
        } else if (body is Map) {
          if (body['groups'] is List) {
            parsed = body['groups'] as List;
          } else if (body['data'] is List) {
            parsed = body['data'] as List;
          } else if (body['list'] is List) {
            parsed = body['list'] as List;
          }
        }

        if (mounted) {
          setState(() {
            _privateGroups = parsed;
            _groupsLoading = false;
            // Bila grup terpilih sudah tidak ada di list baru, lepas pilihan.
            if (_selectedGroup != null) {
              final stillThere = parsed.any((g) =>
                  _groupKey(g) == _groupKey(_selectedGroup));
              if (!stillThere) _selectedGroup = null;
            }
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _privateGroups = [];
            _groupsLoading = false;
          });
        }
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _privateGroups = [];
          _groupsLoading = false;
        });
      }
    }
  }

  // Helper untuk membandingkan grup berdasarkan id atau invite link.
  String _groupKey(dynamic g) {
    if (g == null) return '';
    final id = (g['id'] ?? g['groupId'] ?? '').toString();
    if (id.isNotEmpty) return id;
    return (g['inviteLink'] ?? g['link'] ?? g['subject'] ?? '').toString();
  }

  String? _groupInviteLink(dynamic g) {
    if (g == null) return null;
    String? link;
    if (g['inviteLink'] is String && (g['inviteLink'] as String).isNotEmpty) {
      link = g['inviteLink'] as String;
    } else if (g['link'] is String && (g['link'] as String).isNotEmpty) {
      link = g['link'] as String;
    } else if (g['inviteCode'] is String &&
        (g['inviteCode'] as String).isNotEmpty) {
      link = "https://chat.whatsapp.com/${g['inviteCode']}";
    }
    return link;
  }

  bool _isValidGroupLink(String input) =>
      RegExp(r'https://chat\.whatsapp\.com/[a-zA-Z0-9]{22}').hasMatch(input);

  // ── Send group bug — auto private, prioritas grup terpilih ─────────────
  Future<void> _sendGroupBug() async {
    if (_isSending) return;
    setState(() => _isSending = true);

    final key = widget.sessionKey;

    // Tentukan link grup yang akan dipakai:
    //   1) Grup yang dipilih dari "List Group" (prioritas)
    //   2) Link manual dari TextField
    String linkGroup = "";
    if (_selectedGroup != null) {
      final picked = _groupInviteLink(_selectedGroup);
      if (picked != null) linkGroup = picked.trim();
    }
    if (linkGroup.isEmpty) {
      linkGroup = linkGroupController.text.trim();
    }

    if (linkGroup.isEmpty || !_isValidGroupLink(linkGroup)) {
      _showAlert(
        "❌ Target Belum Siap",
        "Pilih salah satu grup pada \"List Group\" "
        "atau tempelkan link grup WhatsApp yang valid.\n"
        "(https://chat.whatsapp.com/xxxx)",
      );
      setState(() => _isSending = false);
      return;
    }

    try {
      // senderType DIPAKSA = private (sesuai instruksi: auto private)
      final url =
          "http://panel-icxninh.ryuuuprv.my.id:2002/api/whatsapp/groupBug?key=$key&linkGroup=$linkGroup&senderType=private";
      final res  = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      if (data["valid"] == false) {
        _showAlert("❌ Failed",
            data["message"]?.toString() ?? "Gagal mengirim group bug.");
      } else {
        _showSuccessPopup(linkGroup, data is Map<String, dynamic>
            ? data
            : <String, dynamic>{"data": data});
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showSuccessPopup(String linkGroup, Map<String, dynamic> data) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _GroupSuccessDialog(linkGroup: linkGroup, data: data),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _cardBlack.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: _accentBlue, width: 1),
        ),
        title: Text(title,
            style: const TextStyle(
                fontFamily: _font,
                color: Colors.white,
                fontWeight: FontWeight.bold)),
        content: Text(msg,
            style: const TextStyle(fontFamily: _font, color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK",
                style: TextStyle(fontFamily: _font, color: _accentBlue)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _videoController.removeListener(_keepVideoAlive);
    _videoController.dispose();
    _avatarAnimController.dispose();
    _staggerController.dispose();
    linkGroupController.dispose();
    super.dispose();
  }

  // ════════════════════════════════════════════════════════════════════════
  //  BUILD
  // ════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    // Role gate (sama seperti versi lama)
    if (!["member", "Resseler", "VIP", "TK", "owner"]
        .contains(widget.role.toLowerCase())) {
      return Scaffold(
        backgroundColor: _bg,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock, color: Colors.redAccent, size: 60),
              const SizedBox(height: 20),
              const Text("ACCESS DENIED",
                  style: TextStyle(
                      fontFamily: _font,
                      color: Colors.redAccent,
                      fontSize: 22,
                      fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Text("Fitur ini hanya untuk VIP & Owner",
                  style: TextStyle(
                      fontFamily: _font,
                      color: Colors.white.withOpacity(0.6),
                      fontSize: 14)),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          // ── Soft glow latar ────────────────────────────────────
          Positioned(
              top: -120, left: -120, child: _glow(280, _accentBlue, 0.10)),
          Positioned(
              bottom: -100, right: -100,
              child: _glow(260, _accentBlueGlow, 0.08)),

          // ── Pola segi enam besar di pojok kanan atas ──────────
          Positioned(
            top: 0,
            right: 0,
            child: IgnorePointer(
              child: SizedBox(
                width: 220,
                height: 230,
                child: _HexPattern(corner: _HexCornerPos.topRight),
              ),
            ),
          ),
          // ── Pola segi enam besar di pojok kiri bawah ──────────
          Positioned(
            bottom: 0,
            left: 0,
            child: IgnorePointer(
              child: SizedBox(
                width: 220,
                height: 230,
                child: _HexPattern(corner: _HexCornerPos.bottomLeft),
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                FadeTransition(
                  opacity: _f1,
                  child: SlideTransition(position: _s1, child: _buildTopBar()),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(18, 8, 18, 30),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        FadeTransition(
                          opacity: _f2,
                          child: SlideTransition(
                              position: _s2, child: _buildProfileBanner()),
                        ),
                        const SizedBox(height: 18),
                        FadeTransition(
                          opacity: _f3,
                          child: SlideTransition(
                              position: _s3, child: _buildVideoBanner()),
                        ),
                        const SizedBox(height: 18),
                        FadeTransition(
                          opacity: _f4,
                          child: SlideTransition(
                              position: _s4, child: _buildStatsRow()),
                        ),
                        const SizedBox(height: 22),
                        FadeTransition(
                          opacity: _f5,
                          child: SlideTransition(
                              position: _s5, child: _buildInputLinkArea()),
                        ),
                        const SizedBox(height: 18),
                        FadeTransition(
                          opacity: _f5,
                          child: SlideTransition(
                              position: _s5, child: _buildGroupListBox()),
                        ),
                        const SizedBox(height: 24),
                        FadeTransition(
                          opacity: _f6,
                          child: SlideTransition(
                              position: _s6, child: _buildSendButton()),
                        ),
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Widget _glow(double size, Color color, double opacity) =>
      IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [
              color.withOpacity(opacity),
              Colors.transparent,
            ]),
          ),
        ),
      );

  // ════════════════════════════════════════════════════════════════════════
  //  TOP BAR — kotak shield + VOID BUG, label biru V6.0.0
  //  (TANPA tombol back — sesuai instruksi)
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: _cardBlack,
                  borderRadius: BorderRadius.circular(11),
                  border: Border.all(
                      color: _accentBlue.withOpacity(0.45), width: 1.2),
                  boxShadow: [
                    BoxShadow(
                      color: _accentBlue.withOpacity(0.22),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Icon(Icons.shield_rounded,
                    color: _accentBlue, size: 20),
              ),
              const SizedBox(width: 11),
              const Text(
                "BLUE BUG",
                style: TextStyle(
                  fontFamily: _font,
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 17,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_accentBlue, _accentDeep],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(9),
              boxShadow: [
                BoxShadow(
                  color: _accentBlue.withOpacity(0.55),
                  blurRadius: 12,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: const Text(
              "V6.0.0",
              style: TextStyle(
                fontFamily: _font,
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 12,
                letterSpacing: 1.3,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  PROFILE BANNER — sama dengan home_page.dart
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildProfileBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(16, 16, 12, 16),
      decoration: BoxDecoration(
        color: _cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 22,
            offset: const Offset(0, 12),
          ),
          BoxShadow(
            color: _accentBlue.withOpacity(0.12),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          AnimatedBuilder(
            animation: _avatarAnimController,
            builder: (ctx, child) => Transform.translate(
              offset: Offset(0, _avatarFloatAnim.value),
              child: child,
            ),
            child: Container(
              padding: const EdgeInsets.all(2.5),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: _accentBlue, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: _accentBlue.withOpacity(0.55),
                    blurRadius: 14,
                  ),
                ],
              ),
              child: const CircleAvatar(
                radius: 26,
                backgroundImage: AssetImage('assets/images/icon.jpg'),
                backgroundColor: Colors.black,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: _font,
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.role.toUpperCase(),
                  style: const TextStyle(
                    fontFamily: _font,
                    color: _accentBlueGlow,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: _accentBlue.withOpacity(0.10),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: _accentBlue.withOpacity(0.40)),
              boxShadow: [
                BoxShadow(
                  color: _accentBlue.withOpacity(0.18),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.access_time_rounded,
                    color: _accentBlue, size: 13),
                const SizedBox(width: 5),
                Text(
                  widget.expiredDate,
                  style: const TextStyle(
                    fontFamily: _font,
                    color: _accentBlue,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  VIDEO BANNER — assets/videos/banner.mp4 (DI-MUTE — tanpa suara)
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 165,
      decoration: BoxDecoration(
        color: _cardBlackDeep,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: _accentBlue.withOpacity(0.10),
            blurRadius: 18,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              )
            else
              Container(
                color: _cardBlackDeep,
                child: const Center(
                  child: SizedBox(
                    width: 28,
                    height: 28,
                    child: CircularProgressIndicator(
                        color: _accentBlue, strokeWidth: 2),
                  ),
                ),
              ),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.45),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  3 STATS — Group / Stealth / Fast Send
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildStatsRow() {
    final totalSender = _privateSenderCount;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
      decoration: BoxDecoration(
        color: _cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: _accentBlue.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Expanded(
            child: _StatItem(
              icon: Icons.groups_2_rounded,
              iconColor: Color(0xFFFF7A00),
              title: "Group Mode",
              subtitle: "Mass Target",
            ),
          ),
          _ThinDivider(),
          Expanded(
            child: _StatItem(
              icon: FontAwesomeIcons.userShield,
              iconColor: _greenLive,
              title: "Sender Aktif",
              subtitle: "$totalSender Tersedia",
              valueBig: "$totalSender",
            ),
          ),
          _ThinDivider(),
          const Expanded(
            child: _StatItem(
              icon: Icons.flash_on_rounded,
              iconColor: _yellowSoft,
              title: "Fast Send",
              subtitle: "Super Cepat",
            ),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  INPUT LINK — link grup WhatsApp + indikator valid
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildInputLinkArea() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      decoration: BoxDecoration(
        color: _cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: _accentBlue.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: _accentBlue.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: _accentBlue.withOpacity(0.40)),
                ),
                child: const Icon(Icons.link_rounded,
                    color: _accentBlue, size: 16),
              ),
              const SizedBox(width: 11),
              const Text(
                "Masukan Link Grup",
                style: TextStyle(
                  fontFamily: _font,
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.0,
                ),
              ),
              const Spacer(),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                child: _linkValid
                    ? Container(
                        key: const ValueKey('valid'),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 9, vertical: 4),
                        decoration: BoxDecoration(
                          color: _greenLive.withOpacity(0.14),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                              color: _greenLive.withOpacity(0.45)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: const [
                            Icon(Icons.check_circle_rounded,
                                color: _greenLive, size: 12),
                            SizedBox(width: 4),
                            Text(
                              "Valid",
                              style: TextStyle(
                                fontFamily: _font,
                                color: _greenLive,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.4,
                              ),
                            ),
                          ],
                        ),
                      )
                    : const SizedBox.shrink(),
              ),
            ],
          ),
          const SizedBox(height: 14),
          // Input
          Container(
            decoration: BoxDecoration(
              color: _cardBlackDeep,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(
                  color: _linkValid
                      ? _greenLive.withOpacity(0.50)
                      : _accentBlue.withOpacity(0.30),
                  width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: (_linkValid ? _greenLive : _accentBlue)
                      .withOpacity(0.10),
                  blurRadius: 10,
                ),
              ],
            ),
            padding: const EdgeInsets.fromLTRB(12, 4, 8, 4),
            child: Row(
              children: [
                Icon(FontAwesomeIcons.whatsapp,
                    color:
                        _linkValid ? _greenLive : _accentBlueGlow, size: 18),
                const SizedBox(width: 10),
                Container(
                  width: 1,
                  height: 26,
                  color: Colors.white.withOpacity(0.10),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: linkGroupController,
                    keyboardType: TextInputType.url,
                    style: const TextStyle(
                      fontFamily: _font,
                      color: Colors.white,
                      fontSize: 14,
                      letterSpacing: 0.3,
                    ),
                    decoration: InputDecoration(
                      hintText: "https://chat.whatsapp.com/...",
                      hintStyle: TextStyle(
                        fontFamily: _font,
                        color: Colors.white.withOpacity(0.28),
                        fontSize: 12.5,
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
                if (linkGroupController.text.isNotEmpty)
                  GestureDetector(
                    onTap: () {
                      linkGroupController.clear();
                      setState(() => _linkValid = false);
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: Icon(Icons.close_rounded,
                          color: Colors.white.withOpacity(0.40), size: 18),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Text(
            "Tempelkan link undangan grup WhatsApp di atas",
            style: TextStyle(
              fontFamily: _font,
              color: Colors.white.withOpacity(0.35),
              fontSize: 10.5,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  LIST GROUP — daftar grup yang sudah di-join sender private
  //  (mengganti area "Pilih Sender" yang lama)
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildGroupListBox() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
      decoration: BoxDecoration(
        color: _cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: _accentBlue.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header: ikon "orang banyak" + judul List Group + tombol refresh
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: _accentBlue.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: _accentBlue.withOpacity(0.40)),
                ),
                child: const Icon(Icons.groups_rounded,
                    color: _accentBlue, size: 18),
              ),
              const SizedBox(width: 11),
              const Text(
                "List Group",
                style: TextStyle(
                  fontFamily: _font,
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.0,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: _fetchPrivateGroups,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: _greenLive.withOpacity(0.14),
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(color: _greenLive.withOpacity(0.45)),
                  ),
                  child: _groupsLoading
                      ? const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                              color: _greenLive, strokeWidth: 1.5),
                        )
                      : Text(
                          "${_privateGroups.length} Group",
                          style: const TextStyle(
                            fontFamily: _font,
                            color: _greenLive,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.4,
                          ),
                        ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            "Grup yang sudah dimasuki nomor Sender Private milikmu.",
            style: TextStyle(
              fontFamily: _font,
              color: Colors.white.withOpacity(0.40),
              fontSize: 10.5,
              letterSpacing: 0.3,
            ),
          ),
          const SizedBox(height: 14),
          // Konten list
          if (_groupsLoading)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 26),
              child: Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                      color: _accentBlue, strokeWidth: 2),
                ),
              ),
            )
          else if (_privateGroups.isEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 14),
              decoration: BoxDecoration(
                color: _cardBlackDeep,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: Colors.white.withOpacity(0.08)),
              ),
              child: Column(
                children: [
                  Icon(Icons.search_off_rounded,
                      color: Colors.white.withOpacity(0.30), size: 32),
                  const SizedBox(height: 8),
                  Text(
                    "Belum ada grup terdeteksi.\n"
                    "Pastikan Sender Private sudah join ke grup target.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: _font,
                      color: Colors.white.withOpacity(0.55),
                      fontSize: 11.5,
                      letterSpacing: 0.3,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            )
          else
            Column(
              children: [
                for (final g in _privateGroups)
                  _GroupCard(
                    group     : g is Map ? Map<String, dynamic>.from(g)
                                         : <String, dynamic>{},
                    selected  : _groupKey(g) == _groupKey(_selectedGroup),
                    onSelect  : () {
                      final mp = g is Map
                          ? Map<String, dynamic>.from(g)
                          : <String, dynamic>{};
                      // Lock target ke grup yang dipilih.
                      setState(() => _selectedGroup = mp);
                      // Bila grup punya invite link, isi otomatis ke TextField
                      // supaya user juga bisa mereview link target.
                      final lk = _groupInviteLink(mp);
                      if (lk != null && lk.isNotEmpty) {
                        linkGroupController.text = lk;
                        _linkValid = _isValidGroupLink(lk);
                      }
                    },
                  ),
              ],
            ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  SEND BUTTON — biru panjang + paper plane
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildSendButton() {
    return Container(
      width: double.infinity,
      height: 56,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        gradient: const LinearGradient(
          colors: [_accentBlueGlow, _accentBlue, _accentDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: _accentBlue.withOpacity(0.55),
            blurRadius: 22,
            spreadRadius: 1,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(15),
          onTap: _isSending ? null : _sendGroupBug,
          child: Center(
            child: _isSending
                ? const SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(FontAwesomeIcons.paperPlane,
                          color: Colors.white, size: 17),
                      SizedBox(width: 12),
                      Text(
                        "SEND BUG",
                        style: TextStyle(
                          fontFamily: _font,
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2.5,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
//  GROUP CARD — banner panjang per-grup
//   - Kiri : ikon person
//   - Nama group
//   - Label kecil: jumlah anggota + ID grup
//   - Bawah : tombol panjang "Select Group" (icon + ) → lock target
// ════════════════════════════════════════════════════════════════════════════
class _GroupCard extends StatelessWidget {
  final Map<String, dynamic> group;
  final bool selected;
  final VoidCallback onSelect;
  const _GroupCard({
    required this.group,
    required this.selected,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final String name = (group['subject'] ??
            group['name'] ??
            group['groupName'] ??
            '-')
        .toString();

    final String idRaw = (group['id'] ??
            group['groupId'] ??
            group['inviteCode'] ??
            '-')
        .toString();

    // Trim ID supaya enak dibaca (ambil 12 char depan + ...)
    final String idShort = idRaw.length > 18
        ? '${idRaw.substring(0, 14)}...'
        : idRaw;

    final String members = (group['participants'] ??
            group['memberCount'] ??
            group['participantsCount'] ??
            group['members'] ??
            '-')
        .toString();

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      decoration: BoxDecoration(
        color: _cardBlackDeep,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: selected
              ? _accentBlueGlow
              : Colors.white.withOpacity(0.10),
          width: selected ? 1.4 : 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.45),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
          if (selected)
            BoxShadow(
              color: _accentBlue.withOpacity(0.30),
              blurRadius: 18,
            ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Baris atas: avatar + nama + label kecil ─────────────────
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Avatar (icon person)
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  color: _accentBlue.withOpacity(0.14),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _accentBlue.withOpacity(0.45)),
                  boxShadow: [
                    BoxShadow(
                      color: _accentBlue.withOpacity(0.20),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: const Icon(Icons.person_rounded,
                    color: _accentBlueGlow, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontFamily: _font,
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.4,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        // Label jumlah anggota
                        _smallLabel(
                          color: _greenLive,
                          leading: const Icon(
                            Icons.people_alt_rounded,
                            size: 10,
                            color: _greenLive,
                          ),
                          text: '$members Member',
                        ),
                        // Label ID grup
                        _smallLabel(
                          color: _accentBlueGlow,
                          leading: const Icon(
                            Icons.fingerprint_rounded,
                            size: 10,
                            color: _accentBlueGlow,
                          ),
                          text: idShort,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              if (selected)
                const Padding(
                  padding: EdgeInsets.only(left: 6),
                  child: Icon(Icons.verified_rounded,
                      color: _accentBlueGlow, size: 20),
                ),
            ],
          ),
          const SizedBox(height: 12),
          // ── Tombol panjang: Select Group ───────────────────────────
          SizedBox(
            width: double.infinity,
            height: 42,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(11),
                onTap: onSelect,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 240),
                  decoration: BoxDecoration(
                    gradient: selected
                        ? const LinearGradient(
                            colors: [_accentBlue, _accentDeep],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : null,
                    color: selected ? null : _cardBlack,
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(
                      color: selected
                          ? _accentBlueGlow
                          : _accentBlue.withOpacity(0.40),
                      width: 1.2,
                    ),
                    boxShadow: selected
                        ? [
                            BoxShadow(
                              color: _accentBlue.withOpacity(0.55),
                              blurRadius: 14,
                              offset: const Offset(0, 4),
                            ),
                          ]
                        : null,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        selected
                            ? Icons.check_circle_rounded
                            : Icons.add_circle_outline_rounded,
                        color: selected ? Colors.white : _accentBlueGlow,
                        size: 17,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        selected ? 'Selected' : 'Select Group',
                        style: TextStyle(
                          fontFamily: _font,
                          color: selected ? Colors.white : _accentBlueGlow,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _smallLabel({
    required Color color,
    required Widget leading,
    required String text,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(7),
        border: Border.all(color: color.withOpacity(0.45), width: 0.8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          leading,
          const SizedBox(width: 4),
          Text(
            text,
            style: TextStyle(
              fontFamily: _font,
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
//  STAT ITEM
// ════════════════════════════════════════════════════════════════════════════
class _StatItem extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final String? valueBig;

  const _StatItem({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    this.valueBig,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _cardBlackDeep,
            border: Border.all(color: iconColor.withOpacity(0.35), width: 1.2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.55),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
              BoxShadow(
                color: iconColor.withOpacity(0.30),
                blurRadius: 12,
              ),
            ],
          ),
          child: Center(child: Icon(icon, color: iconColor, size: 17)),
        ),
        const SizedBox(height: 9),
        if (valueBig != null) ...[
          Text(
            valueBig!,
            style: const TextStyle(
              fontFamily: _font,
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.4,
              height: 1.0,
            ),
          ),
          const SizedBox(height: 3),
        ],
        Text(
          title,
          style: const TextStyle(
            fontFamily: _font,
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          subtitle,
          style: TextStyle(
            fontFamily: _font,
            color: Colors.white.withOpacity(0.40),
            fontSize: 10,
            letterSpacing: 0.3,
          ),
        ),
      ],
    );
  }
}

class _ThinDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1,
      height: 56,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.transparent,
            Colors.white.withOpacity(0.18),
            Colors.transparent,
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
//  HEXAGON PATTERN — pola segi enam besar di pojok kanan atas & kiri bawah
// ════════════════════════════════════════════════════════════════════════════
enum _HexCornerPos { topRight, bottomLeft }

class _HexPattern extends StatelessWidget {
  final _HexCornerPos corner;
  const _HexPattern({required this.corner});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _HexPainter(corner: corner));
  }
}

class _HexPainter extends CustomPainter {
  final _HexCornerPos corner;
  _HexPainter({required this.corner});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1B2D5C).withOpacity(0.55)
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;

    final glow = Paint()
      ..color = const Color(0xFF1E3A8A).withOpacity(0.10)
      ..style = PaintingStyle.fill;

    const double r = 46;
    final double w = math.sqrt(3) * r;
    final double h = 2 * r;
    final double vSpacing = h * 0.75;

    final List<List<int>> cells = corner == _HexCornerPos.topRight
        ? [
            [0, 0],
            [1, 0],
            [0, 1],
            [-1, 1],
            [1, 1],
          ]
        : [
            [0, 0],
            [1, 0],
            [0, 1],
            [2, 1],
            [1, 1],
          ];

    for (final c in cells) {
      final col = c[0];
      final row = c[1];
      double cx;
      double cy;
      if (corner == _HexCornerPos.topRight) {
        cx = size.width - col * w - (row.isOdd ? w / 2 : 0);
        cy = row * vSpacing + r * 0.4;
      } else {
        cx = col * w + (row.isOdd ? w / 2 : 0);
        cy = size.height - row * vSpacing - r * 0.4;
      }
      _drawHex(canvas, Offset(cx, cy), r, paint, glow);
    }
  }

  void _drawHex(
      Canvas canvas, Offset center, double r, Paint stroke, Paint glow) {
    final path = Path();
    for (int i = 0; i < 6; i++) {
      final angle = math.pi / 3 * i - math.pi / 2;
      final x = center.dx + r * math.cos(angle);
      final y = center.dy + r * math.sin(angle);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();
    canvas.drawPath(path, glow);
    canvas.drawPath(path, stroke);
  }

  @override
  bool shouldRepaint(covariant _HexPainter oldDelegate) =>
      oldDelegate.corner != corner;
}

// ════════════════════════════════════════════════════════════════════════════
//  SUCCESS DIALOG — versi biru
// ════════════════════════════════════════════════════════════════════════════
class _GroupSuccessDialog extends StatefulWidget {
  final String linkGroup;
  final Map<String, dynamic> data;
  const _GroupSuccessDialog({required this.linkGroup, required this.data});

  @override
  State<_GroupSuccessDialog> createState() => _GroupSuccessDialogState();
}

class _GroupSuccessDialogState extends State<_GroupSuccessDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _scaleAnim = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final groupInfo = widget.data["groupInfo"];
    final success   = widget.data["success"] == true;
    final canSend   = widget.data["canSendMessage"] == true;

    return ScaleTransition(
      scale: _scaleAnim,
      child: Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: _cardBlack.withOpacity(0.92),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                    color: _accentBlue.withOpacity(0.55), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: _accentBlue.withOpacity(0.30),
                    blurRadius: 30,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _accentBlue.withOpacity(0.18),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.check_circle_outline,
                        color: _accentBlue, size: 54),
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    "GROUP ATTACK SUCCESS",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: _font,
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _accentBlue.withOpacity(0.25)),
                    ),
                    child: Column(
                      children: [
                        _row("Status", success ? "Sukses" : "Partial"),
                        _row("Can Send", canSend ? "Ya" : "Chat Dimatikan"),
                        if (groupInfo != null) ...[
                          _row("Nama Group",
                              groupInfo["subject"]?.toString() ?? "-"),
                          _row("Members",
                              groupInfo["participants"]?.toString() ?? "-"),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    height: 45,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _accentBlue.withOpacity(0.18),
                        side: const BorderSide(color: _accentBlue),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: const Text(
                        "DISMISS",
                        style: TextStyle(
                          fontFamily: _font,
                          color: _accentBlue,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _row(String label, String val) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          SizedBox(
            width: 110,
            child: Text(
              label,
              style: const TextStyle(
                  fontFamily: _font, color: Colors.white38, fontSize: 12),
            ),
          ),
          const Text(": ",
              style: TextStyle(color: Colors.white38, fontSize: 12)),
          Expanded(
            child: Text(
              val,
              style: const TextStyle(
                fontFamily: _font,
                color: _accentBlueGlow,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
