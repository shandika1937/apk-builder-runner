// ignore_for_file: use_build_context_synchronously, deprecated_member_use, unused_field, unused_element
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

import 'netrax_page.dart';

// ════════════════════════════════════════════════════════════════════════════
//  PALETTE — desain baru "biru cerah" di atas background hitam tipis
// ════════════════════════════════════════════════════════════════════════════
const String _font = "Rajdhani";
const Color _bg = Color(0xFF05060B);
const Color _cardBlack = Color(0xFF0B0E16);   // hitam tapi gak pekat
const Color _cardBlackDeep = Color(0xFF07090F);
const Color _accentBlue = Color(0xFF2196F3);  // biru cerah utama
const Color _accentBlueGlow = Color(0xFF60A5FA);
const Color _accentDeep = Color(0xFF1E40AF);
const Color _greenLive = Color(0xFF22C55E);   // titik hijau hidup
const Color _yellowSoft = Color(0xFFEAB308);

class AttackPage2 extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const AttackPage2({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage2> createState() => _AttackPage2State();
}

class _AttackPage2State extends State<AttackPage2>
    with TickerProviderStateMixin {
  final targetController = TextEditingController();
  static const String baseUrl = "http://angelacantik.pteroq.biz.id:3202";

  // ── Video Banner ───────────────────────────────────────────────────────
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;

  // ── Animasi avatar mengambang ──────────────────────────────────────────
  late AnimationController _avatarAnimController;
  late Animation<double> _avatarFloatAnim;

  // ── Animasi titik hijau hidup di kartu payload ─────────────────────────
  late AnimationController _liveDotController;

  // ── Stagger entrance animation ─────────────────────────────────────────
  late AnimationController _staggerController;
  late Animation<double> _fade1, _fade2, _fade3, _fade4, _fade5, _fade6, _fade7;
  late Animation<Offset> _slide1, _slide2, _slide3, _slide4, _slide5, _slide6, _slide7;

  // ── Payload selector scroll ────────────────────────────────────────────
  final ScrollController _payloadScrollCtrl = ScrollController();
  double _payloadScrollPos = 0;

  // ── State umum ─────────────────────────────────────────────────────────
  String selectedBugId = "";
  String _senderType = "global";
  bool _isSending = false;

  // ── Command parser state (input format: /bug_id <nomor>) ────────────────
  bool _showBugSuggest = false;     // true → list saran tampil di atas input
  String _typedBugQuery = "";       // teks setelah '/' sebelum spasi
  final FocusNode _inputFocus = FocusNode();

  // ── Country code detection ─────────────────────────────────────────────
  String _detectedDialCode = "";

  // ── Sender counts (dari server) ────────────────────────────────────────
  int _globalSenderCount = 0;
  int _privateSenderCount = 0;
  bool _senderLoading = true;

  // ── History log ────────────────────────────────────────────────────────
  final List<Map<String, String>> _historyLog = [];

  @override
  void initState() {
    super.initState();
    _setDefaultBug();
    _initializeVideo();
    _initializeAnimations();
    _staggerController.forward();
    _fetchSenderCounts();

    _payloadScrollCtrl.addListener(() {
      if (mounted) setState(() => _payloadScrollPos = _payloadScrollCtrl.offset);
    });

    targetController.addListener(_onTargetChanged);
    _inputFocus.addListener(() {
      // Sembunyikan saran kalau input kehilangan fokus
      if (!_inputFocus.hasFocus && _showBugSuggest && mounted) {
        setState(() => _showBugSuggest = false);
      }
    });
  }

  // Listener input — parse "/bug_id <nomor>" dan atur saran + bendera + bug terpilih.
  void _onTargetChanged() {
    if (!mounted) return;
    final txt = targetController.text;

    // Quick command: /history → buka riwayat
    if (txt.trim() == '/history') {
      targetController.clear();
      _showHistoryDialog();
      return;
    }

    if (!txt.startsWith('/')) {
      // Tidak ada prefix → sembunyikan saran, reset bendera
      if (_showBugSuggest || _detectedDialCode.isNotEmpty || _typedBugQuery.isNotEmpty) {
        setState(() {
          _showBugSuggest = false;
          _typedBugQuery = "";
          _detectedDialCode = "";
        });
      }
      return;
    }

    // Pisah bagian "bug" dan "nomor"
    final spaceIdx = txt.indexOf(' ');
    final String bugPart = spaceIdx == -1 ? txt.substring(1) : txt.substring(1, spaceIdx);
    final String numPart = spaceIdx == -1 ? '' : txt.substring(spaceIdx + 1);

    // Cocokkan dengan bug_id yang valid → kunci selectedBugId
    String? matchedId;
    for (final b in widget.listBug) {
      if (b['bug_id'].toString().toLowerCase() == bugPart.toLowerCase()) {
        matchedId = b['bug_id'].toString();
        break;
      }
    }

    // Deteksi kode negara dari bagian nomor
    final cleaned = numPart.replaceAll(RegExp(r'[^\d]'), '');
    final dial = _detectDialCode(cleaned);

    setState(() {
      _typedBugQuery = bugPart;
      // Saran tampil HANYA saat user masih ngetik bagian bug (belum spasi)
      _showBugSuggest = spaceIdx == -1;
      if (matchedId != null) selectedBugId = matchedId;
      _detectedDialCode = dial;
    });
  }

  // Filter bug_id sesuai apa yang sedang diketik setelah "/"
  List<Map<String, dynamic>> _filteredBugSuggestions() {
    final q = _typedBugQuery.toLowerCase();
    final all = widget.listBug.cast<Map<String, dynamic>>();
    if (q.isEmpty) return all;
    final starts = <Map<String, dynamic>>[];
    final contains = <Map<String, dynamic>>[];
    for (final b in all) {
      final id = b['bug_id'].toString().toLowerCase();
      if (id.startsWith(q)) {
        starts.add(b);
      } else if (id.contains(q)) {
        contains.add(b);
      }
    }
    return [...starts, ...contains];
  }

  // Saat user tap salah satu saran → isi otomatis dengan "/<bug_id> "
  void _selectBugFromSuggest(String bugId) {
    final newText = '/$bugId ';
    targetController.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: newText.length),
    );
    setState(() {
      selectedBugId = bugId;
      _typedBugQuery = bugId;
      _showBugSuggest = false;
    });
  }

  // ── Deteksi kode negara dari awalan nomor ────────────────────────────
  String _detectDialCode(String cleaned) {
    if (cleaned.isEmpty) return "";
    // Coba 3 → 2 → 1 digit
    for (final len in [3, 2, 1]) {
      if (cleaned.length >= len) {
        final code = cleaned.substring(0, len);
        if (_kFlagMap.containsKey(code)) return code;
      }
    }
    return "";
  }

  // Fetch jumlah sender global & private dari server
  static const String _senderApiUrl = "http://angelacantik.pteroq.biz.id:3202";

  Future<void> _fetchSenderCounts() async {
    if (!mounted) return;
    setState(() => _senderLoading = true);
    try {
      final res = await http.get(
        Uri.parse("$_senderApiUrl/api/whatsapp/mySender?key=${widget.sessionKey}"),
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          final connections = data['connections'] ?? {};
          setState(() {
            _globalSenderCount  = (connections['global']  as List?)?.length ?? 0;
            _privateSenderCount = (connections['private'] as List?)?.length ?? 0;
            _senderLoading = false;
          });
        } else {
          if (mounted) setState(() => _senderLoading = false);
        }
      } else {
        if (mounted) setState(() => _senderLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _senderLoading = false);
    }
  }

  // ── History Dialog ─────────────────────────────────────────────────────
  void _showHistoryDialog() {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 40),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            child: Container(
              constraints: const BoxConstraints(maxHeight: 480),
              decoration: BoxDecoration(
                color: _cardBlack.withOpacity(0.92),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _accentBlue.withOpacity(0.35), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: _accentBlue.withOpacity(0.18),
                    blurRadius: 25,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 22, 20, 0),
                    child: Column(
                      children: [
                        Center(
                          child: RichText(
                            text: const TextSpan(
                              style: TextStyle(
                                fontFamily: _font,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 2.0,
                              ),
                              children: [
                                TextSpan(text: "PXD", style: TextStyle(color: Colors.white)),
                                TextSpan(text: "\u2014", style: TextStyle(color: _accentBlue)),
                                TextSpan(text: "BUG", style: TextStyle(color: _accentBlue)),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "Riwayat aktivitas pengiriman",
                          style: TextStyle(
                            fontFamily: _font,
                            color: Colors.white.withOpacity(0.4),
                            fontSize: 11,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 14),
                        Container(
                          height: 1,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(colors: [
                              Colors.transparent,
                              _accentBlue.withOpacity(0.4),
                              Colors.transparent,
                            ]),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Flexible(
                    child: _historyLog.isEmpty
                        ? Padding(
                            padding: const EdgeInsets.symmetric(vertical: 40),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: const [
                                Icon(Icons.history_toggle_off, color: Colors.white24, size: 44),
                                SizedBox(height: 12),
                                Text(
                                  "Belum ada riwayat aktivitas",
                                  style: TextStyle(
                                    fontFamily: _font,
                                    color: Colors.white38,
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            shrinkWrap: true,
                            physics: const BouncingScrollPhysics(),
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                            itemCount: _historyLog.length,
                            itemBuilder: (_, i) {
                              final h = _historyLog[i];
                              return Container(
                                margin: const EdgeInsets.only(bottom: 10),
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.04),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: _accentBlue.withOpacity(0.18)),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 8,
                                      height: 8,
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: _greenLive,
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            h['target'] ?? '-',
                                            style: const TextStyle(
                                              fontFamily: _font,
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 13,
                                            ),
                                          ),
                                          const SizedBox(height: 3),
                                          Text(
                                            "${h['bugName']} · ${h['senderType']?.toUpperCase()} · ${h['bugId']}",
                                            style: TextStyle(
                                              fontFamily: _font,
                                              color: Colors.white.withOpacity(0.45),
                                              fontSize: 10,
                                              letterSpacing: 0.3,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Text(
                                      h['time'] ?? '',
                                      style: const TextStyle(
                                        fontFamily: _font,
                                        color: _accentBlueGlow,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 10, 20, 18),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 9),
                            decoration: BoxDecoration(
                              color: _accentBlue.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: _accentBlue.withOpacity(0.4)),
                            ),
                            child: const Text(
                              "Close",
                              style: TextStyle(
                                fontFamily: _font,
                                color: _accentBlue,
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _initializeVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _videoInitialized = true);
          _videoController.setLooping(true);
          _videoController.setVolume(0.0); // ada suaranya
          _videoController.play();
          // Auto-resume kalau ke-pause (mis. saat keyboard muncul / TextField focus).
          _videoController.addListener(_keepVideoAlive);
        }
      }).catchError((e) {
        debugPrint("Error Video: $e");
      });
  }

  // Mencegah video berhenti waktu user ngetik di TextField.
  void _keepVideoAlive() {
    if (!mounted) return;
    final v = _videoController.value;
    if (!v.isInitialized || v.hasError) return;
    if (!v.isPlaying) {
      _videoController.play();
    }
  }

  void _initializeAnimations() {
    // Avatar floating
    _avatarAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _avatarFloatAnim = Tween<double>(begin: -3.0, end: 3.0).animate(
      CurvedAnimation(parent: _avatarAnimController, curve: Curves.easeInOut),
    );

    // Live dot pulsing
    _liveDotController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat(reverse: true);

    // Staggered entrance
    _staggerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    Animation<double> createFade(double s, double e) =>
        CurvedAnimation(parent: _staggerController, curve: Interval(s, e, curve: Curves.easeOut));
    Animation<Offset> createSlide(double s, double e) => Tween<Offset>(
          begin: const Offset(0, 0.18),
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: _staggerController, curve: Interval(s, e, curve: Curves.easeOutCubic)));

    _fade1 = createFade(0.00, 0.30); _slide1 = createSlide(0.00, 0.30); // TopBar
    _fade2 = createFade(0.08, 0.38); _slide2 = createSlide(0.08, 0.38); // Profile Card
    _fade3 = createFade(0.16, 0.46); _slide3 = createSlide(0.16, 0.46); // Video Banner
    _fade4 = createFade(0.24, 0.54); _slide4 = createSlide(0.24, 0.54); // 3 Stats
    _fade5 = createFade(0.32, 0.62); _slide5 = createSlide(0.32, 0.62); // Input Number
    _fade6 = createFade(0.40, 0.70); _slide6 = createSlide(0.40, 0.70); // Payload
    _fade7 = createFade(0.50, 0.85); _slide7 = createSlide(0.50, 0.85); // Sender + Send
  }

  void _setDefaultBug() {
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    if (_isSending) return;

    setState(() => _isSending = true);

    // ── Parse format input baru: "/<bug_id> <nomor>" ────────────────────
    final raw = targetController.text.trim();
    if (!raw.startsWith('/')) {
      _showAlert("❌ Format Salah",
          "Gunakan format: /bug_id 628xxxxxxxxxx\nContoh: /crash_v2 6281234567890");
      setState(() => _isSending = false);
      return;
    }
    final spaceIdx = raw.indexOf(' ');
    if (spaceIdx == -1) {
      _showAlert("❌ Nomor Belum Diisi",
          "Sertakan nomor target setelah bug_id.\nContoh: /crash_v2 6281234567890");
      setState(() => _isSending = false);
      return;
    }
    final bugPart = raw.substring(1, spaceIdx).trim();
    final numPart = raw.substring(spaceIdx + 1).trim();

    // Validasi bug_id ada di daftar
    final match = widget.listBug.firstWhere(
      (b) => b['bug_id'].toString().toLowerCase() == bugPart.toLowerCase(),
      orElse: () => <String, dynamic>{},
    );
    if (match.isEmpty) {
      _showAlert("❌ Bug ID Tidak Dikenal",
          "Bug ID '$bugPart' tidak ada di daftar payload.");
      setState(() => _isSending = false);
      return;
    }
    selectedBugId = match['bug_id'].toString();

    final target = formatPhoneNumber(numPart);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("❌ Invalid Number",
          "Gunakan nomor internasional (misal: 62, 1, 44), bukan 08xxx.");
      setState(() => _isSending = false);
      return;
    }

    try {
      final res = await http.get(Uri.parse(
          "http://panel-icxninh.ryuuuprv.my.id:2002/api/whatsapp/sendBug?key=$key&target=$target&bug=$selectedBugId&senderType=$_senderType"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["senderOn"] == false) {
        _showAlert("⚠️ Gagal", "Gagal mengirim bug. Sender Kosong, Hubungi Seller.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Session key tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Gagal mengirim bug. Mungkin server sedang maintenance.");
      } else {
        final now = DateTime.now();
        final timeStr =
            '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
        final selectedBug = widget.listBug.firstWhere(
          (b) => b['bug_id'] == selectedBugId,
          orElse: () => {'bug_name': selectedBugId, 'bug_id': selectedBugId},
        );
        setState(() {
          _historyLog.insert(0, {
            'time': timeStr,
            'target': target,
            'bugId': selectedBugId,
            'bugName': selectedBug['bug_name']?.toString() ?? selectedBugId,
            'senderType': _senderType,
          });
          if (_historyLog.length > 50) _historyLog.removeLast();
        });
        _showSuccessPopup(target);
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showSuccessPopup(String target) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => _CoolSuccessDialog(target: target),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _cardBlack.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: _accentBlue, width: 1),
        ),
        title: Text(title,
            style: const TextStyle(
                fontFamily: _font, color: Colors.white, fontWeight: FontWeight.bold)),
        content: Text(msg,
            style: const TextStyle(fontFamily: _font, color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK",
                style: TextStyle(fontFamily: _font, color: _accentBlue)),
          ),
        ],
      ),
    );
  }

  Color _getRoleColor(String role) {
    String r = role.toLowerCase();
    if (r.contains('member')) return _accentBlue;
    if (r.contains('resseler') || r.contains('reseller')) return _yellowSoft;
    if (r.contains('vip')) return Colors.redAccent;
    if (r.contains('pt')) return Colors.purpleAccent;
    if (r.contains('tk')) return _accentDeep;
    if (r.contains('owner')) return const Color(0xFF8B0000);
    return _accentBlue;
  }

  @override
  void dispose() {
    _videoController.removeListener(_keepVideoAlive);
    _videoController.dispose();
    _avatarAnimController.dispose();
    _liveDotController.dispose();
    _staggerController.dispose();
    _payloadScrollCtrl.dispose();
    targetController.removeListener(_onTargetChanged);
    targetController.dispose();
    _inputFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          // ── Soft glow di latar agar gak terlalu flat ────────────
          Positioned(
              top: -120, left: -120, child: _glow(280, _accentBlue, 0.10)),
          Positioned(
              bottom: -100, right: -100, child: _glow(260, _accentBlueGlow, 0.08)),

          // ── Pola segi enam di pojok kanan atas (besar, sedikit) ──
          Positioned(
            top: 0,
            right: 0,
            child: IgnorePointer(
              child: SizedBox(
                width: 220,
                height: 230,
                child: _HexPattern(corner: _HexCornerPos.topRight),
              ),
            ),
          ),
          // ── Pola segi enam di pojok kiri bawah (besar, sedikit) ──
          Positioned(
            bottom: 0,
            left: 0,
            child: IgnorePointer(
              child: SizedBox(
                width: 220,
                height: 230,
                child: _HexPattern(corner: _HexCornerPos.bottomLeft),
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                FadeTransition(
                  opacity: _fade1,
                  child: SlideTransition(position: _slide1, child: _buildTopBar()),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(18, 8, 18, 30),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        FadeTransition(
                          opacity: _fade2,
                          child: SlideTransition(position: _slide2, child: _buildProfileBanner()),
                        ),
                        const SizedBox(height: 18),
                        FadeTransition(
                          opacity: _fade3,
                          child: SlideTransition(position: _slide3, child: _buildVideoBanner()),
                        ),
                        const SizedBox(height: 18),
                        FadeTransition(
                          opacity: _fade4,
                          child: SlideTransition(position: _slide4, child: _buildStatsRow()),
                        ),
                        const SizedBox(height: 22),
                        FadeTransition(
                          opacity: _fade5,
                          child: SlideTransition(position: _slide5, child: _buildInputNumberArea()),
                        ),
                        const SizedBox(height: 18),
                        FadeTransition(
                          opacity: _fade7,
                          child: SlideTransition(position: _slide7, child: _buildSenderMethodBox()),
                        ),
                        const SizedBox(height: 24),
                        FadeTransition(
                          opacity: _fade7,
                          child: SlideTransition(position: _slide7, child: _buildSendButton()),
                        ),
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Widget _glow(double size, Color color, double opacity) => IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [
              color.withOpacity(opacity),
              Colors.transparent,
            ]),
          ),
        ),
      );

  // ════════════════════════════════════════════════════════════════════════
  //  TOP BAR — Kotak icon shield + VOID BUG, label biru V6.0.0
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              // Kotak icon shield
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: _cardBlack,
                  borderRadius: BorderRadius.circular(11),
                  border: Border.all(color: _accentBlue.withOpacity(0.45), width: 1.2),
                  boxShadow: [
                    BoxShadow(
                      color: _accentBlue.withOpacity(0.22),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Icon(Icons.shield_rounded,
                    color: _accentBlue, size: 20),
              ),
              const SizedBox(width: 11),
              const Text(
                "PXD BUG",
                style: TextStyle(
                  fontFamily: _font,
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 17,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          // Label biru V6.0.0
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_accentBlue, _accentDeep],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(9),
              boxShadow: [
                BoxShadow(
                  color: _accentBlue.withOpacity(0.55),
                  blurRadius: 12,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: const Text(
              "V6.0.0",
              style: TextStyle(
                fontFamily: _font,
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 12,
                letterSpacing: 1.3,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  PROFILE BANNER — foto + username, role biru, label jam expired
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildProfileBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(16, 16, 12, 16),
      decoration: BoxDecoration(
        color: _cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 22,
            offset: const Offset(0, 12),
          ),
          BoxShadow(
            color: _accentBlue.withOpacity(0.12),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Foto profil floating
          AnimatedBuilder(
            animation: _avatarAnimController,
            builder: (ctx, child) => Transform.translate(
              offset: Offset(0, _avatarFloatAnim.value),
              child: child,
            ),
            child: Container(
              padding: const EdgeInsets.all(2.5),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: _accentBlue, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: _accentBlue.withOpacity(0.55),
                    blurRadius: 14,
                  ),
                ],
              ),
              child: const CircleAvatar(
                radius: 26,
                backgroundImage: AssetImage('assets/images/icon.jpg'),
                backgroundColor: Colors.black,
              ),
            ),
          ),
          const SizedBox(width: 14),
          // Info user
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: _font,
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.role.toUpperCase(),
                  style: TextStyle(
                    fontFamily: _font,
                    color: _accentBlueGlow,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          // Label jam + expired
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: _accentBlue.withOpacity(0.10),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: _accentBlue.withOpacity(0.40)),
              boxShadow: [
                BoxShadow(
                  color: _accentBlue.withOpacity(0.18),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.access_time_rounded,
                    color: _accentBlue, size: 13),
                const SizedBox(width: 5),
                Text(
                  widget.expiredDate,
                  style: const TextStyle(
                    fontFamily: _font,
                    color: _accentBlue,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  VIDEO BANNER — assets/videos/banner.mp4 dengan suara
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 165,
      decoration: BoxDecoration(
        color: _cardBlackDeep,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: _accentBlue.withOpacity(0.10),
            blurRadius: 18,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              )
            else
              Container(
                color: _cardBlackDeep,
                child: const Center(
                  child: SizedBox(
                    width: 28,
                    height: 28,
                    child: CircularProgressIndicator(
                        color: _accentBlue, strokeWidth: 2),
                  ),
                ),
              ),
            // Overlay vignette tipis biar teks/icon terbaca
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.45),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  3 STATS ROW — Gacor, Total Payload, Fast Send (dengan divider tipis)
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildStatsRow() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
      decoration: BoxDecoration(
        color: _cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: _accentBlue.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: _StatItem(
              icon: FontAwesomeIcons.fire,
              iconColor: const Color(0xFFFF7A00),
              title: "Gacor",
              subtitle: "Ratting Global",
            ),
          ),
          _ThinDivider(),
          Expanded(
            child: _StatItem(
              icon: FontAwesomeIcons.bug,
              iconColor: _greenLive,
              title: "Total Payload",
              subtitle: "${widget.listBug.length} Tersedia",
              valueBig: "${widget.listBug.length}",
            ),
          ),
          _ThinDivider(),
          Expanded(
            child: _StatItem(
              icon: Icons.flash_on_rounded,
              iconColor: _yellowSoft,
              title: "Fast Send",
              subtitle: "Super Cepat",
            ),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  COMMAND PAYLOAD AREA — input "/bug_id <nomor>" + saran bug_id
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildInputNumberArea() {
    final bool locked = selectedBugId.isNotEmpty &&
        targetController.text.startsWith('/$selectedBugId');
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      decoration: BoxDecoration(
        color: _cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: _accentBlue.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header: icon + "Command Payload" + label "Locked"/jumlah
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: _accentBlue.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: _accentBlue.withOpacity(0.40)),
                ),
                child: const Icon(Icons.terminal_rounded,
                    color: _accentBlue, size: 16),
              ),
              const SizedBox(width: 11),
              const Text(
                "Command Payload",
                style: TextStyle(
                  fontFamily: _font,
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.0,
                ),
              ),
              const Spacer(),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                transitionBuilder: (c, a) =>
                    FadeTransition(opacity: a, child: c),
                child: locked
                    ? Container(
                        key: const ValueKey('locked'),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 9, vertical: 4),
                        decoration: BoxDecoration(
                          color: _greenLive.withOpacity(0.14),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                              color: _greenLive.withOpacity(0.40)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.lock_rounded,
                                color: _greenLive, size: 11),
                            const SizedBox(width: 4),
                            Text(
                              selectedBugId,
                              style: const TextStyle(
                                fontFamily: _font,
                                color: _greenLive,
                                fontSize: 10.5,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.4,
                              ),
                            ),
                          ],
                        ),
                      )
                    : Container(
                        key: const ValueKey('count'),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 9, vertical: 4),
                        decoration: BoxDecoration(
                          color: _accentBlue.withOpacity(0.14),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                              color: _accentBlue.withOpacity(0.40)),
                        ),
                        child: Text(
                          "${widget.listBug.length} Payload",
                          style: const TextStyle(
                            fontFamily: _font,
                            color: _accentBlue,
                            fontSize: 10.5,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.4,
                          ),
                        ),
                      ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // ── Saran bug_id (muncul saat user mengetik "/") ─────────────
          AnimatedSize(
            duration: const Duration(milliseconds: 230),
            curve: Curves.easeOutCubic,
            alignment: Alignment.topCenter,
            child: (_showBugSuggest && _filteredBugSuggestions().isNotEmpty)
                ? _buildBugSuggestList()
                : const SizedBox(width: double.infinity),
          ),

          // ── Input gabungan: /<bug_id> <nomor> ────────────────────────
          Container(
            decoration: BoxDecoration(
              color: _cardBlackDeep,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: _accentBlue.withOpacity(0.30), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: _accentBlue.withOpacity(0.10),
                  blurRadius: 10,
                ),
              ],
            ),
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
            child: Row(
              children: [
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 250),
                  transitionBuilder: (c, a) =>
                      ScaleTransition(scale: a, child: FadeTransition(opacity: a, child: c)),
                  child: Padding(
                    key: ValueKey(_detectedDialCode),
                    padding: const EdgeInsets.only(left: 4, right: 8),
                    child: _CountryFlag(dialCode: _detectedDialCode),
                  ),
                ),
                Container(
                  width: 1,
                  height: 26,
                  color: Colors.white.withOpacity(0.10),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: TextField(
                    controller: targetController,
                    focusNode: _inputFocus,
                    style: const TextStyle(
                      fontFamily: _font,
                      color: Colors.white,
                      fontSize: 15,
                      letterSpacing: 0.4,
                    ),
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      hintText: "/bug_id 6281234567890",
                      hintStyle: TextStyle(
                        fontFamily: _font,
                        color: Colors.white.withOpacity(0.28),
                        fontSize: 13,
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          // Helper teks kecil
          Padding(
            padding: const EdgeInsets.only(left: 2, top: 2),
            child: Text(
              "Format: /bug_id <nomor>   •   contoh: /crash_v2 6281234567890",
              style: TextStyle(
                fontFamily: _font,
                color: Colors.white.withOpacity(0.40),
                fontSize: 10.5,
                letterSpacing: 0.3,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Daftar saran bug_id (muncul tepat di atas input) ────────────────────
  Widget _buildBugSuggestList() {
    final filtered = _filteredBugSuggestions();
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      constraints: const BoxConstraints(maxHeight: 190),
      decoration: BoxDecoration(
        color: _cardBlackDeep,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: _accentBlue.withOpacity(0.30), width: 1.0),
        boxShadow: [
          BoxShadow(
            color: _accentBlue.withOpacity(0.10),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: ScrollConfiguration(
          behavior: const _BugSuggestNoGlow(),
          child: ListView.separated(
            shrinkWrap: true,
            padding: const EdgeInsets.symmetric(vertical: 6),
            itemCount: filtered.length,
            separatorBuilder: (_, __) => Divider(
              height: 1,
              thickness: 1,
              color: Colors.white.withOpacity(0.05),
            ),
            itemBuilder: (ctx, i) {
              final b = filtered[i];
              final bugId = b['bug_id']?.toString() ?? '';
              final bugName = (b['bug_name']?.toString().isNotEmpty == true)
                  ? b['bug_name'].toString()
                  : bugId;
              final bool isActive = bugId.toLowerCase() ==
                  _typedBugQuery.toLowerCase();
              return Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => _selectBugFromSuggest(bugId),
                  splashColor: _accentBlue.withOpacity(0.15),
                  highlightColor: _accentBlue.withOpacity(0.08),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: isActive
                                ? _accentBlue.withOpacity(0.22)
                                : _accentBlue.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(7),
                            border: Border.all(
                                color: _accentBlue.withOpacity(
                                    isActive ? 0.55 : 0.35)),
                          ),
                          child: Text(
                            "/$bugId",
                            style: TextStyle(
                              fontFamily: _font,
                              color: isActive
                                  ? Colors.white
                                  : _accentBlueGlow,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.4,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            bugName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontFamily: _font,
                              color: Colors.white.withOpacity(0.85),
                              fontSize: 12.5,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.2,
                            ),
                          ),
                        ),
                        Icon(Icons.north_west_rounded,
                            color: Colors.white.withOpacity(0.35), size: 14),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  PAYLOAD AREA — list horizontal + indicator dot ikut scroll
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildPayloadArea() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      decoration: BoxDecoration(
        color: _cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: _accentBlue.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: _greenLive.withOpacity(0.14),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: _greenLive.withOpacity(0.40)),
                ),
                child: const Icon(FontAwesomeIcons.bug,
                    color: _greenLive, size: 14),
              ),
              const SizedBox(width: 11),
              const Text(
                "Pilih Payload",
                style: TextStyle(
                  fontFamily: _font,
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.0,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: _accentBlue.withOpacity(0.14),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: _accentBlue.withOpacity(0.40)),
                ),
                child: Text(
                  "${widget.listBug.length} Payload",
                  style: const TextStyle(
                    fontFamily: _font,
                    color: _accentBlue,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildPayloadSelector(),
          const SizedBox(height: 14),
          _buildPayloadDots(),
        ],
      ),
    );
  }

  Widget _buildPayloadSelector() {
    return SizedBox(
      // tinggi cukup agar saat kartu membesar (scale 1.06) tidak terpotong
      height: 132,
      child: ListView.builder(
        controller: _payloadScrollCtrl,
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
        itemCount: widget.listBug.length,
        itemBuilder: (context, index) {
          final bug = widget.listBug[index];
          final bool isSelected = selectedBugId == bug['bug_id'];
          final String bugId   = bug['bug_id']?.toString()   ?? '';
          final String bugName = bug['bug_name']?.toString() ?? '';

          return GestureDetector(
            onTap: () => setState(() => selectedBugId = bug['bug_id']),
            child: AnimatedScale(
              scale: isSelected ? 1.06 : 1.0,
              duration: const Duration(milliseconds: 280),
              curve: Curves.easeOutCubic,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 280),
                width: 168,
                margin: const EdgeInsets.only(right: 12),
                padding: const EdgeInsets.fromLTRB(13, 12, 13, 12),
                decoration: BoxDecoration(
                  gradient: isSelected
                      ? const LinearGradient(
                          colors: [_accentBlue, _accentDeep],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : null,
                  color: isSelected ? null : _cardBlackDeep,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: isSelected
                        ? _accentBlueGlow
                        : Colors.white.withOpacity(0.10),
                    width: 1.4,
                  ),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: _accentBlue.withOpacity(0.45),
                            blurRadius: 18,
                            spreadRadius: 1,
                            offset: const Offset(0, 6),
                          ),
                        ]
                      : [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.35),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                ),
                child: Stack(
                  children: [
                    // Konten utama
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Bulatan shield di kiri atas
                        Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            color: isSelected
                                ? Colors.white.withOpacity(0.22)
                                : _accentBlue.withOpacity(0.12),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: isSelected
                                  ? Colors.white.withOpacity(0.55)
                                  : _accentBlue.withOpacity(0.45),
                              width: 1.2,
                            ),
                          ),
                          child: Center(
                            child: Icon(
                              Icons.shield_rounded,
                              color: isSelected ? Colors.white : _accentBlue,
                              size: 16,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        // bug_name (utama)
                        Text(
                          bugName.isEmpty ? bugId : bugName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: _font,
                            color: isSelected
                                ? Colors.white
                                : Colors.white.withOpacity(0.95),
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            letterSpacing: 0.3,
                          ),
                        ),
                        const SizedBox(height: 6),
                        // Label kecil dengan bug_id
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? Colors.white.withOpacity(0.18)
                                : _accentBlue.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(7),
                            border: Border.all(
                              color: isSelected
                                  ? Colors.white.withOpacity(0.40)
                                  : _accentBlue.withOpacity(0.35),
                            ),
                          ),
                          child: Text(
                            bugId,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontFamily: _font,
                              color: isSelected
                                  ? Colors.white
                                  : _accentBlueGlow,
                              fontSize: 9.5,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.4,
                            ),
                          ),
                        ),
                      ],
                    ),
                    // Bulatan hijau hidup di pojok kanan atas
                    Positioned(
                      top: 0,
                      right: 0,
                      child: AnimatedBuilder(
                        animation: _liveDotController,
                        builder: (ctx, _) {
                          final t = _liveDotController.value;
                          return Stack(
                            alignment: Alignment.center,
                            children: [
                              Container(
                                width: 16 + (6 * t),
                                height: 16 + (6 * t),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _greenLive.withOpacity(0.25 * (1 - t)),
                                ),
                              ),
                              Container(
                                width: 9,
                                height: 9,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _greenLive,
                                  boxShadow: [
                                    BoxShadow(
                                      color: _greenLive.withOpacity(0.75),
                                      blurRadius: 8,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // Indicator dot yang ikut bergerak saat list di-scroll
  Widget _buildPayloadDots() {
    if (widget.listBug.isEmpty) return const SizedBox.shrink();
    final maxScroll = _payloadScrollCtrl.hasClients
        ? _payloadScrollCtrl.position.maxScrollExtent
        : 0.0;
    final cardWidth = 168.0 + 12.0;
    final visibleCount = 5;
    final total = widget.listBug.length > visibleCount
        ? widget.listBug.length - visibleCount + 1
        : 1;
    final activeIndex = maxScroll <= 0
        ? 0
        : ((_payloadScrollPos / cardWidth).round())
            .clamp(0, (total - 1).clamp(0, total));
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        total.clamp(1, 8),
        (i) => AnimatedContainer(
          duration: const Duration(milliseconds: 240),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: i == activeIndex ? 22 : 7,
          height: 7,
          decoration: BoxDecoration(
            color: i == activeIndex
                ? _accentBlue
                : Colors.white.withOpacity(0.18),
            borderRadius: BorderRadius.circular(20),
            boxShadow: i == activeIndex
                ? [
                    BoxShadow(
                      color: _accentBlue.withOpacity(0.55),
                      blurRadius: 8,
                    ),
                  ]
                : null,
          ),
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  SENDER METHOD — 2 tombol Private & Global, biru cerah saat aktif
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildSenderMethodBox() {
    final bool globalDisabled  = !_senderLoading && _globalSenderCount  == 0;
    final bool privateDisabled = !_senderLoading && _privateSenderCount == 0;
    final totalSender = _globalSenderCount + _privateSenderCount;

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
      decoration: BoxDecoration(
        color: _cardBlack,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: _accentBlue.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header: icon link + "Pilih Sender" + label hijau total sender
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: _accentBlue.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: _accentBlue.withOpacity(0.40)),
                ),
                child: const Icon(Icons.link_rounded,
                    color: _accentBlue, size: 16),
              ),
              const SizedBox(width: 11),
              const Text(
                "Pilih Sender",
                style: TextStyle(
                  fontFamily: _font,
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.0,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: _fetchSenderCounts,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: _greenLive.withOpacity(0.14),
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(color: _greenLive.withOpacity(0.45)),
                  ),
                  child: _senderLoading
                      ? const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                              color: _greenLive, strokeWidth: 1.5),
                        )
                      : Text(
                          "$totalSender Sender",
                          style: const TextStyle(
                            fontFamily: _font,
                            color: _greenLive,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.4,
                          ),
                        ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _SenderButton(
                  active: _senderType == "private",
                  disabled: privateDisabled,
                  loading: _senderLoading,
                  icon: Icons.lock_rounded,
                  label: "Private",
                  count: _privateSenderCount,
                  onTap: privateDisabled
                      ? null
                      : () => setState(() => _senderType = "private"),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SenderButton(
                  active: _senderType == "global",
                  disabled: globalDisabled,
                  loading: _senderLoading,
                  icon: Icons.public_rounded,
                  label: "Global",
                  count: _globalSenderCount,
                  onTap: globalDisabled
                      ? null
                      : () => setState(() => _senderType = "global"),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  //  SEND BUTTON — biru panjang + paper plane
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildSendButton() {
    return Container(
      width: double.infinity,
      height: 56,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        gradient: const LinearGradient(
          colors: [_accentBlueGlow, _accentBlue, _accentDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: _accentBlue.withOpacity(0.55),
            blurRadius: 22,
            spreadRadius: 1,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(15),
          onTap: _isSending ? null : _sendBug,
          child: Center(
            child: _isSending
                ? const SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(FontAwesomeIcons.paperPlane,
                          color: Colors.white, size: 17),
                      SizedBox(width: 12),
                      Text(
                        "SEND BUG",
                        style: TextStyle(
                          fontFamily: _font,
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2.5,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
//  STAT ITEM — bulatan hitam 3D + icon + judul + subtitle kecil
// ════════════════════════════════════════════════════════════════════════════
class _StatItem extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final String? valueBig;

  const _StatItem({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    this.valueBig,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Bulatan hitam dengan bayangan (3D)
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _cardBlackDeep,
            border: Border.all(color: iconColor.withOpacity(0.35), width: 1.2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.55),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
              BoxShadow(
                color: iconColor.withOpacity(0.30),
                blurRadius: 12,
                spreadRadius: 0,
              ),
            ],
          ),
          child: Center(
            child: Icon(icon, color: iconColor, size: 17),
          ),
        ),
        const SizedBox(height: 9),
        if (valueBig != null) ...[
          Text(
            valueBig!,
            style: const TextStyle(
              fontFamily: _font,
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.4,
              height: 1.0,
            ),
          ),
          const SizedBox(height: 3),
        ],
        Text(
          title,
          style: const TextStyle(
            fontFamily: _font,
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          subtitle,
          style: TextStyle(
            fontFamily: _font,
            color: Colors.white.withOpacity(0.40),
            fontSize: 10,
            letterSpacing: 0.3,
          ),
        ),
      ],
    );
  }
}

class _ThinDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1,
      height: 56,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.transparent,
            Colors.white.withOpacity(0.18),
            Colors.transparent,
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
//  SENDER BUTTON — biru cerah saat aktif, dengan bayangan 3D
// ════════════════════════════════════════════════════════════════════════════
class _SenderButton extends StatelessWidget {
  final bool active;
  final bool disabled;
  final bool loading;
  final IconData icon;
  final String label;
  final int count;
  final VoidCallback? onTap;

  const _SenderButton({
    required this.active,
    required this.disabled,
    required this.loading,
    required this.icon,
    required this.label,
    required this.count,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final Color border = disabled
        ? Colors.redAccent.withOpacity(0.45)
        : active
            ? _accentBlueGlow
            : Colors.white.withOpacity(0.12);

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 280),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          gradient: !disabled && active
              ? const LinearGradient(
                  colors: [_accentBlue, _accentDeep],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          color: !disabled && active
              ? null
              : disabled
                  ? Colors.redAccent.withOpacity(0.08)
                  : _cardBlackDeep,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: border, width: 1.4),
          boxShadow: !disabled && active
              ? [
                  BoxShadow(
                    color: _accentBlue.withOpacity(0.55),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                    spreadRadius: 1,
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.30),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.35),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: disabled
                  ? Colors.redAccent.withOpacity(0.7)
                  : active
                      ? Colors.white
                      : _accentBlueGlow,
              size: 22,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontFamily: _font,
                color: disabled
                    ? Colors.white38
                    : active
                        ? Colors.white
                        : Colors.white70,
                fontSize: 13,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 6),
            loading
                ? Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      "...",
                      style: TextStyle(
                        fontFamily: _font,
                        color: Colors.white24,
                        fontSize: 10,
                      ),
                    ),
                  )
                : Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: disabled
                          ? Colors.redAccent.withOpacity(0.15)
                          : active
                              ? Colors.white.withOpacity(0.20)
                              : _accentBlue.withOpacity(0.14),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: disabled
                            ? Colors.redAccent.withOpacity(0.40)
                            : active
                                ? Colors.white.withOpacity(0.40)
                                : _accentBlue.withOpacity(0.40),
                        width: 0.8,
                      ),
                    ),
                    child: Text(
                      "$count Senders",
                      style: TextStyle(
                        fontFamily: _font,
                        color: disabled
                            ? Colors.redAccent
                            : active
                                ? Colors.white
                                : _accentBlueGlow,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
//  COUNTRY FLAG — bendera kecil yang muncul otomatis sesuai kode negara
//  (BUKAN emoji — semua digambar manual dengan Container)
// ════════════════════════════════════════════════════════════════════════════
class _CountryFlag extends StatelessWidget {
  final String dialCode;
  const _CountryFlag({required this.dialCode});

  @override
  Widget build(BuildContext context) {
    final builder = _kFlagMap[dialCode];
    final hasFlag = builder != null;
    return Container(
      width: 36,
      height: 26,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: Colors.white.withOpacity(0.18), width: 0.8),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.45), blurRadius: 4),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: hasFlag
          ? builder(context)
          : Container(
              color: _cardBlackDeep,
              child: const Icon(Icons.public, color: Colors.white38, size: 14),
            ),
    );
  }
}

// Map kode negara → builder bendera
typedef _FlagBuilder = Widget Function(BuildContext);

final Map<String, _FlagBuilder> _kFlagMap = {
  "62": (_) => _flagHorizontal2(const Color(0xFFFF0000), Colors.white),       // Indonesia
  "60": (_) => _flagHorizontal2(const Color(0xFFCC0001), Colors.white),       // Malaysia (sederhana)
  "65": (_) => _flagHorizontal2(const Color(0xFFEF3340), Colors.white),       // Singapore
  "1":  (_) => _flagUSA(),                                                    // USA
  "44": (_) => _flagUK(),                                                     // UK
  "91": (_) => _flagHorizontal3(const Color(0xFFFF9933), Colors.white,
                                 const Color(0xFF138808)),                    // India
  "81": (_) => _flagJapan(),                                                  // Jepang
  "86": (_) => _flagChina(),                                                  // China
  "82": (_) => _flagKorea(),                                                  // Korea Selatan
  "84": (_) => _flagVietnam(),                                                // Vietnam
  "66": (_) => _flagThailand(),                                               // Thailand
  "33": (_) => _flagVertical3(const Color(0xFF002395), Colors.white,
                               const Color(0xFFED2939)),                      // France
  "49": (_) => _flagHorizontal3(Colors.black, const Color(0xFFDD0000),
                                 const Color(0xFFFFCE00)),                    // Germany
  "7":  (_) => _flagHorizontal3(Colors.white, const Color(0xFF0039A6),
                                 const Color(0xFFD52B1E)),                    // Russia
  "61": (_) => _flagAustralia(),                                              // Australia
  "55": (_) => _flagBrazil(),                                                 // Brazil
  "39": (_) => _flagVertical3(const Color(0xFF008C45), Colors.white,
                               const Color(0xFFCD212A)),                      // Italy
  "34": (_) => _flagHorizontal3(const Color(0xFFAA151B),
                                 const Color(0xFFF1BF00),
                                 const Color(0xFFAA151B)),                    // Spain (sederhana)
  "31": (_) => _flagHorizontal3(const Color(0xFFAE1C28), Colors.white,
                                 const Color(0xFF21468B)),                    // Netherlands
  "63": (_) => _flagHorizontal2(const Color(0xFF0038A8),
                                 const Color(0xFFCE1126)),                    // Philippines (sederhana)
  "90": (_) => _flagTurkey(),                                                 // Turkey
  "971": (_) => _flagHorizontal3(const Color(0xFF00732F), Colors.white,
                                  Colors.black),                              // UAE (sederhana)
  "966": (_) => Container(color: const Color(0xFF006C35)),                    // Saudi Arabia (sederhana)
  "20":  (_) => _flagHorizontal3(const Color(0xFFCE1126), Colors.white,
                                  Colors.black),                              // Egypt
  "27":  (_) => Container(color: const Color(0xFF007A4D)),                    // South Africa (sederhana)
  "92":  (_) => Container(color: const Color(0xFF01411C)),                    // Pakistan (sederhana)
  "880": (_) => Container(color: const Color(0xFF006A4E)),                    // Bangladesh
  "234": (_) => _flagVertical3(const Color(0xFF008751), Colors.white,
                                const Color(0xFF008751)),                     // Nigeria
};

// ── Helper builder bendera ────────────────────────────────────────────────
Widget _flagHorizontal2(Color top, Color bottom) {
  return Column(
    children: [
      Expanded(child: Container(color: top)),
      Expanded(child: Container(color: bottom)),
    ],
  );
}

Widget _flagHorizontal3(Color a, Color b, Color c) {
  return Column(
    children: [
      Expanded(child: Container(color: a)),
      Expanded(child: Container(color: b)),
      Expanded(child: Container(color: c)),
    ],
  );
}

Widget _flagVertical3(Color a, Color b, Color c) {
  return Row(
    children: [
      Expanded(child: Container(color: a)),
      Expanded(child: Container(color: b)),
      Expanded(child: Container(color: c)),
    ],
  );
}

Widget _flagJapan() {
  return Container(
    color: Colors.white,
    child: Center(
      child: Container(
        width: 14,
        height: 14,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0xFFBC002D),
        ),
      ),
    ),
  );
}

Widget _flagChina() {
  return Container(
    color: const Color(0xFFEE1C25),
    child: Stack(
      children: const [
        Positioned(
          left: 4,
          top: 4,
          child: Icon(Icons.star, color: Color(0xFFFFFF00), size: 10),
        ),
        Positioned(
          left: 13,
          top: 3,
          child: Icon(Icons.star, color: Color(0xFFFFFF00), size: 5),
        ),
        Positioned(
          left: 16,
          top: 8,
          child: Icon(Icons.star, color: Color(0xFFFFFF00), size: 5),
        ),
      ],
    ),
  );
}

Widget _flagKorea() {
  return Container(
    color: Colors.white,
    child: Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [Color(0xFFCD2E3A), Color(0xFF0047A0)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
      ],
    ),
  );
}

Widget _flagVietnam() {
  return Container(
    color: const Color(0xFFDA251D),
    child: const Center(
      child: Icon(Icons.star, color: Color(0xFFFFFF00), size: 14),
    ),
  );
}

Widget _flagThailand() {
  return Column(
    children: [
      Expanded(flex: 1, child: Container(color: const Color(0xFFED1C24))),
      Expanded(flex: 1, child: Container(color: Colors.white)),
      Expanded(flex: 2, child: Container(color: const Color(0xFF241D4F))),
      Expanded(flex: 1, child: Container(color: Colors.white)),
      Expanded(flex: 1, child: Container(color: const Color(0xFFED1C24))),
    ],
  );
}

Widget _flagUSA() {
  return Stack(
    children: [
      Column(
        children: List.generate(
          7,
          (i) => Expanded(
            child: Container(
              color: i.isEven ? const Color(0xFFB22234) : Colors.white,
            ),
          ),
        ),
      ),
      Container(
        width: 16,
        height: 13,
        decoration: const BoxDecoration(color: Color(0xFF3C3B6E)),
        child: const Center(
          child: Icon(Icons.star, color: Colors.white, size: 8),
        ),
      ),
    ],
  );
}

Widget _flagUK() {
  return Stack(
    children: [
      Container(color: const Color(0xFF012169)),
      // Diagonals putih (sederhana)
      Positioned.fill(
        child: CustomPaint(painter: _UKCrossPainter()),
      ),
    ],
  );
}

class _UKCrossPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final whitePaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 4;
    final redPaint = Paint()
      ..color = const Color(0xFFC8102E)
      ..strokeWidth = 2;

    canvas.drawLine(Offset.zero, Offset(size.width, size.height), whitePaint);
    canvas.drawLine(Offset(0, size.height), Offset(size.width, 0), whitePaint);
    canvas.drawLine(Offset.zero, Offset(size.width, size.height), redPaint);
    canvas.drawLine(Offset(0, size.height), Offset(size.width, 0), redPaint);
    // Cross +
    canvas.drawRect(Rect.fromLTWH(0, size.height / 2 - 3, size.width, 6), whitePaint);
    canvas.drawRect(Rect.fromLTWH(size.width / 2 - 3, 0, 6, size.height), whitePaint);
    canvas.drawRect(Rect.fromLTWH(0, size.height / 2 - 1.5, size.width, 3), redPaint);
    canvas.drawRect(Rect.fromLTWH(size.width / 2 - 1.5, 0, 3, size.height), redPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

Widget _flagAustralia() {
  return Stack(
    children: [
      Container(color: const Color(0xFF012169)),
      Positioned(
        top: 0,
        left: 0,
        child: SizedBox(
          width: 16,
          height: 13,
          child: CustomPaint(painter: _UKCrossPainter()),
        ),
      ),
      const Positioned(
        right: 4,
        bottom: 4,
        child: Icon(Icons.star, color: Colors.white, size: 8),
      ),
    ],
  );
}

Widget _flagBrazil() {
  return Container(
    color: const Color(0xFF009C3B),
    child: Center(
      child: Container(
        width: 22,
        height: 14,
        decoration: const BoxDecoration(
          color: Color(0xFFFFDF00),
        ),
        child: Center(
          child: Container(
            width: 10,
            height: 10,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Color(0xFF002776),
            ),
          ),
        ),
      ),
    ),
  );
}

Widget _flagTurkey() {
  return Container(
    color: const Color(0xFFE30A17),
    child: const Center(
      child: Icon(Icons.nightlight_round, color: Colors.white, size: 14),
    ),
  );
}

// ════════════════════════════════════════════════════════════════════════════
//  COOL SUCCESS DIALOG — versi biru
// ════════════════════════════════════════════════════════════════════════════
class _CoolSuccessDialog extends StatefulWidget {
  final String target;
  const _CoolSuccessDialog({required this.target});

  @override
  State<_CoolSuccessDialog> createState() => _CoolSuccessDialogState();
}

class _CoolSuccessDialogState extends State<_CoolSuccessDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _scaleAnim = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scaleAnim,
      child: Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: _cardBlack.withOpacity(0.92),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _accentBlue.withOpacity(0.55), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: _accentBlue.withOpacity(0.30),
                    blurRadius: 30,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _accentBlue.withOpacity(0.18),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.check_circle_outline,
                        color: _accentBlue, size: 60),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "BUG TERKIRIM",
                    style: TextStyle(
                      fontFamily: _font,
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    "Payload has been successfully delivered to:\n${widget.target}",
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontFamily: _font,
                        color: Colors.white70,
                        fontSize: 14,
                        height: 1.5),
                  ),
                  const SizedBox(height: 30),
                  SizedBox(
                    width: double.infinity,
                    height: 45,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _accentBlue.withOpacity(0.18),
                        side: const BorderSide(color: _accentBlue),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: const Text(
                        "Konfirmasi",
                        style: TextStyle(
                          fontFamily: _font,
                          color: _accentBlue,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
//  HEXAGON PATTERN — pola segi enam besar di pojok kanan atas & kiri bawah
// ════════════════════════════════════════════════════════════════════════════
enum _HexCornerPos { topRight, bottomLeft }

class _HexPattern extends StatelessWidget {
  final _HexCornerPos corner;
  const _HexPattern({required this.corner});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _HexPainter(corner: corner),
    );
  }
}

class _HexPainter extends CustomPainter {
  final _HexCornerPos corner;
  _HexPainter({required this.corner});

  @override
  void paint(Canvas canvas, Size size) {
    // Garis biru tua agak gelap, transparan agar background tetap dominan
    final paint = Paint()
      ..color = const Color(0xFF1B2D5C).withOpacity(0.55)
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;

    // Glow halus di belakang garis
    final glow = Paint()
      ..color = const Color(0xFF1E3A8A).withOpacity(0.10)
      ..style = PaintingStyle.fill;

    const double r = 46; // radius hexagon — besar agar sedikit jumlahnya
    final double w = math.sqrt(3) * r;
    final double h = 2 * r;
    final double vSpacing = h * 0.75;

    final List<List<int>> cells = corner == _HexCornerPos.topRight
        ? [
            [0, 0],
            [1, 0],
            [0, 1],
            [-1, 1],
            [1, 1],
          ]
        : [
            [0, 0],
            [1, 0],
            [0, 1],
            [2, 1],
            [1, 1],
          ];

    for (final c in cells) {
      final col = c[0];
      final row = c[1];
      double cx;
      double cy;
      if (corner == _HexCornerPos.topRight) {
        cx = size.width - col * w - (row.isOdd ? w / 2 : 0);
        cy = row * vSpacing + r * 0.4;
      } else {
        cx = col * w + (row.isOdd ? w / 2 : 0);
        cy = size.height - row * vSpacing - r * 0.4;
      }
      _drawHex(canvas, Offset(cx, cy), r, paint, glow);
    }
  }

  void _drawHex(
    Canvas canvas,
    Offset center,
    double r,
    Paint stroke,
    Paint glow,
  ) {
    final path = Path();
    for (int i = 0; i < 6; i++) {
      final angle = math.pi / 3 * i - math.pi / 2;
      final x = center.dx + r * math.cos(angle);
      final y = center.dy + r * math.sin(angle);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();
    canvas.drawPath(path, glow);
    canvas.drawPath(path, stroke);
  }

  @override
  bool shouldRepaint(covariant _HexPainter oldDelegate) =>
      oldDelegate.corner != corner;
}

// ScrollBehavior tanpa overscroll glow — dipakai pada list saran bug_id
class _BugSuggestNoGlow extends ScrollBehavior {
  const _BugSuggestNoGlow();
  @override
  Widget buildOverscrollIndicator(
      BuildContext context, Widget child, ScrollableDetails details) {
    return child;
  }
}

