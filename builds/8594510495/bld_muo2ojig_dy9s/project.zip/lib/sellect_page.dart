import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: const Color(0xFFFDF6E3),
      ),
      home: const SellectPage2(),
    );
  }
}

// ==========================================
// 1. HALAMAN UTAMA (SELLECT PAGE 2)
// ==========================================
class SellectPage2 extends StatefulWidget {
  const SellectPage2({super.key});

  @override
  State<SellectPage2> createState() => _SellectPage2State();
}

class _SellectPage2State extends State<SellectPage2> {
  final List<Map<String, dynamic>> menus = [
    {
      'title': 'NEBULAXRAT',
      'desc': 'Kontrol remote target · list device · command',
      'color': const Color(0xFFE53935),
      'icon': Icons.devices,
      'isActive': true,
    },
    {
      'title': 'NEBULACRASH',
      'desc': 'System crash simulation · exploit tool',
      'color': const Color(0xFFFDD835),
      'icon': Icons.warning,
      'isActive': false,
    },
    {
      'title': 'NEBULARAT',
      'desc': 'Remote access trojan · stealth mode',
      'color': const Color(0xFF1E88E5),
      'icon': Icons.security,
      'isActive': false,
    },
    {
      'title': 'NEBULARAT',
      'desc': 'Advanced persistent threat · monitoring',
      'color': const Color(0xFF43A047),
      'icon': Icons.visibility,
      'isActive': false,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const Positioned.fill(child: ComicBackgroundPattern()),
          const ComicDecorations(),
          SafeArea(
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: MediaQuery.of(context).size.height -
                      MediaQuery.of(context).padding.top -
                      MediaQuery.of(context).padding.bottom,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 15, 20, 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Transform.rotate(
                            angle: -0.02,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFDF6E3),
                                border:
                                    Border.all(color: Colors.black, width: 2.5),
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Colors.black,
                                      offset: Offset(3, 3),
                                      blurRadius: 0),
                                ],
                              ),
                              child: const Row(
                                children: [
                                  Icon(Icons.circle,
                                      color: Colors.green, size: 12),
                                  SizedBox(width: 8),
                                  Text("NEBULA RAT",
                                      style: TextStyle(
                                          fontWeight: FontWeight.w900,
                                          fontSize: 12)),
                                ],
                              ),
                            ),
                          ),
                          Transform.rotate(
                            angle: 0.03,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                border:
                                    Border.all(color: Colors.black, width: 2.5),
                                borderRadius: BorderRadius.circular(8),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Colors.black,
                                      offset: Offset(3, 3),
                                      blurRadius: 0),
                                ],
                              ),
                              child: const Row(
                                children: [
                                  Icon(Icons.play_circle_fill,
                                      color: Colors.red, size: 16),
                                  SizedBox(width: 4),
                                  Text("Tutorial",
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w900)),
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),

                    // Title
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0),
                      child: Transform.rotate(
                        angle: -0.01,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Stack(
                              children: [
                                Positioned(
                                  left: 3,
                                  top: 3,
                                  child: Text(
                                    "PILIH RAT",
                                    style: TextStyle(
                                      fontSize: 38,
                                      fontWeight: FontWeight.w900,
                                      fontStyle: FontStyle.italic,
                                      color: Colors.black.withValues(alpha: 0.15),
                                    ),
                                  ),
                                ),
                                const Text(
                                  "PILIH RAT",
                                  style: TextStyle(
                                    fontSize: 38,
                                    fontWeight: FontWeight.w900,
                                    fontStyle: FontStyle.italic,
                                    color: Colors.black,
                                    letterSpacing: -1,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 2),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.black,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: const Text("4 menu",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 25),

                    // HORIZONTAL LIST VIEW
                    SizedBox(
                      height: 460,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.only(left: 20, right: 20),
                        itemCount: menus.length,
                        itemBuilder: (context, index) {
                          final menu = menus[index];
                          return Padding(
                            padding: const EdgeInsets.only(right: 20.0),
                            child: MenuCard(
                              title: menu['title'],
                              description: menu['desc'],
                              color: menu['color'],
                              icon: menu['icon'],
                              isActive: menu['isActive'],
                              rotation: index == 0 ? -0.02 : 0.02,
                              onTap: () {
                                if (!mounted) return;
                                if (menu['isActive']) {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          const DeviceDashboardPage(),
                                    ),
                                  );
                                } else {
                                  ScaffoldMessenger.of(context)
                                      .showSnackBar(
                                    SnackBar(
                                      content: Text(
                                          "${menu['title']} Coming Soon!",
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white)),
                                      backgroundColor: menu['color'],
                                      behavior: SnackBarBehavior.floating,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        side: const BorderSide(
                                            color: Colors.black, width: 2),
                                      ),
                                      duration:
                                          const Duration(seconds: 1),
                                    ),
                                  );
                                }
                              },
                            ),
                          );
                        },
                      ),
                    ),

                    const SizedBox(height: 40),

                    // Bottom Info Panel dengan Maskot
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 90),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border:
                                  Border.all(color: Colors.black, width: 3),
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: const [
                                BoxShadow(
                                    color: Colors.black,
                                    offset: Offset(5, 5),
                                    blurRadius: 0),
                              ],
                            ),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFE53935),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        color: Colors.black, width: 2.5),
                                    boxShadow: const [
                                      BoxShadow(
                                          color: Colors.black,
                                          offset: Offset(2, 2),
                                          blurRadius: 0),
                                    ],
                                  ),
                                  child: const Icon(Icons.devices,
                                      color: Colors.white, size: 24),
                                ),
                                const SizedBox(width: 14),
                                const Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text("NEBULAXRAT",
                                          style: TextStyle(
                                              fontWeight: FontWeight.w900,
                                              fontSize: 15)),
                                      SizedBox(height: 2),
                                      Text(
                                        "Kontrol remote target · list device · command",
                                        style: TextStyle(
                                            fontSize: 10,
                                            color: Colors.grey),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            left: 14,
                            right: 14,
                            bottom: -50,
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const DeviceDashboardPage(),
                                  ),
                                );
                              },
                              child: Container(
                                height: 48,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFE53935),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                      color: Colors.black, width: 3),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Colors.black,
                                        offset: Offset(4, 4),
                                        blurRadius: 0),
                                  ],
                                ),
                                child: const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      "BUKA NEBULAXRAT",
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w900,
                                        fontStyle: FontStyle.italic,
                                        fontSize: 16,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                    SizedBox(width: 8),
                                    Icon(Icons.arrow_forward,
                                        color: Colors.white, size: 20),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const Positioned(
                            right: 0,
                            bottom: -45,
                            child: ComicMascot(),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// 2. WIDGET KARTU MENU (STYLE KOMIK)
// ==========================================
class MenuCard extends StatelessWidget {
  final String title;
  final String description;
  final Color color;
  final IconData icon;
  final bool isActive;
  final VoidCallback onTap;
  final double rotation;

  const MenuCard({
    super.key,
    required this.title,
    required this.description,
    required this.color,
    required this.icon,
    required this.isActive,
    required this.onTap,
    this.rotation = 0.0,
  });

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: rotation,
      child: Container(
        width: 320,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.black, width: 4),
          boxShadow: const [
            BoxShadow(color: Colors.black, offset: Offset(8, 8), blurRadius: 0),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 22,
                decoration: BoxDecoration(
                  color: color,
                  border: const Border(
                    bottom: BorderSide(color: Colors.black, width: 3),
                  ),
                ),
              ),
              Expanded(
                child: Stack(
                  children: [
                    Positioned(
                      right: -30,
                      top: -30,
                      child: Container(
                        width: 200,
                        height: 200,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: color.withValues(alpha: 0.08),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color: color,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                      color: Colors.black, width: 3),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Colors.black,
                                        offset: Offset(3, 3),
                                        blurRadius: 0),
                                  ],
                                ),
                                child: Icon(icon,
                                    color: Colors.white, size: 30),
                              ),
                              Transform.rotate(
                                angle: 0.05,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFFFD54F),
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                        color: Colors.black, width: 2.5),
                                    boxShadow: const [
                                      BoxShadow(
                                          color: Colors.black,
                                          offset: Offset(2, 2),
                                          blurRadius: 0),
                                    ],
                                  ),
                                  child: Text(
                                    isActive ? "RAT" : "LOCK",
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w900,
                                        fontSize: 12),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const Spacer(),
                          Stack(
                            children: [
                              Positioned(
                                left: 2,
                                top: 2,
                                child: Text(
                                  title,
                                  style: TextStyle(
                                    fontSize: 30,
                                    fontWeight: FontWeight.w900,
                                    fontStyle: FontStyle.italic,
                                    color: Colors.black.withValues(alpha: 0.12),
                                  ),
                                ),
                              ),
                              Text(
                                title,
                                style: const TextStyle(
                                  fontSize: 30,
                                  fontWeight: FontWeight.w900,
                                  fontStyle: FontStyle.italic,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            description,
                            style: const TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                                height: 1.4),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 18),
                          GestureDetector(
                            onTap: onTap,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 12),
                              decoration: BoxDecoration(
                                color: color,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    color: Colors.black, width: 3),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Colors.black,
                                      offset: Offset(3, 3),
                                      blurRadius: 0),
                                ],
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    isActive ? "BUKA MENU" : "COMING SOON",
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w900,
                                      fontStyle: FontStyle.italic,
                                      fontSize: 13,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  const Icon(Icons.arrow_forward,
                                      color: Colors.white, size: 16),
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 3. HALAMAN TUJUAN (DEVICE DASHBOARD)
// ==========================================
class DeviceDashboardPage extends StatelessWidget {
  const DeviceDashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF6E3),
      appBar: AppBar(
        title: const Text("Device Dashboard",
            style: TextStyle(
                fontWeight: FontWeight.w900, fontStyle: FontStyle.italic)),
        backgroundColor: const Color(0xFFE53935),
        foregroundColor: Colors.white,
        shape: const Border(
          bottom: BorderSide(color: Colors.black, width: 3),
        ),
      ),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.check_circle, color: Colors.green, size: 80),
              SizedBox(height: 20),
              Text(
                "Selamat Datang di NEBULAXRAT",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 10),
              Text(
                "Halaman ini hanya bisa diakses oleh menu NEBULAXRAT.",
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 4. BACKGROUND PATTERN KOMIK
// ==========================================
class ComicBackgroundPattern extends StatelessWidget {
  const ComicBackgroundPattern({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: ComicDotPainter(),
      size: Size.infinite,
    );
  }
}

class ComicDotPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final bgPaint = Paint()..color = const Color(0xFFFDF6E3);
    canvas.drawRect(Offset.zero & size, bgPaint);

    final dotPaint = Paint()
      ..color = Colors.grey.withValues(alpha: 0.18)
      ..style = PaintingStyle.fill;

    const double spacing = 18.0;
    const double radius = 1.8;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ==========================================
// 5. DEKORASI KOMIK
// ==========================================
class ComicDecorations extends StatelessWidget {
  const ComicDecorations({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned(
          left: 30,
          top: 180,
          child: Transform.rotate(
            angle: 0.3,
            child: const Icon(Icons.star, color: Color(0xFF42A5F5), size: 20),
          ),
        ),
        Positioned(
          right: 40,
          top: 400,
          child: Transform.rotate(
            angle: -0.2,
            child: const Icon(Icons.star, color: Color(0xFFEF5350), size: 24),
          ),
        ),
        Positioned(
          right: 100,
          top: 100,
          child: Transform.rotate(
            angle: 0.5,
            child: const Icon(Icons.star, color: Color(0xFFFFCA28), size: 16),
          ),
        ),
        Positioned(
          left: 20,
          bottom: 220,
          child: CustomPaint(
            painter: ZigzagPainter(color: const Color(0xFFFFCA28)),
            size: const Size(40, 20),
          ),
        ),
        Positioned(
          right: 30,
          bottom: 350,
          child: CustomPaint(
            painter: ZigzagPainter(color: const Color(0xFF42A5F5)),
            size: const Size(40, 20),
          ),
        ),
        Positioned(
          left: -20,
          bottom: 100,
          child: Transform.rotate(
            angle: 0.6,
            child: Container(
              width: 60,
              height: 2,
              color: Colors.grey.withValues(alpha: 0.4),
            ),
          ),
        ),
        Positioned(
          right: -20,
          top: 200,
          child: Transform.rotate(
            angle: -0.6,
            child: Container(
              width: 80,
              height: 2,
              color: Colors.grey.withValues(alpha: 0.3),
            ),
          ),
        ),
      ],
    );
  }
}

// ==========================================
// 6. ZIGZAG PAINTER
// ==========================================
class ZigzagPainter extends CustomPainter {
  final Color color;

  ZigzagPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final path = Path();
    final double step = size.width / 4;
    path.moveTo(0, size.height / 2);
    for (int i = 0; i < 4; i++) {
      path.lineTo(step * i + step / 2, i.isEven ? 0 : size.height);
      path.lineTo(step * (i + 1), size.height / 2);
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ==========================================
// 7. MASKOT KARAKTER KOMIK
// ==========================================
class ComicMascot extends StatelessWidget {
  const ComicMascot({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 70,
      height: 90,
      child: Stack(
        children: [
          Positioned(
            top: 0,
            left: 5,
            child: Container(
              width: 60,
              height: 22,
              decoration: BoxDecoration(
                color: const Color(0xFFFFC107),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: Colors.black, width: 2.5),
              ),
            ),
          ),
          Positioned(
            top: 18,
            left: 10,
            child: Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: const Color(0xFFFFCC80),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.black, width: 2.5),
              ),
            ),
          ),
          Positioned(
            top: 38,
            left: 22,
            child: Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                color: Colors.black,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            top: 38,
            left: 42,
            child: Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                color: Colors.black,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            top: 50,
            left: 28,
            child: Container(
              width: 20,
              height: 8,
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(color: Colors.black, width: 2),
                ),
              ),
            ),
          ),
          Positioned(
            top: 65,
            left: 15,
            child: Container(
              width: 40,
              height: 25,
              decoration: BoxDecoration(
                color: const Color(0xFFE53935),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.black, width: 2.5),
              ),
            ),
          ),
        ],
      ),
    );
  }
}