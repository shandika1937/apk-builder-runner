import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'api_config.dart';

// ─── COMIC THEME (RED, YELLOW, WHITE) ──────────────────────────
const _kBg      = Color(0xFFFDF6E3);        // Krem terang seperti kertas komik
const _kCard    = Color(0xFFFFFFFF);         // Putih untuk kartu
const _kBorder  = Color(0xFF1A1A1A);         // Hitam tebal untuk border komik
const _kRed     = Color(0xFFE53935);         // Merah komik
const _kRedDark = Color(0xFFC62828);         // Merah gelap
const _kYellow  = Color(0xFFFFD600);         // Kuning komik
const _kWhite   = Colors.white;
const _kBlack   = Color(0xFF1A1A1A);          // Hitam teks
const _kGrey    = Color(0xFF757575);          // Abu-abu teks

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late VideoPlayerController _videoCtrl;
  late AnimationController _pulseCtrl;

  final _targetCtrl = TextEditingController();
  final _bugPageCtrl = PageController(viewportFraction: 0.88);

  String? _selectedBugId;
  bool _isSending = false;
  String? _responseMessage;
  int _currentBugPage = 0;

  List<String> _globalSenders = [];
  bool _isLoadingSenders = false;
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _loadingSender = false;
  Timer? _senderTimer;
  String _selectedSender = 'private';

  int _remainingQuota = 7;
  int _maxQuota = 7;

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return r == 'owner' || r == 'admin' || r == 'moderator' ||
        r == 'partner' || r == 'vip';
  }

  @override
  void initState() {
    super.initState();

    _videoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoCtrl.setLooping(true);
        _videoCtrl.setVolume(0.0);
        _videoCtrl.play();
      });

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _fetchSenderStats();
    _loadGlobalSenders();
    _senderTimer = Timer.periodic(const Duration(seconds: 30), (_) => _fetchSenderStats());

    if (widget.listBug.isNotEmpty) {
      _selectedBugId = widget.listBug[0]['bug_id'] as String? ?? '0';
    }
  }

  @override
  void dispose() {
    _videoCtrl.dispose();
    _pulseCtrl.dispose();
    _targetCtrl.dispose();
    _bugPageCtrl.dispose();
    _senderTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchSenderStats() async {
    if (_loadingSender) return;
    setState(() => _loadingSender = true);
    try {
      final res = await http.get(Uri.parse(
        'http://panel-icxninh.ryuuuprv.my.id:2002/getSenderStats?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount  = data['global'] ?? 0;
            _remainingQuota     = data['remaining'] ?? 7;
            _maxQuota           = data['max'] ?? 7;
          });
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingSender = false);
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
        'http://panel-icxninh.ryuuuprv.my.id:2002/getActiveSenders?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null && mounted) {
        setState(() {
          _globalSenders     = List<String>.from(data['senders']);
          _globalSenderCount = _globalSenders.length;
        });
      } else if (mounted) {
        setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  String? _formatPhone(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMessage = '$type|$msg');
  }

  Future<void> _sendBug() async {
    final raw = _targetCtrl.text.trim();
    if (_formatPhone(raw) == null) {
      _showAlert('❌ Nomor Tidak Valid', 'Gunakan format internasional.\nContoh: +62812xxxxxxxx');
      return;
    }
    if (_selectedSender == 'global' && !canAccessGlobalSender) {
      _showAlert('❌ Akses Ditolak', 'Sender Global hanya untuk VIP, Admin, Owner.');
      return;
    }
    if (_selectedBugId == null || _selectedBugId!.isEmpty) {
      _showAlert('❌ No Bug Selected', 'Pilih 1 bug untuk dikirim.');
      return;
    }
    if (_selectedSender == 'private' && _privateSenderCount == 0) {
      _showAlert('❌ No Private Sender', 'Tidak ada private sender tersedia.');
      return;
    }
    if (_selectedSender == 'global' && _globalSenderCount == 0) {
      _showAlert('❌ No Global Sender', 'Tidak ada global sender tersedia.');
      return;
    }

    setState(() { _isSending = true; _responseMessage = null; });
    try {
      final encodedTarget = Uri.encodeComponent(raw);
      final res = await http.get(Uri.parse(
        'http://panel-icxninh.ryuuuprv.my.id:2002/sendBug'
        '?key=${widget.sessionKey}'
        '&target=$encodedTarget'
        '&bug=${_selectedBugId}'
        '${_selectedSender == 'global' ? '&senderMode=global' : '&sender=private'}',
      )).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        _setResponse('error', 'Session key tidak valid. Silakan login ulang.');
      } else if (data['cooldown'] == true) {
        _setResponse('warning', 'Cooldown aktif! Tunggu ${data['wait'] ?? 0} detik lagi.');
      } else if (data['sended'] == true) {
        _setResponse('success', 'Bug berhasil dikirim ke $raw! [${data['role'] ?? widget.role}]');
        _targetCtrl.clear();
        _fetchSenderStats();
      } else {
        _setResponse('error', 'Gagal mengirim. Server sedang maintenance.');
      }
    } on Exception catch (e) {
      _setResponse('error', e.toString().contains('Timeout')
          ? 'Request timeout. Periksa koneksi internet.'
          : 'Koneksi error. Coba lagi.');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: _kWhite,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: _kBorder, width: 3), // Border komik
          ),
          title: Text(title, style: const TextStyle(
            color: _kRed, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 15,
          )),
          content: Text(msg, style: const TextStyle(
            color: _kBlack, fontFamily: 'ShareTechMono', fontSize: 13, height: 1.5,
          )),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK', style: TextStyle(
                color: _kRed, fontWeight: FontWeight.bold, fontFamily: 'Orbitron',
              )),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BANNER VIDEO (Comic Style) ──────────────────────────────
  Widget _buildBannerVideo() {
    return Container(
      height: 210,
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        border: Border.all(color: _kBorder, width: 4),
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(color: _kBorder, offset: Offset(4, 4), blurRadius: 0),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          fit: StackFit.expand,
          children: [
            _videoCtrl.value.isInitialized
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoCtrl.value.size.width,
                      height: _videoCtrl.value.size.height,
                      child: VideoPlayer(_videoCtrl),
                    ),
                  )
                : Container(color: _kCard),
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.black87],
                ),
              ),
            ),
            Positioned(
              bottom: 20, left: 0, right: 0,
              child: Center(
                child: Text(
                  'NEBULA BUG',
                  style: TextStyle(
                    color: _kWhite,
                    fontSize: 34,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 8,
                    shadows: [
                      Shadow(color: _kRed.withOpacity(0.8), blurRadius: 20),
                      const Shadow(color: Colors.black, blurRadius: 4),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── NOMOR TARGET CARD (Comic Style) ──────────────────────────
  Widget _buildNomorTarget() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _kRed, // Background merah
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kBorder, width: 4),
        boxShadow: const [
          BoxShadow(color: _kBorder, offset: Offset(4, 4), blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _kWhite,
                  border: Border.all(color: _kBorder, width: 2),
                ),
                child: const Icon(Icons.phone_android_rounded, color: _kRed, size: 20),
              ),
              const SizedBox(width: 12),
              const Text('NOMOR TARGET', style: TextStyle(
                color: _kWhite, fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 2,
              )),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            decoration: BoxDecoration(
              color: _kWhite,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _kBorder, width: 2),
            ),
            child: TextField(
              controller: _targetCtrl,
              style: const TextStyle(
                color: _kBlack,
                fontFamily: 'ShareTechMono',
                fontSize: 15,
              ),
              cursorColor: _kRed,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                hintText: '62xxxxxxxxxxx',
                hintStyle: TextStyle(
                  color: _kBlack.withOpacity(0.4),
                  fontFamily: 'ShareTechMono',
                ),
                prefixIcon: const Icon(
                  Icons.public_rounded,
                  color: Colors.blueAccent,
                  size: 22,
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── PILIH BUG PANEL (Comic Style) ─────────────────────────────
  Widget _buildPilihBug() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _kRed, // Background merah
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kBorder, width: 4),
        boxShadow: const [
          BoxShadow(color: _kBorder, offset: Offset(4, 4), blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _kWhite,
                  border: Border.all(color: _kBorder, width: 2),
                ),
                child: const Icon(Icons.bug_report_rounded, color: _kRed, size: 20),
              ),
              const SizedBox(width: 10),
              const Text('PILIH BUG', style: TextStyle(
                color: _kWhite, fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 2,
              )),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: _kWhite,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _kBorder, width: 2),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Container(width: 8, height: 8,
                    decoration: const BoxDecoration(color: Color(0xFF00CC66), shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 6),
                  const Text('Engine lokal aktif', style: TextStyle(
                    color: _kBlack, fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.bold
                  )),
                ]),
              ),
            ],
          ),
          const SizedBox(height: 14),

          SizedBox(
            height: 160,
            child: widget.listBug.isEmpty
                ? const Center(child: Text('Tidak ada bug tersedia.',
                    style: TextStyle(color: _kWhite, fontFamily: 'ShareTechMono')))
                : PageView.builder(
                    controller: _bugPageCtrl,
                    itemCount: widget.listBug.length,
                    onPageChanged: (i) => setState(() {
                      _currentBugPage = i;
                      _selectedBugId = widget.listBug[i]['bug_id'] as String? ?? '$i';
                    }),
                    itemBuilder: (ctx, i) {
                      final bug = widget.listBug[i];
                      final bugId = bug['bug_id'] as String? ?? '$i';
                      final isSelected = _selectedBugId == bugId;

                      return GestureDetector(
                        onTap: () => setState(() => _selectedBugId = bugId),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.only(right: 10),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: isSelected ? _kYellow : _kWhite,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: _kBorder, width: 2),
                            boxShadow: const [
                              BoxShadow(color: _kBorder, offset: Offset(2, 2), blurRadius: 0),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    width: 40, height: 40,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: isSelected ? _kRed : _kBorder.withOpacity(0.1),
                                      border: Border.all(color: _kBorder, width: 2),
                                    ),
                                    child: Icon(Icons.shield_rounded,
                                      color: isSelected ? _kWhite : _kBlack.withOpacity(0.4), size: 22),
                                  ),
                                  if (isSelected)
                                    Container(
                                      width: 28, height: 28,
                                      decoration: const BoxDecoration(
                                        color: Color(0xFF00CC66), shape: BoxShape.circle,
                                        border: Border.fromBorderSide(BorderSide(color: _kBorder, width: 2)),
                                      ),
                                      child: const Icon(Icons.check_rounded, color: _kWhite, size: 16),
                                    ),
                                ],
                              ),
                              const Spacer(),
                              Text(
                                (bug['bug_name'] as String? ?? 'BUG').toUpperCase(),
                                style: const TextStyle(
                                  color: _kBlack,
                                  fontFamily: 'Orbitron',
                                  fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 0.5,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _kWhite,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: _kBorder, width: 1),
                                ),
                                child: Text(
                                  bug['bug_id']?.toString().toLowerCase() ?? 'bug',
                                  style: const TextStyle(
                                    color: _kBlack,
                                    fontFamily: 'ShareTechMono', fontSize: 10,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 12),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(widget.listBug.length, (i) {
              final active = i == _currentBugPage;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: active ? 22 : 7, height: 7,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: active ? _kWhite : _kWhite.withOpacity(0.4),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  // ─── PILIH SENDER PANEL (Comic Style) ─────────────────────────
  Widget _buildSenderPanel() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _kRed, // Background merah
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kBorder, width: 4),
        boxShadow: const [
          BoxShadow(color: _kBorder, offset: Offset(4, 4), blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34, height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _kWhite,
                  border: Border.all(color: _kBorder, width: 2),
                ),
                child: const Icon(Icons.swap_horiz_rounded, color: _kRed, size: 18),
              ),
              const SizedBox(width: 10),
              const Text('PILIH SENDER', style: TextStyle(
                color: _kWhite, fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1,
              )),
              const Spacer(),
              GestureDetector(
                onTap: () { _fetchSenderStats(); _loadGlobalSenders(); },
                child: _isLoadingSenders || _loadingSender
                    ? const SizedBox(width: 16, height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: _kWhite))
                    : const Icon(Icons.refresh_rounded, color: _kWhite, size: 20),
              ),
              const SizedBox(width: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: _kWhite,
                  border: Border.all(color: _kBorder, width: 2),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.circle, color: Color(0xFF00CC66), size: 7),
                  const SizedBox(width: 5),
                  Text(
                    _loadingSender
                        ? '-- WA'
                        : 'WA : ${_privateSenderCount + _globalSenderCount}',
                    style: const TextStyle(
                      color: _kBlack, fontFamily: 'ShareTechMono', fontSize: 10, fontWeight: FontWeight.bold
                    ),
                  ),
                ]),
              ),
            ],
          ),
          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _selectedSender = 'private'),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 150,
                    decoration: BoxDecoration(
                      color: _selectedSender == 'private' ? _kYellow : _kWhite,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: _kBorder, width: 3),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.person_rounded,
                          color: _selectedSender == 'private' ? _kRed : _kBlack.withOpacity(0.4),
                          size: 40),
                        const SizedBox(height: 8),
                        Text('Pribadi', style: TextStyle(
                          color: _selectedSender == 'private' ? _kRed : _kBlack.withOpacity(0.7),
                          fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14,
                        )),
                        const SizedBox(height: 6),
                        _privateSenderCount == 0
                            ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                const Icon(Icons.close_rounded, color: Colors.redAccent, size: 14),
                                const SizedBox(width: 4),
                                const Text('Kosong', style: TextStyle(
                                  color: Colors.redAccent, fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.bold, fontSize: 12,
                                )),
                              ])
                            : Text('$_privateSenderCount sender', style: TextStyle(
                                color: _selectedSender == 'private' ? _kRedDark : _kGrey,
                                fontFamily: 'ShareTechMono', fontSize: 12, fontWeight: FontWeight.bold
                              )),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),

              Expanded(
                child: GestureDetector(
                  onTap: () {
                    if (!canAccessGlobalSender) {
                      _showAlert('❌ Akses Ditolak', 'Sender Global hanya untuk VIP, Admin, Owner.');
                      return;
                    }
                    setState(() => _selectedSender = 'global');
                    _loadGlobalSenders();
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 150,
                    decoration: BoxDecoration(
                      color: _selectedSender == 'global' ? _kYellow : _kWhite,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: _kBorder, width: 3),
                    ),
                    child: Stack(
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(width: double.infinity),
                            Icon(Icons.public_rounded,
                              color: _selectedSender == 'global' ? _kRed : _kBlack.withOpacity(0.4),
                              size: 40),
                            const SizedBox(height: 8),
                            Text('Global', style: TextStyle(
                              color: _selectedSender == 'global' ? _kRed : _kBlack.withOpacity(0.7),
                              fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14,
                            )),
                            const SizedBox(height: 6),
                            _globalSenderCount == 0
                                ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                    const Icon(Icons.close_rounded, color: Colors.redAccent, size: 14),
                                    const SizedBox(width: 4),
                                    const Text('Kosong', style: TextStyle(
                                      color: Colors.redAccent, fontFamily: 'ShareTechMono',
                                      fontWeight: FontWeight.bold, fontSize: 12,
                                    )),
                                  ])
                                : Text('$_globalSenderCount sender', style: TextStyle(
                                    color: _selectedSender == 'global' ? _kRedDark : _kGrey,
                                    fontFamily: 'ShareTechMono', fontSize: 12, fontWeight: FontWeight.bold
                                  )),
                          ],
                        ),
                        if (!canAccessGlobalSender)
                          Positioned(top: 8, right: 8,
                            child: Container(
                              width: 22, height: 22,
                              decoration: const BoxDecoration(
                                color: Colors.amber, shape: BoxShape.circle,
                                border: Border.fromBorderSide(BorderSide(color: _kBorder, width: 2)),
                              ),
                              child: const Icon(Icons.lock_rounded, color: _kWhite, size: 12),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          Row(
            children: [
              const Icon(Icons.info_outline_rounded, color: _kWhite, size: 14),
              const SizedBox(width: 6),
              Text(
                'Sisa kirim global hari ini: $_remainingQuota / $_maxQuota',
                style: const TextStyle(
                  color: _kWhite, fontFamily: 'ShareTechMono', fontSize: 11,
                ),
              ),
            ],
          ),

          if (_selectedSender == 'global' && _globalSenders.isNotEmpty) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _kWhite,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _kBorder, width: 2),
              ),
              child: Column(
                children: [
                  ..._globalSenders.take(3).map((s) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(
                      children: [
                        const Icon(Icons.circle, color: Color(0xFF00CC66), size: 7),
                        const SizedBox(width: 8),
                        Text(s, style: const TextStyle(
                          color: _kBlack, fontFamily: 'ShareTechMono', fontSize: 11, fontWeight: FontWeight.bold
                        )),
                      ],
                    ),
                  )),
                  if (_globalSenders.length > 3)
                    Text('+ ${_globalSenders.length - 3} lainnya...',
                      style: TextStyle(color: _kGrey.withOpacity(0.6), fontSize: 10)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ─── RESPONSE BANNER (Comic Style) ─────────────────────────────
  Widget _buildResponse() {
    if (_responseMessage == null) return const SizedBox.shrink();
    final parts = _responseMessage!.split('|');
    final type  = parts[0];
    final msg   = parts.length > 1 ? parts[1] : '';

    Color color;
    IconData icon;
    String title;
    switch (type) {
      case 'success':  color = const Color(0xFF00CC66); icon = Icons.check_circle_outline; title = 'Berhasil'; break;
      case 'warning':  color = Colors.amber;            icon = Icons.warning_rounded;       title = 'Peringatan'; break;
      default:         color = Colors.redAccent;        icon = Icons.error_outline;         title = 'Gagal';
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _kWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kBorder, width: 3),
        boxShadow: const [
          BoxShadow(color: _kBorder, offset: Offset(3, 3), blurRadius: 0),
        ],
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 32, height: 32,
          decoration: BoxDecoration(
            shape: BoxShape.circle, color: color.withOpacity(0.15),
            border: Border.all(color: _kBorder, width: 2),
          ),
          child: Icon(icon, color: color, size: 18)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(
            color: color, fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.bold,
          )),
          const SizedBox(height: 2),
          Text(msg, style: const TextStyle(
            color: _kBlack, fontFamily: 'ShareTechMono', fontSize: 12, height: 1.4,
          )),
        ])),
        GestureDetector(
          onTap: () => setState(() => _responseMessage = null),
          child: const Icon(Icons.close_rounded, color: _kGrey, size: 16),
        ),
      ]),
    );
  }

  // ─── KIRIM BUG BUTTON (Comic Style) ────────────────────────────
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            color: _kRed,
            border: Border.all(color: _kBorder, width: 4),
            boxShadow: const [
              BoxShadow(color: _kBorder, offset: Offset(4, 4), blurRadius: 0),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), elevation: 0,
            ),
            child: _isSending
                ? const SizedBox(width: 26, height: 26,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3))
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.play_arrow_rounded, color: Colors.white, size: 26),
                      SizedBox(width: 10),
                      Text('KIRIM BUG', style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w900,
                        fontSize: 16, fontFamily: 'Orbitron', letterSpacing: 2,
                      )),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  // ─── FOOTER (Comic Style) ──────────────────────────────────────
  Widget _buildFooter() {
    return Column(
      children: [
        Text('NEBULA TEAM', style: TextStyle(
          color: _kBlack.withOpacity(0.5), fontFamily: 'Orbitron',
          fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold
        )),
        const SizedBox(height: 4),
        Text('© 2026 NEBULA Always For You', style: TextStyle(
          color: _kBlack.withOpacity(0.4), fontFamily: 'ShareTechMono', fontSize: 10,
        )),
      ],
    );
  }

  // ─── APP BAR (Comic Style) ─────────────────────────────────────
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _kWhite,
                border: Border.all(color: _kBorder, width: 3),
                boxShadow: const [
                  BoxShadow(color: _kBorder, offset: Offset(2, 2), blurRadius: 0),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded, color: _kBlack, size: 16),
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            decoration: BoxDecoration(
              color: _kRed,
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: _kBorder, width: 3),
              boxShadow: const [
                BoxShadow(color: _kBorder, offset: Offset(3, 3), blurRadius: 0),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 20, height: 20,
                  decoration: const BoxDecoration(color: _kWhite, shape: BoxShape.circle),
                  child: const Icon(Icons.circle, color: _kRed, size: 10),
                ),
                const SizedBox(width: 8),
                const Text('NEBULA BUG', style: TextStyle(
                  color: _kWhite, fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1,
                )),
              ],
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: () { _fetchSenderStats(); _loadGlobalSenders(); },
            child: Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _kWhite,
                border: Border.all(color: _kBorder, width: 3),
                boxShadow: const [
                  BoxShadow(color: _kBorder, offset: Offset(2, 2), blurRadius: 0),
                ],
              ),
              child: const Icon(Icons.refresh_rounded, color: _kBlack, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: Stack(
        children: [
          Positioned.fill(child: Container(color: _kBg)),
          SafeArea(
            child: Column(
              children: [
                _buildAppBar(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      children: [
                        _buildBannerVideo(),
                        const SizedBox(height: 20),
                        _buildNomorTarget(),
                        const SizedBox(height: 20),
                        _buildPilihBug(),
                        const SizedBox(height: 20),
                        _buildSenderPanel(),
                        const SizedBox(height: 20),
                        _buildResponse(),
                        if (_responseMessage != null) const SizedBox(height: 14),
                        _buildSendButton(),
                        const SizedBox(height: 20),
                        _buildFooter(),
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}