package com.example.sampleapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val textView = TextView(this).apply {
            text = "Hello from Android APK Builder! 🚀\nReal APK generated successfully."
            textSize = 20f
            setPadding(40, 80, 40, 40)
        }
        setContentView(textView)
    }
}
