package com.nullx.cyyberrr;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
