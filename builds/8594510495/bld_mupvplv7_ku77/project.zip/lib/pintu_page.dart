import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'landing.dart'; // Pastikan file landing.dart ada

class PintuPage extends StatefulWidget {
  const PintuPage({super.key});

  @override
  State<PintuPage> createState() => _PintuPageState();
}

class _PintuPageState extends State<PintuPage> with TickerProviderStateMixin {
  late AnimationController _doorController;
  late AnimationController _textController;
  late AnimationController _pulseController;
  late AnimationController _shakeController;

  late Animation<double> _doorAnimation;
  late Animation<double> _textScaleAnimation;
  late Animation<double> _textOpacityAnimation;
  late Animation<double> _signboardOpacityAnimation;
  late Animation<double> _signboardOffsetAnimation;
  late Animation<double> _shakeAnimation;

  bool _isOpen = false;
  bool _showRipple = false;
  bool _hasNavigated = false;

  @override
  void initState() {
    super.initState();

    // 1. Controller Animasi Pintu Terbuka
    _doorController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    );
    _doorAnimation = CurvedAnimation(
      parent: _doorController,
      curve: const Cubic(0.19, 1.0, 0.22, 1.0),
    );

    // 2. Controller Teks NEBULA Muncul
    _textController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4000),
    );
    _textScaleAnimation = Tween<double>(begin: 3.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _textController,
        curve: const Cubic(0.19, 1.0, 0.22, 1.0),
      ),
    );
    _textOpacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _textController,
        curve: const Interval(0.0, 0.4, curve: Curves.easeIn),
      ),
    );

    // 3. Controller Signboard Menghilang
    _signboardOpacityAnimation = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(
        parent: _doorController,
        curve: const Interval(0.0, 0.6, curve: Curves.easeInOut),
      ),
    );
    _signboardOffsetAnimation = Tween<double>(begin: 0.0, end: -3.0).animate(
      CurvedAnimation(
        parent: _doorController,
        curve: const Cubic(0.19, 1.0, 0.22, 1.0),
      ),
    );

    // 4. Controller Pulse (Ketuk Pintu)
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    )..repeat();

    // 5. Controller Getaran (Shake Effect)
    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _shakeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _shakeController, curve: Curves.elasticIn),
    );

    // Listener: Selesai animasi pintu -> Pindah Halaman
    _doorController.addStatusListener((status) {
      if (status == AnimationStatus.completed && !_hasNavigated) {
        _hasNavigated = true;
        _navigateToLanding();
      }
    });
  }

  void _navigateToLanding() {
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (context, animation, secondaryAnimation) =>
              const LandingPage(),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            return FadeTransition(
              opacity: CurvedAnimation(
                parent: animation,
                curve: Curves.easeInOut,
              ),
              child: child,
            );
          },
          transitionDuration: const Duration(milliseconds: 1200),
        ),
      );
    });
  }

  @override
  void dispose() {
    _doorController.dispose();
    _textController.dispose();
    _pulseController.dispose();
    _shakeController.dispose();
    super.dispose();
  }

  // Fungsi saat pintu diketuk
  void _onTap() {
    if (_isOpen) return;

    // 1. Efek Visual Getaran
    _shakeController.forward(from: 0.0);
    HapticFeedback.heavyImpact();

    // 2. Mainkan Suara Pintu (Menggunakan SystemSound bawaan)
    SystemSound.play(SystemSoundType.click);

    // 3. Efek Ripple (Gelombang)
    setState(() => _showRipple = true);
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) setState(() => _showRipple = false);
    });

    // 4. Buka Pintu Setelah Jeda
    Future.delayed(const Duration(milliseconds: 800), () {
      if (!mounted) return;
      setState(() => _isOpen = true);
      _doorController.forward();
      _textController.forward();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: GestureDetector(
          onTap: _onTap,
          child: AnimatedBuilder(
            animation: _shakeAnimation,
            builder: (context, child) {
              // Efek getaran saat diketuk
              final dx = math.sin(_shakeAnimation.value * math.pi * 10) *
                  5 *
                  (1 - _shakeAnimation.value);
              return Transform.translate(
                offset: Offset(dx, 0),
                child: child,
              );
            },
            child: SizedBox(
              width: 380,
              height: 700,
              child: Stack(
                children: [
                  _buildRoomBehind(),
                  _buildDoorFrame(),
                  _buildShadowOverlay(),
                  _buildDoor(isLeft: true),
                  _buildDoor(isLeft: false),
                  _buildSignboard(),
                  if (_showRipple) _buildRipple(),
                  ..._buildDustParticles(),
                  _buildInstruction(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ================= WIDGET BUILDERS =================

  // 1. Ruangan Gelap & Teks NEBULA di belakang pintu
  Widget _buildRoomBehind() {
    return Positioned.fill(
      child: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 0.7,
            colors: [Color(0xFF0F0F0F), Color(0xFF050505), Color(0xFF000000)],
            stops: [0.0, 0.4, 0.8],
          ),
        ),
        child: Center(
          child: AnimatedBuilder(
            animation: _textController,
            builder: (context, child) {
              return Opacity(
                opacity: _textOpacityAnimation.value,
                child: Transform.scale(
                  scale: _textScaleAnimation.value,
                  child: child,
                ),
              );
            },
            // MENGGUNAKAN FONT ORBITRON DARI PUBSPEC YAML
            child: Text(
              'NEBULA',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 80,
                color: Color(0xFFC9A84C),
                fontWeight: FontWeight.w900,
                letterSpacing: 15,
                shadows: [
                  Shadow(color: Color(0xE6C9A84C), blurRadius: 10),
                  Shadow(color: Color(0xB3A88B4A), blurRadius: 30),
                  Shadow(color: Color(0x80A88B4A), blurRadius: 60),
                  Shadow(color: Color(0x4DA88B4A), blurRadius: 120),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // 2. Bingkai Pintu (Frame)
  Widget _buildDoorFrame() {
    return Positioned.fill(
      child: IgnorePointer(
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF050505), width: 28),
            boxShadow: const [
              BoxShadow(color: Colors.black, blurRadius: 80, spreadRadius: 10),
            ],
          ),
          child: Container(
            margin: const EdgeInsets.all(-22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: const Color(0xFF1A1A1A), width: 3),
            ),
          ),
        ),
      ),
    );
  }

  // 3. Overlay Bayangan
  Widget _buildShadowOverlay() {
    return Positioned.fill(
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _doorAnimation,
          builder: (context, child) {
            return Container(
              color: Colors.black.withOpacity(_doorAnimation.value * 0.7),
            );
          },
        ),
      ),
    );
  }

  // 4. Pintu Kiri & Kanan
  Widget _buildDoor({required bool isLeft}) {
    return Positioned(
      top: 0,
      left: isLeft ? 0 : null,
      right: isLeft ? null : 0,
      width: 190,
      height: 700,
      child: AnimatedBuilder(
        animation: _doorAnimation,
        builder: (context, child) {
          // Sudut bukaan pintu (115 derajat)
          final angle = _doorAnimation.value * (115 * math.pi / 180);
          return Transform(
            alignment: isLeft ? Alignment.centerLeft : Alignment.centerRight,
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.001) // Efek Perspektif 3D
              ..rotateY(isLeft ? -angle : angle)
              ..scale(1.0 + _doorAnimation.value * 0.2),
            child: Opacity(
              opacity: 1.0 - (_doorAnimation.value * 0.95),
              child: child,
            ),
          );
        },
        child: Stack(
          children: [
            // Panel Dasar Pintu
            Positioned.fill(
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF050505),
                      Color(0xFF151515),
                      Color(0xFF050505),
                    ],
                  ),
                ),
                child: CustomPaint(
                  painter: MetalTexturePainter(isLeft: isLeft),
                ),
              ),
            ),
            // Panel Berundak (Recessed Panel)
            Positioned(
              top: 60,
              left: 15,
              right: 15,
              bottom: 60,
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF080808),
                      Color(0xFF1A1A1A),
                      Color(0xFF080808),
                    ],
                  ),
                  border: Border.all(color: const Color(0xFF111111), width: 2),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black, blurRadius: 20, offset: Offset(0, 0)),
                  ],
                ),
                child: Container(
                  margin: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    border: Border.all(color: const Color(0xFF222222), width: 1),
                  ),
                ),
              ),
            ),
            // Engsel Atas & Bawah
            Positioned(
              top: 120,
              left: isLeft ? -2 : null,
              right: isLeft ? null : -2,
              child: _buildHinge(),
            ),
            Positioned(
              top: 520,
              left: isLeft ? -2 : null,
              right: isLeft ? null : -2,
              child: _buildHinge(),
            ),
            // Gagang Pintu Emas
            Positioned(
              top: 0,
              bottom: 0,
              left: isLeft ? null : 20,
              right: isLeft ? 20 : null,
              child: Center(child: _buildHandle()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHinge() {
    return Container(
      width: 14,
      height: 70,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(3),
        gradient: const LinearGradient(
          colors: [Color(0xFF050505), Color(0xFF333333), Color(0xFF050505)],
        ),
        boxShadow: const [BoxShadow(color: Colors.black, blurRadius: 15)],
      ),
    );
  }

  Widget _buildHandle() {
    return SizedBox(
      width: 24,
      height: 120,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Batang Gagang
          Container(
            width: 12,
            height: 90,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              gradient: const LinearGradient(
                colors: [
                  Color(0xFF2A1F0A),
                  Color(0xFFC9A84C),
                  Color(0xFFF0D890),
                  Color(0xFFC9A84C),
                  Color(0xFF2A1F0A),
                ],
              ),
              boxShadow: const [
                BoxShadow(color: Colors.black, blurRadius: 15),
                BoxShadow(color: Color(0x4DC9A84C), blurRadius: 10),
              ],
            ),
          ),
          // Mur Atas
          Positioned(
            top: 0,
            child: Container(
              width: 24,
              height: 12,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFF1A1205),
                    Color(0xFF8A6E2A),
                    Color(0xFF1A1205)
                  ],
                ),
              ),
            ),
          ),
          // Mur Bawah
          Positioned(
            bottom: 0,
            child: Container(
              width: 24,
              height: 12,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFF1A1205),
                    Color(0xFF8A6E2A),
                    Color(0xFF1A1205)
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 5. Signboard Gantung
  Widget _buildSignboard() {
    return AnimatedBuilder(
      animation: _doorController,
      builder: (context, child) {
        return Positioned(
          top: 220 + (_signboardOffsetAnimation.value * 250),
          left: 0,
          right: 0,
          child: Opacity(
            opacity: _signboardOpacityAnimation.value,
            child: Transform.scale(
              scale: 1.0 - (_doorAnimation.value * 0.5),
              child: child,
            ),
          ),
        );
      },
      child: Column(
        children: [
          // Rantai Gantung
          Container(
            width: 4,
            height: 70,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(2),
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF1A1A1A),
                  Color(0xFF555555),
                  Color(0xFF1A1A1A)
                ],
              ),
            ),
          ),
          // Kait Besi
          Container(
            width: 16,
            height: 16,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF111111),
              border: Border.all(color: const Color(0xFF444444), width: 3),
            ),
          ),
          const SizedBox(height: 5),
          // Papan Nama dengan Ornamen
          Center(
            child: CustomPaint(
              painter: SignboardOrnamentPainter(),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 45, vertical: 30),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF0A0A0A), Color(0xFF020202)],
                  ),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black, blurRadius: 20, spreadRadius: 5),
                  ],
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Teks "Welcome To" - Menggunakan ShareTechMono
                    Positioned(
                      top: -5,
                      child: const Text(
                        'Welcome To',
                        style: TextStyle(
                          fontFamily: 'ShareTechMono',
                          fontSize: 22,
                          color: Color(0xFFC9B18C),
                          letterSpacing: 2,
                          shadows: [
                            Shadow(
                              color: Color(0x80C9B18C),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                      ),
                    ),
                    // Teks "NEBULA" - Menggunakan Orbitron
                    Positioned(
                      bottom: -10,
                      child: const Text(
                        'NEBULA',
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          fontSize: 40,
                          color: Color(0xFFE0D0B0),
                          fontWeight: FontWeight.w800,
                          letterSpacing: 4,
                          shadows: [
                            Shadow(
                              color: Color(0x99E0D0B0),
                              blurRadius: 15,
                            ),
                            Shadow(
                              color: Color(0x4DE0D0B0),
                              blurRadius: 30,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 6. Efek Ripple (Gelombang Ketukan)
  Widget _buildRipple() {
    return Positioned.fill(
      child: IgnorePointer(
        child: Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.5, end: 8.0),
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeOut,
            builder: (context, scale, child) {
              final opacity = (1.0 - (scale - 0.5) / 7.5).clamp(0.0, 1.0);
              return Opacity(
                opacity: opacity,
                child: Transform.scale(
                  scale: scale,
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white.withOpacity(0.3),
                        width: 3,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  // 7. Partikel Debu
  List<Widget> _buildDustParticles() {
    final particles = [
      const Offset(0.3, 0.2),
      const Offset(0.7, 0.6),
      const Offset(0.5, 0.4),
      const Offset(0.2, 0.8),
      const Offset(0.8, 0.1),
    ];
    return particles.map((offset) {
      return Positioned(
        top: 700 * offset.dy,
        left: 380 * offset.dx,
        child: TweenAnimationBuilder<double>(
          tween: Tween(begin: 0.0, end: 1.0),
          duration: Duration(seconds: 8 + (offset.dx * 3).toInt()),
          builder: (context, value, child) {
            final y = -120 * value;
            final opacity = value < 0.5 ? value * 2 : (1 - value) * 2;
            return Transform.translate(
              offset: Offset(30 * value, y),
              child: Opacity(
                opacity: opacity * 0.4,
                child: Container(
                  width: 2.5,
                  height: 2.5,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.5),
                  ),
                ),
              ),
            );
          },
        ),
      );
    }).toList();
  }

  // 8. Instruksi "KETUK PINTU"
  Widget _buildInstruction() {
    return Positioned(
      bottom: 25,
      left: 0,
      right: 0,
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _pulseController,
          builder: (context, child) {
            final opacity = 0.1 +
                0.6 *
                    (0.5 +
                        0.5 * math.sin(_pulseController.value * math.pi * 2));
            return Opacity(opacity: opacity, child: child);
          },
          // Menggunakan ShareTechMono
          child: const Text(
            'KETUK PINTU',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'ShareTechMono',
              fontSize: 12,
              color: Colors.white,
              letterSpacing: 12,
              fontWeight: FontWeight.w300,
            ),
          ),
        ),
      ),
    );
  }
}

// ================= CUSTOM PAINTERS =================

// 1. Painter untuk Tekstur Logam & Paku Keling
class MetalTexturePainter extends CustomPainter {
  final bool isLeft;
  MetalTexturePainter({required this.isLeft});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;

    // Paku Keling Vertikal (Pinggir)
    paint.color = const Color(0xFF222222);
    for (double y = 15; y < size.height; y += 35) {
      canvas.drawCircle(Offset(10, y), 3.0, paint);
      canvas.drawCircle(Offset(size.width - 10, y), 3.0, paint);
    }

    // Paku Keling Horizontal (Atas & Bawah)
    paint.color = const Color(0xFF2A2A2A);
    for (double x = 30; x < size.width - 20; x += 45) {
      canvas.drawCircle(Offset(x, 35), 2.5, paint);
      canvas.drawCircle(Offset(x, size.height - 35), 2.5, paint);
    }

    // Gradien untuk Efek 3D
    final gradientPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Colors.white.withOpacity(0.05),
          Colors.transparent,
          Colors.black.withOpacity(0.8),
        ],
        stops: const [0.0, 0.3, 1.0],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), gradientPaint);
  }

  @override
  bool shouldRepaint(covariant MetalTexturePainter oldDelegate) =>
      oldDelegate.isLeft != isLeft;
}

// 2. Painter untuk Ornamen Ukiran Besi Signboard
class SignboardOrnamentPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF333333)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0;

    // Bingkai Utama
    final rect = Rect.fromLTWH(0, 0, size.width, size.height);
    final rrect = RRect.fromRectAndRadius(rect, const Radius.circular(12));
    canvas.drawRRect(rrect, paint);

    // Ornamen Melengkung Kiri & Kanan
    final ornamentPaint = Paint()
      ..color = const Color(0xFF444444)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;

    final pathLeft = Path()
      ..moveTo(0, size.height * 0.25)
      ..quadraticBezierTo(-20, size.height * 0.5, 0, size.height * 0.75);
    canvas.drawPath(pathLeft, ornamentPaint);

    final pathRight = Path()
      ..moveTo(size.width, size.height * 0.25)
      ..quadraticBezierTo(
          size.width + 20, size.height * 0.5, size.width, size.height * 0.75);
    canvas.drawPath(pathRight, ornamentPaint);

    // Aksen Titik Sudut
    final dotPaint = Paint()..color = const Color(0xFF555555);
    canvas.drawCircle(Offset(0, 0), 4, dotPaint);
    canvas.drawCircle(Offset(size.width, 0), 4, dotPaint);
    canvas.drawCircle(Offset(0, size.height), 4, dotPaint);
    canvas.drawCircle(Offset(size.width, size.height), 4, dotPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
