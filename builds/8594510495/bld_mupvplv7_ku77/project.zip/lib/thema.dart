import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pengaturan Tema',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: const Color(0xFFF7F2E7),
      ),
      home: const ThemaPage(),
    );
  }
}

class ThemaPage extends StatefulWidget {
  const ThemaPage({super.key});

  @override
  State<ThemaPage> createState() => _ThemaPageState();
}

class _ThemaPageState extends State<ThemaPage> {
  // 0 = SYAM Original, 1 = SYAM 3D Comic
  int _selectedThemeIndex = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Pattern (Titik-titik halus)
          Positioned.fill(
            child: CustomPaint(
              painter: DotPatternPainter(),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                // --- HEADER ---
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      vertical: 16, horizontal: 20),
                  color: const Color(0xFFD32F2F),
                  child: const Center(
                    child: Text(
                      'PENGATURAN TEMA',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        fontStyle: FontStyle.italic,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ),

                // --- CONTENT ---
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildModeTampilanCard(),
                        const SizedBox(height: 20),
                        _buildInfoKomikCard(),
                        const SizedBox(height: 20),
                        _buildContohTampilanCard(),
                        const SizedBox(height: 100),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Dekorasi Karakter di Pojok Kanan Bawah
          Positioned(
            bottom: 20,
            right: 20,
            child: _buildCharacterPlaceholder(),
          ),
        ],
      ),
    );
  }

  // --- WIDGET KARTU 1: MODE TAMPILAN ---
  Widget _buildModeTampilanCard() {
    return _buildBaseCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 4,
                height: 20,
                color: const Color(0xFFD32F2F),
              ),
              const SizedBox(width: 8),
              const Text(
                'MODE TAMPILAN',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontStyle: FontStyle.italic,
                  color: Color(0xFF222222),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'Pilih tampilan aplikasi. Tersimpan permanen di HP.',
            style: TextStyle(fontSize: 13, color: Colors.black87),
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _buildThemeOption(
                  index: 0,
                  title: 'SYAM Original',
                  subtitle: 'Palet warna bebas',
                  icon: Icons.image_outlined,
                  iconBgColor: const Color(0xFFFCE4EC),
                  iconColor: const Color(0xFFD32F2F),
                  isSelected: _selectedThemeIndex == 0,
                  showColorDots: true,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildThemeOption(
                  index: 1,
                  title: 'SYAM 3D COMIC',
                  subtitle: 'Kertas & tinta 3D',
                  icon: Icons.star,
                  iconBgColor: const Color(0xFFFFD54F),
                  iconColor: const Color(0xFF222222),
                  isSelected: _selectedThemeIndex == 1,
                  showColorDots: false,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // --- WIDGET KARTU 2: INFO KOMIK ---
  Widget _buildInfoKomikCard() {
    return _buildBaseCard(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline,
              color: Color(0xFF222222), size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'INFO KOMIK',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic,
                    color: Color(0xFFD32F2F),
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'Mode Comic memakai palet kertas & tinta tetap (merah, kuning, biru).\nPilihan warna aksen/latar dinonaktifkan — kembali ke SYAM Original untuk ganti warna.',
                  style: TextStyle(
                      fontSize: 13, color: Colors.black87, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- WIDGET KARTU 3: CONTOH TAMPILAN ---
  Widget _buildContohTampilanCard() {
    return _buildBaseCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'CONTOH TAMPILAN',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontStyle: FontStyle.italic,
              color: Color(0xFF222222),
            ),
          ),
          const SizedBox(height: 12),
          // Area Preview
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFFF7F2E7),
              border: Border.all(color: const Color(0xFF222222), width: 2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Badge "BARU!"
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: const Color(0xFFD32F2F),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                            color: const Color(0xFF222222), width: 2),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0xFF222222),
                            offset: Offset(3, 3),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: const Text(
                        'BARU!',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontStyle: FontStyle.italic,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    // Judul
                    const Text(
                      'WOW! KOMIK!',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                        fontStyle: FontStyle.italic,
                        color: Color(0xFFD32F2F),
                        letterSpacing: 1.2,
                        shadows: [
                          Shadow(
                            offset: Offset(2, 2),
                            color: Color(0xFF222222),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    // Deskripsi
                    const Text(
                      'Kartu, tombol, dan teks memakai gaya kertas & tinta 3D — border tebal, bayangan blok, dan huruf komik.',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.black87,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 20),
                    // Tombol-tombol
                    Wrap(
                      spacing: 12,
                      runSpacing: 8,
                      children: [
                        _buildComicButton('MULAI!',
                            const Color(0xFFD32F2F), Colors.white),
                        _buildComicButton('3D',
                            const Color(0xFFFFD54F), const Color(0xFF222222)),
                      ],
                    ),
                  ],
                ),
                // Bintang dekorasi di kanan atas
                const Positioned(
                  top: 0,
                  right: 0,
                  child: Icon(Icons.star,
                      color: Color(0xFFFFD54F), size: 30),
                ),
                const Positioned(
                  top: 15,
                  right: 25,
                  child: Icon(Icons.star,
                      color: Color(0xFFFFD54F), size: 15),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- HELPER WIDGETS ---

  Widget _buildBaseCard({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFDF5),
        border: Border.all(color: const Color(0xFF222222), width: 2.5),
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(
            color: Color(0xFF222222),
            offset: Offset(5, 5),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  // Opsi Tema (Kotak Pilihan)
  Widget _buildThemeOption({
    required int index,
    required String title,
    required String subtitle,
    required IconData icon,
    required Color iconBgColor,
    required Color iconColor,
    required bool isSelected,
    required bool showColorDots,
  }) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedThemeIndex = index;
        });
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFFFFDF5),
          border: Border.all(
            color: const Color(0xFF222222),
            width: isSelected ? 3 : 2,
          ),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF222222),
              offset: isSelected ? const Offset(4, 4) : const Offset(2, 2),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: iconBgColor,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                        color: const Color(0xFF222222), width: 1.5),
                  ),
                  child: Icon(icon, color: iconColor, size: 18),
                ),
                if (isSelected)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFD54F),
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(
                          color: const Color(0xFF222222), width: 1.5),
                    ),
                    child: const Text(
                      'AKTIF',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic,
                color: Color(0xFF222222),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: const TextStyle(fontSize: 11, color: Colors.black54),
            ),
            const SizedBox(height: 12),
            if (showColorDots)
              Row(
                children: [
                  _buildColorDot(const Color(0xFFD32F2F)),
                  const SizedBox(width: 6),
                  _buildColorDot(const Color(0xFFFFD54F)),
                  const SizedBox(width: 6),
                  _buildColorDot(const Color(0xFFFCE4EC)),
                ],
              )
            else
              Row(
                children: List.generate(
                  4,
                  (i) => Container(
                    width: 4,
                    height: 4,
                    margin: const EdgeInsets.only(right: 4),
                    decoration: const BoxDecoration(
                      color: Color(0xFF222222),
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildColorDot(Color color) {
    return Container(
      width: 16,
      height: 16,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFF222222), width: 1.5),
      ),
    );
  }

  Widget _buildComicButton(String text, Color bgColor, Color textColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: const Color(0xFF222222), width: 2),
        boxShadow: const [
          BoxShadow(
            color: Color(0xFF222222),
            offset: Offset(3, 3),
            blurRadius: 0,
          ),
        ],
      ),
      child: Text(
        text,
        style: TextStyle(
          color: textColor,
          fontWeight: FontWeight.bold,
          fontStyle: FontStyle.italic,
          fontSize: 14,
        ),
      ),
    );
  }

  // Placeholder untuk karakter di pojok kanan bawah
  Widget _buildCharacterPlaceholder() {
    return Container(
      width: 80,
      height: 80,
      decoration: BoxDecoration(
        color: const Color(0xFFD32F2F),
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFF222222), width: 3),
        boxShadow: const [
          BoxShadow(
            color: Color(0xFF222222),
            offset: Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: const Center(
        child: Icon(Icons.person, size: 50, color: Color(0xFFFFD54F)),
      ),
    );
  }
}

// --- CUSTOM PAINTER UNTUK BACKGROUND TITIK-TITIK ---
class DotPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFE0E0E0).withValues(alpha: 0.5)
      ..style = PaintingStyle.fill;

    const double spacing = 20.0;
    const double radius = 1.5;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
