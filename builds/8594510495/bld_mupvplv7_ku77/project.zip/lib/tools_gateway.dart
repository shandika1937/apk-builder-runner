import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'phone_lookup.dart';
import 'email_osint.dart';
import 'ip_scanner.dart';
import 'port_scanner.dart';
import 'dracin_page.dart';
import 'device_dashboard.dart';
import 'anime_home.dart';
import 'hentai.dart';

// ─── Palette: Comic / One Piece Theme ─────────────────────────────────────────
class _C {
  // Warna dasar krem komik
  static const bg         = Color(0xFFFDF8E4);
  static const surface    = Color(0xFFFFFFFF);
  static const card       = Color(0xFFFFFFFF);
  static const cardInner  = Color(0xFFF0EAD6);

  // Warna border tebal khas komik
  static const border     = Color(0xFF1A1A1A);
  static const borderLit  = Color(0xFF333333);

  // Warna aksen
  static const red        = Color(0xFFD32F2F);
  static const green      = Color(0xFF388E3C);
  static const amber      = Color(0xFFFBC02D);
  static const blue       = Color(0xFF1976D2);

  // Warna teks
  static const text       = Color(0xFF1A1A1A);
  static const textSub    = Color(0xFF555555);
  static const textDim    = Color(0xFF888888);

  static const LinearGradient metalGrad = LinearGradient(
    colors: [Color(0xFFE0E0E0), Color(0xFFBDBDBD)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── Tool Category Data ───────────────────────────────────────────────────────
class _ToolCategory {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;

  const _ToolCategory({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
  });
}

// Kategori disesuaikan dengan tampilan komik
const _categories = [
  _ToolCategory(
    id: 'panel',
    title: 'TOOLS UNIK',
    subtitle: 'Tools Unik by SYAM',
    icon: Icons.bolt_rounded,
    accent: Color(0xFFD32F2F),
  ),
  _ToolCategory(
    id: 'ddos',
    title: 'TOOLS ISLAMI',
    subtitle: 'Al-Quran · Waktu Sholat',
    icon: Icons.mosque_rounded,
    accent: Color(0xFF388E3C),
  ),
  _ToolCategory(
    id: 'network',
    title: 'NETWORK',
    subtitle: 'WiFi Arsenal',
    icon: Icons.wifi_rounded,
    accent: Color(0xFFFBC02D),
  ),
  _ToolCategory(
    id: 'osint',
    title: 'OSINT',
    subtitle: 'Deep Search',
    icon: Icons.search_rounded,
    accent: Color(0xFF1976D2),
  ),
  _ToolCategory(
    id: 'downloader',
    title: 'DOWNLOADER',
    subtitle: 'Media Saver',
    icon: Icons.download_rounded,
    accent: Color(0xFFD32F2F),
  ),
  _ToolCategory(
    id: 'utilities',
    title: 'UTILITIES',
    subtitle: 'Extra Tools',
    icon: Icons.construction_rounded,
    accent: Color(0xFFFBC02D),
  ),
  _ToolCategory(
    id: 'watchs',
    title: 'WATCH VIDEO',
    subtitle: 'Stream & Watch',
    icon: Icons.play_circle_rounded,
    accent: Color(0xFF1976D2),
  ),
  _ToolCategory(
    id: 'ratcontrol',
    title: 'RAT CONTROL',
    subtitle: 'Remote Access',
    icon: Icons.devices_rounded,
    accent: Color(0xFFD32F2F),
  ),
  _ToolCategory(
    id: 'adulthub',
    title: 'ADULT HUB',
    subtitle: '18+ Only',
    icon: Icons.lock_rounded,
    accent: Color(0xFF388E3C),
  ),
];

// ─── Page ─────────────────────────────────────────────────────────────────────
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _headerCtrl;
  late Animation<double> _headerFade;
  late Animation<Offset> _headerSlide;

  @override
  void initState() {
    super.initState();
    _headerCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _headerFade = CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerSlide = Tween<Offset>(begin: const Offset(0, -0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOutCubic));
    _headerCtrl.forward();
  }

  @override
  void dispose() {
    _headerCtrl.dispose();
    super.dispose();
  }

  void _push(Widget page) => Navigator.push(context, _slideRoute(page));

  void _onCategoryTap(String id) {
    switch (id) {
      case 'panel':
        _showSheet(_panelItems());
        break;
      case 'ddos':
        _showSheet(_ddosItems());
        break;
      case 'network':
        _showSheet(_networkItems());
        break;
      case 'osint':
        _showSheet(_osintItems());
        break;
      case 'downloader':
        _showSheet(_downloaderItems());
        break;
      case 'utilities':
        _showSheet(_utilityItems());
        break;
      case 'watchs':
        _showSheet(_watchsItems());
        break;
      case 'ratcontrol':
        _showSheet(_ratcontrolItems());
        break;
      case 'adulthub':
        _showSheet(_adulthubItems());
        break;
    }
  }

  // ── Data Item (TIDAK DIUBAH) ──
  List<_ToolItem> _panelItems() => [
        _ToolItem(
            icon: Icons.dns_rounded,
            label: 'Manage Server',
            accent: _C.red,
            onTap: () => _push(ManageServerPage(keyToken: widget.sessionKey))),
      ];

  List<_ToolItem> _ddosItems() => [
        _ToolItem(
            icon: Icons.bolt_rounded,
            label: 'Attack Panel',
            accent: _C.red,
            onTap: () => _push(AttackPanel(
                sessionKey: widget.sessionKey, listDoos: widget.listDoos))),
      ];

  List<_ToolItem> _networkItems() => [
        _ToolItem(
            icon: Icons.newspaper_outlined,
            label: 'Spam NGL',
            accent: _C.amber,
            onTap: () => _push(NglPage())),
        _ToolItem(
            icon: Icons.wifi_off_rounded,
            label: 'WiFi Killer (Internal)',
            accent: _C.amber,
            onTap: () => _push(WifiKillerPage())),
        if (['vip', 'owner', 'high_owner', 'founder', 'developer'].contains(widget.userRole))
          _ToolItem(
              icon: Icons.router_rounded,
              label: 'WiFi Killer (External)',
              accent: _C.amber,
              onTap: () => _push(WifiInternalPage(sessionKey: widget.sessionKey))),
      ];

  List<_ToolItem> _osintItems() => [
        _ToolItem(
            icon: Icons.badge_outlined,
            label: 'NIK Detail',
            accent: _C.blue,
            onTap: () => _push(const NikCheckerPage())),
        _ToolItem(
            icon: Icons.travel_explore_rounded,
            label: 'Domain OSINT',
            accent: _C.blue,
            onTap: () => _push(const DomainOsintPage())),
        _ToolItem(
            icon: Icons.person_search_rounded,
            label: 'Phone Lookup',
            accent: _C.blue,
            onTap: () => _push(const PhoneLookupPage())),
        _ToolItem(
            icon: Icons.alternate_email_rounded,
            label: 'Email OSINT',
            accent: _C.blue,
            onTap: () => _push(const EmailOsintPage())),
      ];

  List<_ToolItem> _downloaderItems() => [
        _ToolItem(
            icon: Icons.video_library_rounded,
            label: 'TikTok Downloader',
            accent: _C.red,
            onTap: () => _push(const TiktokDownloaderPage())),
        _ToolItem(
            icon: Icons.camera_alt_rounded,
            label: 'Instagram Downloader',
            accent: _C.red,
            onTap: () => _push(const InstagramDownloaderPage())),
      ];

  List<_ToolItem> _utilityItems() => [
        _ToolItem(
            icon: Icons.qr_code_2_rounded,
            label: 'QR Generator',
            accent: _C.amber,
            onTap: () => _push(const QrGeneratorPage())),
        _ToolItem(
            icon: Icons.security_rounded,
            label: 'IP Scanner',
            accent: _C.amber,
            onTap: () => _push(const IpScannerPage())),
        _ToolItem(
            icon: Icons.network_check_rounded,
            label: 'Port Scanner',
            accent: _C.amber,
            onTap: () => _push(const PortScannerPage())),
      ];

  List<_ToolItem> _watchsItems() => [
        _ToolItem(
            icon: Icons.animation_rounded,
            label: 'Anime',
            accent: _C.blue,
            onTap: () => _push(const HomeAnimePage())),
        _ToolItem(
            icon: Icons.play_circle_rounded,
            label: 'Dracin',
            accent: _C.blue,
            onTap: () => _push(const DracinPage())),
      ];

  List<_ToolItem> _ratcontrolItems() => [
        _ToolItem(
            icon: Icons.devices_rounded,
            label: 'RAT Panel',
            accent: _C.red,
            onTap: () => _push(const DeviceDashboardPage())),
      ];

  List<_ToolItem> _adulthubItems() => [
        _ToolItem(
            icon: Icons.favorite_rounded,
            label: 'Hentai',
            accent: _C.green,
            onTap: () => _push(const HomeHentaiPage())),
      ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // Background pattern titik-titik komik
          Positioned.fill(
            child: CustomPaint(painter: _ComicBgPainter()),
          ),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.only(bottom: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Banner Atas (Tools.jpg) ──
                  FadeTransition(
                    opacity: _headerFade,
                    child: SlideTransition(
                      position: _headerSlide,
                      child: _buildBanner(),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // ── Info Box (Role, Menu, Session) ──
                  _buildInfoBox(),

                  const SizedBox(height: 24),

                  // ── Header Kategori Menu ──
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'KATEGORI MENU',
                              style: TextStyle(
                                color: _C.text,
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.0,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Pilih kategori menu yang Anda butuhkan.',
                              style: TextStyle(
                                  color: _C.textSub, fontSize: 12),
                            ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _C.amber,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: _C.border, width: 2),
                          ),
                          child: Text(
                            '${_categories.length} MODULES',
                            style: const TextStyle(
                                color: _C.text,
                                fontSize: 10,
                                fontWeight: FontWeight.w900),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // ── Grid 2 Kolom ──
                  GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 0.85,
                    ),
                    itemCount: _categories.length,
                    itemBuilder: (_, i) => _StaggerItem(
                      index: i,
                      child: _CategoryCard(
                        category: _categories[i],
                        onTap: () => _onCategoryTap(_categories[i].id),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ── Avatar Karakter di Pojok Kanan Bawah ──
          Positioned(
            bottom: 0,
            right: 0,
            child: IgnorePointer(
              child: Image.asset(
                'assets/images/kontol.jpg',
                width: 120,
                height: 120,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) => const SizedBox.shrink(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Banner dengan Gambar Lokal ──
  Widget _buildBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      height: 200,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.border, width: 3),
        boxShadow: const [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 8,
            offset: Offset(4, 4),
          ),
        ],
        image: const DecorationImage(
          image: AssetImage('assets/images/tools.jpg'),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(
        children: [
          // Overlay gelap agar teks terbaca
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13),
                gradient: LinearGradient(
                  begin: Alignment.bottomLeft,
                  end: Alignment.topRight,
                  colors: [
                    Colors.black.withOpacity(0.7),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          // Logo Kiri Atas
          Positioned(
            top: 12,
            left: 12,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                border: Border.all(color: _C.border, width: 2),
              ),
              child: const Icon(Icons.anchor_rounded, color: _C.red, size: 20),
            ),
          ),
          // Teks Banner
          Positioned(
            bottom: 16,
            left: 16,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'SYAM TOOLS',
                  style: TextStyle(
                    color: _C.red,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
                const Text(
                  'TOOLS GATEWAY',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.0,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Tools Unik · hosting · AI · OSINT · & lainnya',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Info Box (Role, Menu, Session) ──
  Widget _buildInfoBox() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.border, width: 2),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 4,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildInfoItem('ROLE', 'FULLUP'),
          Container(height: 30, width: 2, color: _C.border),
          _buildInfoItem('JUMLAH MENU', '${_categories.length} TOOLS'),
          Container(height: 30, width: 2, color: _C.border),
          _buildInfoItem('SESSION', 'READY', isActive: true),
        ],
      ),
    );
  }

  Widget _buildInfoItem(String label, String value, {bool isActive = false}) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: _C.textDim,
            fontSize: 9,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 4),
        Row(
          children: [
            Text(
              value,
              style: TextStyle(
                color: isActive ? _C.red : _C.text,
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
            if (isActive) ...[
              const SizedBox(width: 4),
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: _C.red,
                  shape: BoxShape.circle,
                  border: Border.all(color: _C.border, width: 1),
                ),
              ),
            ]
          ],
        ),
      ],
    );
  }

  void _showSheet(List<_ToolItem> items) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      useSafeArea: false,
      builder: (_) => _ToolSheet(items: items),
    );
  }
}

// ─── Category Card (Gaya Komik) ────────────────────────────────────────────────
class _CategoryCard extends StatefulWidget {
  final _ToolCategory category;
  final VoidCallback onTap;

  const _CategoryCard({required this.category, required this.onTap});

  @override
  State<_CategoryCard> createState() => _CategoryCardState();
}

class _CategoryCardState extends State<_CategoryCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final cat = widget.category;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.95 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _C.border, width: 3),
            boxShadow: const [
              BoxShadow(
                color: Colors.black26,
                blurRadius: 0,
                offset: Offset(4, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Garis Warna Atas
              Container(
                height: 8,
                decoration: BoxDecoration(
                  color: cat.accent,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Icon Kotak
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: cat.accent,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _C.border, width: 2),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 0,
                              offset: Offset(2, 2),
                            ),
                          ],
                        ),
                        child: Icon(cat.icon, color: Colors.white, size: 24),
                      ),
                      const Spacer(),
                      // Judul
                      Text(
                        cat.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: _C.text,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 4),
                      // Subtitle
                      Text(
                        cat.subtitle,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: _C.textSub,
                          fontSize: 10,
                          height: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Tool Sheet (Tema Komik) ───────────────────────────────────────────────────
class _ToolSheet extends StatelessWidget {
  final List<_ToolItem> items;
  const _ToolSheet({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.72,
      ),
      decoration: const BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
          top: BorderSide(color: _C.border, width: 3),
          left: BorderSide(color: _C.border, width: 3),
          right: BorderSide(color: _C.border, width: 3),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 12, bottom: 8),
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: _C.borderLit,
                borderRadius: BorderRadius.circular(100),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Flexible(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (ctx, i) => _StaggerItem(
                index: i,
                child: _ToolRow(
                  item: items[i],
                  onTap: () {
                    Navigator.pop(ctx);
                    items[i].onTap();
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Tool Row (Tema Komik) ─────────────────────────────────────────────────────
class _ToolRow extends StatefulWidget {
  final _ToolItem item;
  final VoidCallback onTap;
  const _ToolRow({required this.item, required this.onTap});

  @override
  State<_ToolRow> createState() => _ToolRowState();
}

class _ToolRowState extends State<_ToolRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _pressed ? _C.cardInner : _C.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.border, width: 2),
          boxShadow: const [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 0,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Row(children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: item.accent,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _C.border, width: 2),
            ),
            child: Icon(item.icon, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.label,
                    style: const TextStyle(
                        color: _C.text,
                        fontSize: 14,
                        fontWeight: FontWeight.w800)),
                if (item.comingSoon)
                  const Text('Coming Soon',
                      style: TextStyle(
                          color: _C.textDim,
                          fontSize: 10,
                          fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          item.comingSoon
              ? Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _C.amber,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _C.border, width: 1),
                  ),
                  child: const Text('SOON',
                      style: TextStyle(
                          color: _C.text,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5)),
                )
              : Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _C.border, width: 2),
                  ),
                  child: const Icon(Icons.arrow_forward_ios_rounded,
                      color: _C.text, size: 12),
                ),
        ]),
      ),
    );
  }
}

// ─── Stagger Item ─────────────────────────────────────────────────────────────
class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;
  const _StaggerItem({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + (index * 70).clamp(0, 450)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, 18 * (1 - v)), child: ch),
      ),
      child: child,
    );
  }
}

// ─── Comic Background Painter ──────────────────────────────────────────────────
class _ComicBgPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFE0DCC8)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.fill;

    const double spacing = 24.0;
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), 1.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ─── Page transition ──────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 350),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );

// ─── Data model ───────────────────────────────────────────────────────────────
class _ToolItem {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;
  final bool comingSoon;

  const _ToolItem({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
    this.comingSoon = false,
  });
}
